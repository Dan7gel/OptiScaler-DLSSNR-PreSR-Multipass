#include "pch.h"
#include "DlssNr_StreamlinePicture.h"
#include "DlssNrFeature_Dx12.h"
#include <Config.h>
#include <State.h>
#include <Util.h>
#include <cstring>
#include <wrl/client.h>

namespace DlssNr::StreamlinePicture
{
namespace
{
using Present = HRESULT (*)(IDXGISwapChain*, UINT, UINT, bool&);
using Present1 = HRESULT (*)(IDXGISwapChain*, UINT, UINT, const DXGI_PRESENT_PARAMETERS*, bool&);
using CreateHwnd = HRESULT (*)(IDXGIFactory2*, IUnknown*, HWND, const DXGI_SWAP_CHAIN_DESC1*,
                              const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*, IDXGIOutput*, IDXGISwapChain1**, bool&);
Present originalPresent = nullptr;
Present1 originalPresent1 = nullptr;
CreateHwnd originalCreate = nullptr;
GetIndex getIndex = nullptr;
GetBuffer getBuffer = nullptr;

// The game's UI colour+alpha layer and its HUD-less frame, tagged for frame generation and kept for the
// finished picture's HUD mask. A resource only valid at tag time is copied right then on the game's
// command list (the way frame generation keeps it); one valid until present is noted directly.
struct TagCapture
{
    ID3D12Resource* noted = nullptr;
    D3D12_RESOURCE_STATES notedState = D3D12_RESOURCE_STATE_COMMON;
    bool valid = false;
    Microsoft::WRL::ComPtr<ID3D12Resource> copy; // our own copy of an only-valid-now resource
    bool copyReadable = false;                    // false = fresh (COPY_DEST); true = NPSR

    ID3D12Resource* Take(D3D12_RESOURCE_STATES* state)
    {
        ID3D12Resource* r = valid ? noted : nullptr;
        *state = notedState;
        noted = nullptr;
        valid = false;
        return r;
    }

    // Diagnostics for the status line: what the last tag delivered.
    unsigned seen = 0;          // tags seen in this session
    bool lastOnlyNow = false;
    bool lastHadCmd = false;
    unsigned lastFormat = 0;
    unsigned lastW = 0, lastH = 0;
    bool copyFailed = false;

    void Note(ID3D12Resource* resource, unsigned int state, bool onlyValidNow, void* cmdBuffer)
    {
        if (resource == nullptr)
            return;
        ++seen;
        lastOnlyNow = onlyValidNow;
        lastHadCmd = cmdBuffer != nullptr;
        {
            const auto d = resource->GetDesc();
            lastFormat = (unsigned) d.Format;
            lastW = (unsigned) d.Width;
            lastH = d.Height;
        }
        if (!onlyValidNow)
        {
            noted = resource;
            notedState = (D3D12_RESOURCE_STATES) state;
            valid = true;
            return;
        }
        auto* cmd = (ID3D12GraphicsCommandList*) cmdBuffer;
        if (cmd == nullptr)
            return;
        const auto desc = resource->GetDesc();
        if (desc.Dimension != D3D12_RESOURCE_DIMENSION_TEXTURE2D)
            return;
        if (copy)
        {
            const auto cd = copy->GetDesc();
            if (cd.Width != desc.Width || cd.Height != desc.Height || cd.Format != desc.Format)
            {
                copy.Reset();
                copyReadable = false;
            }
        }
        if (!copy)
        {
            Microsoft::WRL::ComPtr<ID3D12Device> device;
            if (FAILED(resource->GetDevice(IID_PPV_ARGS(&device))))
                return;
            D3D12_RESOURCE_DESC cd = desc;
            cd.Flags = D3D12_RESOURCE_FLAG_NONE;
            cd.MipLevels = 1;
            D3D12_HEAP_PROPERTIES heap {};
            heap.Type = D3D12_HEAP_TYPE_DEFAULT;
            if (FAILED(device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &cd, D3D12_RESOURCE_STATE_COPY_DEST,
                                                       nullptr, IID_PPV_ARGS(&copy))))
            {
                copyFailed = true;
                return;
            }
            copyFailed = false;
            copyReadable = false;
        }
        const auto srcState = (D3D12_RESOURCE_STATES) state;
        const bool moveSrc = srcState != D3D12_RESOURCE_STATE_COPY_SOURCE && srcState != D3D12_RESOURCE_STATE_COMMON;
        D3D12_RESOURCE_BARRIER b[2] {};
        unsigned n = 0;
        if (moveSrc)
        {
            b[n].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
            b[n].Transition.pResource = resource;
            b[n].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
            b[n].Transition.StateBefore = srcState;
            b[n].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
            ++n;
        }
        if (copyReadable)
        {
            b[n].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
            b[n].Transition.pResource = copy.Get();
            b[n].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
            b[n].Transition.StateBefore = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
            b[n].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;
            ++n;
        }
        if (n) cmd->ResourceBarrier(n, b);
        D3D12_TEXTURE_COPY_LOCATION dst {}, src {};
        dst.pResource = copy.Get(); dst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; dst.SubresourceIndex = 0;
        src.pResource = resource; src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; src.SubresourceIndex = 0;
        cmd->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);
        n = 0;
        if (moveSrc)
        {
            b[n].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
            b[n].Transition.pResource = resource;
            b[n].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
            b[n].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
            b[n].Transition.StateAfter = srcState;
            ++n;
        }
        b[n].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        b[n].Transition.pResource = copy.Get();
        b[n].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b[n].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
        b[n].Transition.StateAfter = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
        ++n;
        cmd->ResourceBarrier(n, b);
        copyReadable = true;
        noted = copy.Get();
        notedState = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
        valid = true;
    }
};
TagCapture uiTag;
TagCapture hudlessTag;

void Apply(IDXGISwapChain* swapchain, UINT flags, bool skip)
{
    const auto& cfg = *Config::Instance();
    if (skip || (flags & DXGI_PRESENT_TEST) || !cfg.DlssNrEnabled.value_or_default() ||
        !cfg.DlssNrFinishedPicture.value_or_default()) return;
    auto queue = RenderQueue(swapchain);
    if (!queue) return;
    auto picture = Read(swapchain, getIndex, getBuffer);
    D3D12_RESOURCE_STATES uiState = D3D12_RESOURCE_STATE_COMMON, hudState = D3D12_RESOURCE_STATE_COMMON;
    ID3D12Resource* ui = uiTag.Take(&uiState);
    ID3D12Resource* hud = hudlessTag.Take(&hudState);
    if (!picture) return;
    ApplyToStreamlinePicture(swapchain, picture.Get(), queue.Get(), ui, uiState, hud, hudState);
}

HRESULT BeforePresent(IDXGISwapChain* swapchain, UINT interval, UINT flags, bool& skip)
{
    Apply(swapchain, flags, skip);
    return originalPresent(swapchain, interval, flags, skip);
}
HRESULT BeforePresent1(IDXGISwapChain* swapchain, UINT interval, UINT flags,
                       const DXGI_PRESENT_PARAMETERS* parameters, bool& skip)
{
    Apply(swapchain, flags, skip);
    return originalPresent1(swapchain, interval, flags, parameters, skip);
}
HRESULT CreateForHwnd(IDXGIFactory2* factory, IUnknown* device, HWND window, const DXGI_SWAP_CHAIN_DESC1* desc,
                      const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* fullscreen, IDXGIOutput* output,
                      IDXGISwapChain1** swapchain, bool& skip)
{
    const auto result = originalCreate(factory, device, window, desc, fullscreen, output, swapchain, skip);
    // A handled create is the native game's DLSSG swapchain. Remember the app's queue,
    // not the internal presentation queue that DLSSG passes to the native DXGI factory.
    if (SUCCEEDED(result) && skip && device && swapchain && *swapchain)
    {
        Microsoft::WRL::ComPtr<ID3D12CommandQueue> queue;
        if (SUCCEEDED(device->QueryInterface(IID_PPV_ARGS(&queue))))
        {
            ID3D12CommandQueue* real = nullptr;
            if (Util::CheckForRealObject(__FUNCTION__, queue.Get(), (IUnknown**) &real)) queue = real;
            if (SUCCEEDED((*swapchain)->SetPrivateDataInterface(renderQueueKey, queue.Get())))
                LOG_INFO("DLSS-NR: native Streamline finished-picture handoff registered on the game render queue");
        }
    }
    return result;
}
}

void NoteUiTag(ID3D12Resource* resource, unsigned int state, bool onlyValidNow, void* cmdBuffer)
{
    uiTag.Note(resource, state, onlyValidNow, cmdBuffer);
}

std::string TagDiagnostics()
{
    char buf[256];
    snprintf(buf, sizeof(buf), "tags: hudless %u (%s, cmd %s, fmt %u, %ux%u%s) | ui %u (%s, cmd %s, fmt %u%s)",
             hudlessTag.seen, hudlessTag.lastOnlyNow ? "only-now" : "until-present", hudlessTag.lastHadCmd ? "yes" : "no",
             hudlessTag.lastFormat, hudlessTag.lastW, hudlessTag.lastH, hudlessTag.copyFailed ? ", copy FAILED" : "",
             uiTag.seen, uiTag.lastOnlyNow ? "only-now" : "until-present", uiTag.lastHadCmd ? "yes" : "no",
             uiTag.lastFormat, uiTag.copyFailed ? ", copy FAILED" : "");
    return buf;
}

void NoteHudlessTag(ID3D12Resource* resource, unsigned int state, bool onlyValidNow, void* cmdBuffer)
{
    hudlessTag.Note(resource, state, onlyValidNow, cmdBuffer);
}

void* Wrap(const char* name, GetFunction getFunction)
{
    if (!getFunction) return nullptr;
    const bool present = std::strcmp(name, "slHookPresent") == 0;
    const bool present1 = std::strcmp(name, "slHookPresent1") == 0;
    const bool create = std::strcmp(name, "slHookCreateSwapChainForHwnd") == 0;
    if (!present && !present1 && !create) return nullptr;
    auto* function = getFunction(name);
    getIndex = reinterpret_cast<GetIndex>(getFunction("slHookGetCurrentBackBufferIndex"));
    getBuffer = reinterpret_cast<GetBuffer>(getFunction("slHookGetBuffer"));
    if (!function || !getIndex || !getBuffer || !getFunction("slHookPresent") || !getFunction("slHookPresent1"))
        return nullptr;
    if (present) { originalPresent = reinterpret_cast<Present>(function); return &BeforePresent; }
    if (present1) { originalPresent1 = reinterpret_cast<Present1>(function); return &BeforePresent1; }
    originalCreate = reinterpret_cast<CreateHwnd>(function);
    return &CreateForHwnd;
}
}
