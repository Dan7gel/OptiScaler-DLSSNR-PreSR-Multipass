#include "pch.h"
#include "DlssNr_StreamlinePicture.h"
#include "DlssNrFeature_Dx12.h"
#include <Config.h>
#include <State.h>
#include <Util.h>
#include <cstring>
#include <wrl/client.h>

namespace DlssNr::StreamlinePicture
{
namespace
{
using Present = HRESULT (*)(IDXGISwapChain*, UINT, UINT, bool&);
using Present1 = HRESULT (*)(IDXGISwapChain*, UINT, UINT, const DXGI_PRESENT_PARAMETERS*, bool&);
using CreateHwnd = HRESULT (*)(IDXGIFactory2*, IUnknown*, HWND, const DXGI_SWAP_CHAIN_DESC1*,
                              const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*, IDXGIOutput*, IDXGISwapChain1**, bool&);
Present originalPresent = nullptr;
Present1 originalPresent1 = nullptr;
CreateHwnd originalCreate = nullptr;
GetIndex getIndex = nullptr;
GetBuffer getBuffer = nullptr;
ID3D12Resource* notedUi = nullptr;
D3D12_RESOURCE_STATES notedUiState = D3D12_RESOURCE_STATE_COMMON;
bool notedUiValid = false;
Microsoft::WRL::ComPtr<ID3D12Resource> uiCopy;      // our own copy of an only-valid-now UI layer
bool uiCopyReadable = false;                          // false = never used yet (COMMON); true = NPSR

void Apply(IDXGISwapChain* swapchain, UINT flags, bool skip)
{
    const auto& cfg = *Config::Instance();
    if (skip || (flags & DXGI_PRESENT_TEST) || !cfg.DlssNrEnabled.value_or_default() ||
        !cfg.DlssNrFinishedPicture.value_or_default()) return;
    auto queue = RenderQueue(swapchain);
    if (!queue) return;
    auto picture = Read(swapchain, getIndex, getBuffer);
    if (!picture) return;
    ID3D12Resource* ui = notedUiValid ? notedUi : nullptr;
    const auto uiState = notedUiState;
    notedUi = nullptr;
    notedUiValid = false;
    ApplyToStreamlinePicture(swapchain, picture.Get(), queue.Get(), ui, uiState);
}

HRESULT BeforePresent(IDXGISwapChain* swapchain, UINT interval, UINT flags, bool& skip)
{
    Apply(swapchain, flags, skip);
    return originalPresent(swapchain, interval, flags, skip);
}
HRESULT BeforePresent1(IDXGISwapChain* swapchain, UINT interval, UINT flags,
                       const DXGI_PRESENT_PARAMETERS* parameters, bool& skip)
{
    Apply(swapchain, flags, skip);
    return originalPresent1(swapchain, interval, flags, parameters, skip);
}
HRESULT CreateForHwnd(IDXGIFactory2* factory, IUnknown* device, HWND window, const DXGI_SWAP_CHAIN_DESC1* desc,
                      const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* fullscreen, IDXGIOutput* output,
                      IDXGISwapChain1** swapchain, bool& skip)
{
    const auto result = originalCreate(factory, device, window, desc, fullscreen, output, swapchain, skip);
    // A handled create is the native game's DLSSG swapchain. Remember the app's queue,
    // not the internal presentation queue that DLSSG passes to the native DXGI factory.
    if (SUCCEEDED(result) && skip && device && swapchain && *swapchain)
    {
        Microsoft::WRL::ComPtr<ID3D12CommandQueue> queue;
        if (SUCCEEDED(device->QueryInterface(IID_PPV_ARGS(&queue))))
        {
            ID3D12CommandQueue* real = nullptr;
            if (Util::CheckForRealObject(__FUNCTION__, queue.Get(), (IUnknown**) &real)) queue = real;
            if (SUCCEEDED((*swapchain)->SetPrivateDataInterface(renderQueueKey, queue.Get())))
                LOG_INFO("DLSS-NR: native Streamline finished-picture handoff registered on the game render queue");
        }
    }
    return result;
}
}

void NoteUiTag(ID3D12Resource* resource, unsigned int state, bool onlyValidNow, void* cmdBuffer)
{
    if (resource == nullptr)
        return;
    if (!onlyValidNow)
    {
        notedUi = resource;
        notedUiState = (D3D12_RESOURCE_STATES) state;
        notedUiValid = true;
        return;
    }
    auto* cmd = (ID3D12GraphicsCommandList*) cmdBuffer;
    if (cmd == nullptr)
        return;
    const auto desc = resource->GetDesc();
    if (desc.Dimension != D3D12_RESOURCE_DIMENSION_TEXTURE2D)
        return;
    if (uiCopy)
    {
        const auto cd = uiCopy->GetDesc();
        if (cd.Width != desc.Width || cd.Height != desc.Height || cd.Format != desc.Format)
        {
            uiCopy.Reset();
            uiCopyReadable = false;
        }
    }
    if (!uiCopy)
    {
        Microsoft::WRL::ComPtr<ID3D12Device> device;
        if (FAILED(resource->GetDevice(IID_PPV_ARGS(&device))))
            return;
        D3D12_RESOURCE_DESC cd = desc;
        cd.Flags = D3D12_RESOURCE_FLAG_NONE;
        cd.MipLevels = 1;
        D3D12_HEAP_PROPERTIES heap {};
        heap.Type = D3D12_HEAP_TYPE_DEFAULT;
        if (FAILED(device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &cd, D3D12_RESOURCE_STATE_COPY_DEST,
                                                   nullptr, IID_PPV_ARGS(&uiCopy))))
            return;
        uiCopyReadable = false;
    }
    const auto srcState = (D3D12_RESOURCE_STATES) state;
    D3D12_RESOURCE_BARRIER b[2] {};
    unsigned n = 0;
    if (srcState != D3D12_RESOURCE_STATE_COPY_SOURCE && srcState != D3D12_RESOURCE_STATE_COMMON)
    {
        b[n].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        b[n].Transition.pResource = resource;
        b[n].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b[n].Transition.StateBefore = srcState;
        b[n].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
        ++n;
    }
    if (uiCopyReadable)
    {
        b[n].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        b[n].Transition.pResource = uiCopy.Get();
        b[n].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b[n].Transition.StateBefore = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
        b[n].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;
        ++n;
    }
    if (n) cmd->ResourceBarrier(n, b);
    // Mip zero only: the copy is single-mip.
    D3D12_TEXTURE_COPY_LOCATION dst {}, src {};
    dst.pResource = uiCopy.Get(); dst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; dst.SubresourceIndex = 0;
    src.pResource = resource; src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; src.SubresourceIndex = 0;
    cmd->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);
    n = 0;
    if (srcState != D3D12_RESOURCE_STATE_COPY_SOURCE && srcState != D3D12_RESOURCE_STATE_COMMON)
    {
        b[n].Transition.pResource = resource;
        b[n].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
        b[n].Transition.StateAfter = srcState;
        ++n;
    }
    b[n].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    b[n].Transition.pResource = uiCopy.Get();
    b[n].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    b[n].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
    b[n].Transition.StateAfter = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
    ++n;
    cmd->ResourceBarrier(n, b);
    uiCopyReadable = true;
    notedUi = uiCopy.Get();
    notedUiState = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
    notedUiValid = true;
}

void* Wrap(const char* name, GetFunction getFunction)
{
    if (!getFunction) return nullptr;
    const bool present = std::strcmp(name, "slHookPresent") == 0;
    const bool present1 = std::strcmp(name, "slHookPresent1") == 0;
    const bool create = std::strcmp(name, "slHookCreateSwapChainForHwnd") == 0;
    if (!present && !present1 && !create) return nullptr;
    auto* function = getFunction(name);
    getIndex = reinterpret_cast<GetIndex>(getFunction("slHookGetCurrentBackBufferIndex"));
    getBuffer = reinterpret_cast<GetBuffer>(getFunction("slHookGetBuffer"));
    if (!function || !getIndex || !getBuffer || !getFunction("slHookPresent") || !getFunction("slHookPresent1"))
        return nullptr;
    if (present) { originalPresent = reinterpret_cast<Present>(function); return &BeforePresent; }
    if (present1) { originalPresent1 = reinterpret_cast<Present1>(function); return &BeforePresent1; }
    originalCreate = reinterpret_cast<CreateHwnd>(function);
    return &CreateForHwnd;
}
}
