#pragma once

#include <imgui/imgui.h>
#include <algorithm>
#include <cmath>

class Config;

namespace DlssNr::MenuSections
{
// Keyboard control for sliders.
//
// The slider under the mouse becomes the keyboard target and stays the target after the mouse
// leaves it, until another slider is hovered. Left / Right move it one step; holding a key repeats
// at ImGui's key-repeat rate, so a long press runs the value. Returns true when the value changed
// this frame. Sliders whose commit rebuilds the model call ArrowKeyHeld() to commit only once the
// key is released, so a long press costs one rebuild rather than one per step.
inline ImGuiID& ArrowTarget()
{
    static ImGuiID target = 0;
    return target;
}

// Also draws a pair of "<" ">" step buttons after the slider's label: a click moves one step, and
// holding the button repeats like the keys. The item ID is read before the buttons are drawn, so the
// keyboard target is always the slider itself.
inline bool ArrowNudge(float* value, float step, float mn, float mx)
{
    const ImGuiID id = ImGui::GetItemID();
    if (ImGui::IsItemHovered())
        ArrowTarget() = id;
    float delta = 0.0f;
    if (ArrowTarget() == id)
    {
        if (ImGui::IsKeyPressed(ImGuiKey_LeftArrow, true))
            delta -= step;
        if (ImGui::IsKeyPressed(ImGuiKey_RightArrow, true))
            delta += step;
    }
    ImGui::SameLine();
    ImGui::PushID((int) id);
    ImGui::PushItemFlag(ImGuiItemFlags_ButtonRepeat, true);
    if (ImGui::SmallButton("<"))
    {
        delta -= step;
        ArrowTarget() = id;
    }
    ImGui::SameLine(0.0f, 2.0f);
    if (ImGui::SmallButton(">"))
    {
        delta += step;
        ArrowTarget() = id;
    }
    ImGui::PopItemFlag();
    ImGui::PopID();
    if (delta == 0.0f)
        return false;
    *value = std::clamp(*value + delta, mn, mx);
    return true;
}

inline bool ArrowNudgeInt(int* value, int step, int mn, int mx)
{
    float v = (float) *value;
    if (!ArrowNudge(&v, (float) step, (float) mn, (float) mx))
        return false;
    *value = (int) lroundf(v);
    return true;
}

inline bool ArrowKeyHeld()
{
    return ImGui::IsKeyDown(ImGuiKey_LeftArrow) || ImGui::IsKeyDown(ImGuiKey_RightArrow);
}

// A small "Reset" button on the same line as the last slider, keyed by that slider's label.
inline bool ResetButton(const char* label)
{
    ImGui::SameLine();
    ImGui::PushID(label);
    const bool pressed = ImGui::SmallButton("Reset");
    ImGui::PopID();
    return pressed;
}

// Compact contextual help, matching the rest of the menu.
inline void HelpMarker(const char* tip)
{
    ImGui::SameLine();
    ImGui::TextDisabled("(?)");

    if (ImGui::IsItemHovered())
    {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 40.0f);
        ImGui::TextUnformatted(tip);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }
}


void RenderPlacement(Config* config, float menuResScale);
void RenderStatus(Config* config, float menuResScale);
void RenderInput(Config* config, float menuResScale);
void RenderModel(Config* config, float menuResScale);
void RenderBlend(Config* config, float menuResScale);
void RenderInspect(Config* config, float menuResScale);
void RenderCleanup(Config* config, float menuResScale);
} // namespace DlssNr::MenuSections
