#include "pch.h"

#include "DlssNr.h"
#include "DlssNr_MenuSections.h"
#include "DlssNr_Status.h"
#include "DlssNr_RrRoute.h"
#include "DlssNr_Drift.h"
#include "DlssNrNative.h"
#include <Config.h>
#include <menu/menu_common.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>

namespace DlssNr::MenuSections
{
namespace
{
enum class Tone { Info, Good, Note, Warn };

void Line(Tone tone, const std::string& text)
{
    ImVec4 colour = ImGui::GetStyleColorVec4(ImGuiCol_Text);
    switch (tone)
    {
    case Tone::Good: colour = ImVec4(0.58f, 0.86f, 0.58f, 1.0f); break;
    case Tone::Note: colour = ImVec4(0.92f, 0.80f, 0.42f, 1.0f); break;
    case Tone::Warn: colour = ImVec4(0.96f, 0.56f, 0.50f, 1.0f); break;
    default: break;
    }
    ImGui::PushStyleColor(ImGuiCol_Text, colour);
    ImGui::TextWrapped("%s", text.c_str());
    ImGui::PopStyleColor();
}

std::string Pct(float v) { return std::to_string((int) std::lround(v * 100.0f)) + "%"; }
std::string Ms(double v)
{
    char buf[32];
    snprintf(buf, sizeof(buf), "%.2f ms", v);
    return buf;
}
} // namespace

void RenderAdvisor(Config* config, float menuResScale)
{
    const auto& state = State::Instance();
    const auto feature = state.currentFeature;
    const bool rr = feature && feature->GetUpscalerType() == Upscaler::DLSSD;
    const bool dedicatedRr = DedicatedRrRoute(*config, rr);
    const auto placement = ResolvePlacementFor(*config, rr);
    const float scale = ModelWorkingScale(*config, rr);
    const unsigned int passes = ModelPasses(*config, rr);
    const unsigned int style = config->DlssNrStyle.value_or_default();
    const char* styleName = style == 1 ? "Natural" : style == 2 ? "Cinematic" : "Standard";
    const unsigned int transfer = config->DlssNrTransfer.value_or_default();
    const unsigned int filter = config->DlssNrEnlargeFilter.value_or_default();
    const bool colourLock = dedicatedRr && config->DlssNrRRColourLock.value_or_default();
    const float colourStrength = colourLock ? 0.0f : config->DlssNrColourStrength.value_or_default();
    const float hueStability = config->DlssNrHueStability.value_or_default();
    const float glow = config->DlssNrGlowSuppression.value_or_default();
    const unsigned int reversible = config->DlssNrReversibleMode.value_or_default();
    const bool running = DlssNr::IsRunning();
    const auto ms = DlssNr::LastGpuTime();
    const auto exposure = DlssNr::GameExposureStatus();
    const auto observed = DlssNrNative::Observed();
    const auto drift = DlssNr::Drift::Get();

    // The model's base size is the frame it runs on: the render size before the upscaler (pre-SR),
    // the output size after it (shared post route and the RR route).
    unsigned int outW = 0, outH = 0;
    if (feature)
    {
        const bool preSr = placement.beforeUpscale && !dedicatedRr;
        outW = preSr ? feature->RenderWidth() : feature->DisplayWidth();
        outH = preSr ? feature->RenderHeight() : feature->DisplayHeight();
    }
    const unsigned int modelW = (unsigned int) std::lround(outW * scale);
    const unsigned int modelH = (unsigned int) std::lround(outH * scale);

    // ---- what runs where
    ImGui::SeparatorText("Pipeline");
    if (!running)
        Line(Tone::Warn, "NR is not running. The status line under the chart says why; Retry after fixing it.");
    if (placement.finished)
        Line(Tone::Note, std::string("Placement: finished picture at presentation") + (rr ? " (RR route)" : "") +
                             ". Tone-mapped, HUD included. Under HDR/RenoDX this route can boil on neon and shine on"
                             " skin; the linear-buffer routes do not.");
    else if (dedicatedRr)
        Line(Tone::Good, "Placement: dedicated RR route. NR runs once right after Ray Reconstruction on the de-jittered,"
                         " denoised linear frame. RR's inputs are untouched, so its denoise is intact; this is the"
                         " placement the RR games need.");
    else if (placement.beforeUpscale && rr)
        Line(Tone::Warn, "Placement: NR before Ray Reconstruction. The denoiser eats most of the edit and the noisy input"
                         " can leave artifacts. Tick the Dedicated RR route.");
    else if (placement.beforeUpscale)
        Line(Tone::Good, "Placement: pre-SR. NR runs on the render-resolution frame before the upscaler; cheapest, and"
                         " right for games without Ray Reconstruction.");
    else
        Line(Tone::Info, "Placement: after the upscaler (shared route) on the linear frame.");

    Line(Tone::Info, "Ray Reconstruction: " + std::string(rr ? "active (DLSSD feature)." : "not active (DLSS SR/DLAA)."));

    {
        std::string fg;
        if (state.activeFgOutput != FGOutput::NoFG)
            fg = "OptiScaler frame generation is active. NR is applied to rendered frames before FG; generated"
                 " frames inherit it. NR's cost lands once per rendered frame, not per displayed frame.";
        else
            fg = "OptiScaler is not replacing frame generation; the game's own FG (DLSS-G / MFG), if enabled, passes"
                 " through. NR runs on rendered frames before FG, so generated frames inherit it and NR's cost"
                 " is per rendered frame (once per 2x/3x/4x displayed frames).";
        Line(Tone::Info, "Frame generation: " + fg);
    }

    Line(Tone::Info, std::string("Output: ") + (state.hdrOutputActive ? "HDR swapchain." : "SDR swapchain.") +
                         " NR edits the game's internal linear HDR buffer before the tonemapper on the linear routes, so the"
                         " display mode does not change what the model sees.");

    // ---- cost
    ImGui::SeparatorText("Cost");
    {
        std::string s = "Model: " + std::to_string(modelW) + "x" + std::to_string(modelH) + " (" + Pct(scale) + " of " +
                        std::to_string(outW) + "x" + std::to_string(outH) + "), " + std::to_string(passes) +
                        (passes == 1 ? " pass" : " passes") + ", style " + styleName + ".";
        if (observed.tokens > 0)
            s += " Tokens M=" + std::to_string(observed.tokens) + " (grid " + std::to_string(observed.dims[0]) + "x" +
                 std::to_string(observed.dims[1]) + "); cost follows M, not pixels.";
        Line(Tone::Info, s);
    }
    if (ms.has_value())
    {
        const double frame = state.currentFG ? state.lastFGFrameTime : state.presentFrameTime;
        std::string s = "NR " + Ms(ms.value());
        if (frame > 0.0)
        {
            char buf[64];
            snprintf(buf, sizeof(buf), " of a ~%.2f ms rendered frame (%d%%).", frame,
                     (int) std::lround(100.0 * ms.value() / frame));
            s += buf;
        }
        Line(ms.value() > 6.0 ? Tone::Note : Tone::Info, s);
    }
    {
        const auto hybrid = DlssNrNative::Status();
        if (config->DlssNrPrecision.value_or_default() == 2)
        {
            if (hybrid.find(" hybrid M=") != std::string::npos)
                Line(Tone::Good, std::string("Hybrid NVFP4: engaged (") +
                                     (hybrid.rfind("Candidate", 0) == 0 ? "split-half candidate kernel" : "fused kernel") +
                                     ").");
            else if (hybrid.find("fallback") != std::string::npos)
                Line(Tone::Note, "Hybrid NVFP4: not engaged at this model size (kernels exist for M=960, 2160 and 3840 tokens:"
                                 " the 2560x1440, 3840x2160 and 5120x2880 models) or the asset set is incomplete. Running FP8,"
                                 " no cost either way.");
            else if (hybrid.find("Restart required") != std::string::npos)
                Line(Tone::Warn, "Hybrid NVFP4: " + hybrid.substr(0, hybrid.find(" |")));
            else
                Line(Tone::Info, "Hybrid NVFP4: selected, waiting for the model's next launch to record its kernels.");
        }
    }
    // Hybrid reach: which render/model sizes from THIS output land on a hybrid token count. The model's
    // grids we have observed: 2560x1440 -> 960, 3840x2160 -> 2160, 5120x2880 -> 3840 (16:9 only).
    if (config->DlssNrPrecision.value_or_default() == 2 && feature)
    {
        const unsigned int dispW = feature->DisplayWidth(), dispH = feature->DisplayHeight();
        const bool sixteenNine = dispW > 0 && dispH > 0 && std::abs((int) (dispW * 9) - (int) (dispH * 16)) <= 16;
        std::string reach;
        if (!sixteenNine)
            reach = "Hybrid reach: this output is not 16:9, so no DLSS ratio lands on a hybrid model size; the"
                    " hybrid stays FP8 here unless a 16:9 resolution is used.";
        else
        {
            const struct { unsigned int w, h, m; } sizes[] = { { 2560, 1440, 960 }, { 3840, 2160, 2160 }, { 5120, 2880, 3840 } };
            for (const auto& sz : sizes)
            {
                if (sz.w > dispW * 2) continue; // above 200% render is not a real option
                const float ratio = (float) sz.w / (float) dispW;
                char buf[160];
                if (std::abs(ratio - 1.0f) < 0.005f)
                    snprintf(buf, sizeof(buf), " %ux%u (M=%u): DLAA / 100%%.", sz.w, sz.h, sz.m);
                else if (ratio < 1.0f)
                    snprintf(buf, sizeof(buf), " %ux%u (M=%u): DLSS ratio %.3f (%s).", sz.w, sz.h, sz.m, ratio,
                             std::abs(ratio - 0.6667f) < 0.01f ? "Quality" : std::abs(ratio - 0.5f) < 0.01f ? "Performance"
                             : std::abs(ratio - 0.58f) < 0.01f ? "Balanced" : "custom ratio override");
                else
                    snprintf(buf, sizeof(buf), " %ux%u (M=%u): model resolution %.0f%% above native (costs more than it saves).",
                             sz.w, sz.h, sz.m, ratio * 100.0f);
                reach += buf;
            }
            reach = reach.empty() ? "Hybrid reach: no hybrid size reachable from this output." : "Hybrid reach from " +
                    std::to_string(dispW) + "x" + std::to_string(dispH) + " (pre-SR: the DLSS render size is the model):" + reach;
        }
        Line(Tone::Info, reach);
    }

    if (scale < 0.999f)
    {
        std::string s;
        if (transfer == 2)
            s = "Enlargement: Matched residual + DLSS. The edit is enlarged by a private DLSS context with motion"
                " vectors, the best enlarger here. If its status line says it cannot engage, the spatial filter"
                " below takes over automatically.";
        else
            s = std::string("Enlargement: matched residual, ") +
                (filter == 1 ? "SGSR1 edge-directed" : filter == 2 ? "FSR1 EASU" : filter == 3 ? "bicubic" : "bilinear") +
                " enlarge of the edit onto the frame's own full-resolution proxy. Native detail is kept exact; only"
                " the edit is upscaled.";
        Line(Tone::Info, s);
        if (style == 1 && scale < 0.9f && glow <= 0.0f && transfer != 2)
            Line(Tone::Warn, "Below 90% with Natural the enlarged tone lift bleeds into a glow on skin. Use Halo"
                             " reduction (0.4, radius 8), Matched residual + DLSS, or 90%.");
        if (scale < 0.75f)
            Line(Tone::Note, "Below 75% fine detail (pores, hair strands, fabric) is visibly lost whatever the enlarger.");
    }
    else
        Line(Tone::Good, "Model at 100%: reference quality, nothing enlarged. 90% measured the same picture for ~15% less.");

    // ---- colour fidelity
    ImGui::SeparatorText("Colour fidelity");
    Line(Tone::Info, std::string("White point: ") +
                         (exposure.everOffered ? "game exposure available (used when Game exposure is the source)."
                                               : "no exposure texture from the game; the paper-white slider or the"
                                                 " scanned exposure sets it.") +
                         " The linear frame is mapped into the model's range with the " +
                         (reversible == 0 ? "soft-knee curve: bright saturated colours are compressed by luminance"
                                            " before the model sees them (neon, path-traced reds)."
                          : reversible >= 3 ? "hybrid proxy curve." : "Neutwo curve, which has no clip point."));
    if (colourLock)
        Line(Tone::Good, "Hue and saturation: identical to the game by construction (RR colour lock). NR contributes"
                         " light and detail only.");
    else if (colourStrength <= 0.0f)
        Line(Tone::Good, "Hue and saturation: identical to the game (Colour strength 0). NR contributes light and detail.");
    else
    {
        std::string s = "Colour: the model may shift hue and saturation (Colour strength " +
                        std::to_string((int) std::lround(colourStrength * 100.0f)) + "%).";
        if (hueStability > 0.0f)
            s += " Hue stability " + Pct(hueStability) + " limits the edit's chroma to a fraction of its luma change.";
        else
            s += " Hue stability is off: strong edits can arrive as colour casts.";
        Line(Tone::Note, s);
    }
    if (style == 1)
        Line(Tone::Info, "Style Natural lifts tone and contrast; Standard is neutral and darker; Cinematic grades.");

    if (config->DlssNrDriftMeter.value_or_default())
    {
        if (drift.valid)
        {
            char buf[256];
            const float lumaPct = (drift.lumaRatio - 1.0f) * 100.0f;
            const float satPct = drift.saturationOriginal > 1e-4f
                                     ? (drift.saturationResult / drift.saturationOriginal - 1.0f) * 100.0f
                                     : 0.0f;
            const double age = DlssNr::Drift::AgeSeconds();
            const bool stale = age > 0.5 || !config->DlssNrApplyModel.value_or_default();
            char when[64];
            if (!stale)
                snprintf(when, sizeof(when), "Measured now");
            else if (age < 3600.0)
                snprintf(when, sizeof(when), "Last measured %.0f s ago, not sampling now", age);
            else
                snprintf(when, sizeof(when), "Last measured earlier, not sampling now");
            snprintf(buf, sizeof(buf),
                     "%s (NR result vs original, %d samples): brightness %+.1f%%, saturation %+.1f%%,"
                     " mean hue shift %.1f deg.",
                     when, (int) drift.samples, lumaPct, satPct, drift.hueDeltaDeg);
            Tone t = Tone::Good;
            if (std::fabs(satPct) > 8.0f || drift.hueDeltaDeg > 4.0f)
                t = Tone::Warn;
            else if (std::fabs(satPct) > 3.0f || drift.hueDeltaDeg > 1.5f || std::fabs(lumaPct) > 8.0f)
                t = Tone::Note;
            if (stale)
                t = Tone::Info;
            Line(t, buf);
            Line(Tone::Info, "Read it as: brightness is what Natural's tone lift does on purpose; saturation loss or a hue"
                             " shift above a couple of degrees is drift. Colour lock / Colour strength 0 remove it,"
                             " Hue stability limits it.");
        }
        else
            Line(Tone::Info, "Measured drift: waiting for samples (a few frames after NR starts).");
    }
    else
        Line(Tone::Info, "Colour drift meter is off.");

    // ---- warnings and suggestions
    ImGui::SeparatorText("Suggestions");
    if (transfer == 2 && placement.beforeUpscale)
        Line(Tone::Warn, "Matched residual + DLSS cannot engage before the upscaler (pre-SR). It falls back to the spatial"
                         " filter here; it works on the RR route and after-upscale placements.");
    if (placement.finished && state.hdrOutputActive)
        Line(Tone::Warn, "Finished picture under HDR output: expect specular shine and neon boil. The RR route keeps colours"
                         " and avoids it.");
    if (config->DlssNrPreset.value_or_default() == 0)
        Line(Tone::Info, "Model preset hint is 0 (OptiScaler default). ShortFuse's injector runs 3; it is untested here and"
                         " costs nothing per frame. Compare 3 at the same spot.");
    if (passes > 1)
        Line(Tone::Note, "Multipass multiplies the model cost per pass; keep it to 1 unless the look demands it.");
    if (rr && !dedicatedRr)
        Line(Tone::Note, "For latency on RR: tick the Dedicated RR route and use its own slider (90% is the sweet spot).");
    if (scale >= 0.999f && ms.has_value() && ms.value() > 4.0)
        Line(Tone::Info, "For less latency: RR/model resolution 90% first, then 80% with Halo reduction or Matched residual +"
                         " DLSS; use Fit to land on a cheap token class.");
    {
        bool meter = config->DlssNrDriftMeter.value_or_default();
        if (ImGui::Checkbox("Colour drift meter", &meter))
        {
            config->DlssNrDriftMeter = meter;
            DlssNr::Drift::Reset();
        }
        HelpMarker("One sample per 32x32 pixels of the frame before and after NR, read back four frames later and"
                   "\naveraged. Negligible cost; off if you want the resolve untouched.");
    }
}
} // namespace DlssNr::MenuSections
