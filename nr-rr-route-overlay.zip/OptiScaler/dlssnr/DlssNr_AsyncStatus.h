#pragma once
#include <mutex>
#include <string>

// The ASYNC NR status line, for the menu.
namespace DlssNr::AsyncStatus
{
inline std::mutex& Mutex() { static std::mutex m; return m; }
inline std::string& Stored() { static std::string s; return s; }
inline void Set(const std::string& s) { std::lock_guard lock(Mutex()); Stored() = s; }
inline std::string Get() { std::lock_guard lock(Mutex()); return Stored(); }
} // namespace DlssNr::AsyncStatus
