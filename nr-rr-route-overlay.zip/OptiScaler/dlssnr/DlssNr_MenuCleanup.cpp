#include "pch.h"

#include "DlssNr.h"
#include "DlssNr_MenuSections.h"
#include <Config.h>
#include <menu/menu_common.h>
#include <algorithm>

namespace DlssNr::MenuSections
{
namespace
{
// Commits on release, like the model sliders: these constants are read every frame, so a live drag
// would be fine functionally, but committing on release keeps Save INI from chasing the mouse.
template <typename Option>
bool CleanupSlider(const char* label, Option* option, float mn, float mx, float def, const char* fmt = "%.2f")
{
    float value = option->value_or_default();
    bool changed = false;
    if (ImGui::SliderFloat(label, &value, mn, mx, fmt))
    {
        *option = std::clamp(value, mn, mx);
        changed = true;
    }
    if (ArrowNudge(&value, (mx - mn) / 40.0f, mn, mx))
    {
        *option = std::clamp(value, mn, mx);
        changed = true;
    }
    if (ResetButton(label))
    {
        *option = def;
        changed = true;
    }
    return changed;
}
} // namespace

void RenderCleanup(Config* config, float menuResScale)
{
    ImGui::TextWrapped("Corrections on NR's edit before it is composed. All neutral by default; each one costs a"
                       " few texture reads per pixel only while it is on.");

    CleanupSlider("Halo reduction", &config->DlssNrGlowSuppression, 0.0f, 1.0f, 0.0f);
    HelpMarker("Subtracts the broad, positive part of the edit around each pixel: the bleed that reads as glow"
               "\non skin at reduced model resolution. Detail finer than the radius is kept.");
    CleanupSlider("Halo radius", &config->DlssNrGlowRadius, 2.0f, 24.0f, 8.0f, "%.0f px");
    HelpMarker("The scale that separates detail from glow, in model-input pixels: brightening narrower than"
               "\nthe radius is kept as detail, wider brightening is treated as glow and reduced. Small radius"
               "\n= aggressive (only fine detail survives); large radius = gentle (only wide soft glow goes)."
               "\nDoes nothing while Halo reduction is 0.");
    CleanupSlider("Halo guard", &config->DlssNrHaloGuard, 0.0f, 1.0f, 0.0f);
    HelpMarker("Damps edits that push against the frame's own contrast at an edge: overshoot rings.");
    CleanupSlider("Hue stability", &config->DlssNrHueStability, 0.0f, 1.0f, 0.0f);
    HelpMarker("Limits the edit's colour to a fraction of its brightness change, so a strong edit"
               "\ncannot arrive as a colour cast. 0 = off.");
    CleanupSlider("Shadow strength", &config->DlssNrResidualShadow, 0.0f, 2.0f, 1.0f);
    CleanupSlider("Light strength", &config->DlssNrResidualLight, 0.0f, 2.0f, 1.0f);
    HelpMarker("Separate strengths for the edits that darken and the edits that brighten. 1 = unchanged.");

    if (ImGui::Button("Reset clean-up"))
    {
        config->DlssNrGlowSuppression = 0.0f;
        config->DlssNrGlowRadius = 8.0f;
        config->DlssNrHaloGuard = 0.0f;
        config->DlssNrHueStability = 0.0f;
        config->DlssNrResidualShadow = 1.0f;
        config->DlssNrResidualLight = 1.0f;
    }

    ImGui::SeparatorText("Faces and skin");
    // The same settings the Model and Blend sections expose, gathered here. NVIDIA's own mask and
    // skin structure are model inputs (a change rebuilds the model once); the colour-based filter is
    // applied by the resolve to the final edit.
    {
        bool mask = config->DlssNrAutoMask.value_or_default();
        if (ImGui::Checkbox("Protect faces and skin (model mask)##cleanup", &mask))
            config->DlssNrAutoMask = mask;
        HelpMarker("NVIDIA's model-based skin selection. Same setting as Auto skin mask under Pass 1.");

        static float pendingSkin = -2.0f;
        float skin = pendingSkin > -2.0f ? pendingSkin : config->DlssNrSkinStructure.value_or_default();
        static bool skinByKey = false;
        if (ImGui::SliderFloat("Skin detail strength##cleanup", &skin, -1.0f, 2.0f, "%.2f"))
            pendingSkin = skin;
        const bool skinReleased = ImGui::IsItemDeactivatedAfterEdit();
        if (ArrowNudge(&skin, 0.05f, -1.0f, 2.0f))
        {
            pendingSkin = skin;
            skinByKey = true;
        }
        if (pendingSkin > -2.0f && (skinReleased || (skinByKey && !ArrowKeyHeld())))
        {
            config->DlssNrSkinStructure = std::clamp(pendingSkin, -1.0f, 2.0f);
            pendingSkin = -2.0f;
            skinByKey = false;
        }
        if (ResetButton("Skin detail strength##cleanup"))
        {
            config->DlssNrSkinStructure = -1.0f;
            pendingSkin = -2.0f;
            skinByKey = false;
        }
        HelpMarker("NVIDIA's skin structure input. -1 follows Local structure (the model's default), 0 turns"
                   "\nskin detail off, up to 2 pushes it. Same setting as Skin structure under Pass 1.");

        bool filter = config->DlssNrSkinProtection.value_or_default();
        if (ImGui::Checkbox("Separate skin / environment strength (colour mask)##cleanup", &filter))
            config->DlssNrSkinProtection = filter;
        HelpMarker("Colour-based skin selection applied to the final edit. Not the model's mask.");
        ImGui::BeginDisabled(!filter);
        const auto unit = [](const char* label, auto& option)
        {
            float v = option.value_or_default();
            if (ImGui::SliderFloat(label, &v, 0.0f, 1.0f, "%.2f"))
                option = v;
            if (ArrowNudge(&v, 0.05f, 0.0f, 1.0f))
                option = v;
            if (ResetButton(label))
                option = 1.0f;
        };
        unit("Skin detail / lighting##cleanup", config->DlssNrSkinDetail);
        unit("Skin colour##cleanup", config->DlssNrSkinColour);
        unit("Environment detail / lighting##cleanup", config->DlssNrEnvironmentDetail);
        unit("Environment colour##cleanup", config->DlssNrEnvironmentColour);
        bool preview = config->DlssNrShowSkinMask.value_or_default();
        if (ImGui::Checkbox("Preview colour mask##cleanup", &preview))
            config->DlssNrShowSkinMask = preview;
        ImGui::EndDisabled();
    }
}
} // namespace DlssNr::MenuSections
