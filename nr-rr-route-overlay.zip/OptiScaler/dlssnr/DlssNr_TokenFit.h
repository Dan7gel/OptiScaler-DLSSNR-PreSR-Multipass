#pragma once

// Token-aware model size.
//
// The NR model tiles its input into tokens and its cost follows the token count, not the pixel count.
// The tile size it picks depends on the input dimensions, so neighbouring working scales can differ a
// lot in tokens (a 60% model has been measured at twice the tokens of a 50% one). A fit probes the
// scales above the configured one, one frame each, reads the token grid every launch actually used
// (through the NvAPI kernel hook), and settles on the largest scale that costs no more tokens than the
// configured scale: more pixels for the same cost. DX12 only; the result is written into the route's
// working-scale setting and shows in the menu.

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace DlssNr::TokenFit
{
struct Row
{
    float scale;
    uint32_t width;
    uint32_t height;
    uint64_t tokens;
    uint32_t dims[2];
};

struct Snapshot
{
    bool active = false;
    bool rayReconstruction = false;
    std::string status;
    std::vector<Row> rows;
    float applied = 0.0f;
};

// Start probing [baseScale, maxScale] in `step` increments for the given route.
void Request(bool rayReconstruction, float baseScale, float maxScale, float step);
void Cancel();
// Scale to run this frame while a fit for the route is active; nullopt otherwise.
std::optional<float> ScaleOverride(bool rayReconstruction);
// Called after every successful DX12 model evaluation. Returns the settled scale once the fit is done.
std::optional<float> OnModelEvaluated(bool rayReconstruction, float scaleUsed, uint32_t width, uint32_t height);
Snapshot GetSnapshot();
} // namespace DlssNr::TokenFit
