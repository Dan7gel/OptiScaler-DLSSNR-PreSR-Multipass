#pragma once

#include <shaders/dlssnr/DlssNr_Common.h>
#include <chrono>
#include <mutex>

// The colour drift meter's latest reading, smoothed, for the Advisor.
namespace DlssNr::Drift
{
inline std::mutex& Mutex()
{
    static std::mutex m;
    return m;
}

inline DlssNrDriftResult& Stored()
{
    static DlssNrDriftResult r;
    return r;
}

inline std::chrono::steady_clock::time_point& LastPublish()
{
    static std::chrono::steady_clock::time_point t {};
    return t;
}

// Seconds since the last sample arrived; large when the resolve is not sampling (model not applied).
inline double AgeSeconds()
{
    std::lock_guard lock(Mutex());
    if (LastPublish() == std::chrono::steady_clock::time_point {})
        return 1e9;
    return std::chrono::duration<double>(std::chrono::steady_clock::now() - LastPublish()).count();
}

inline void Publish(const DlssNrDriftResult& sample)
{
    std::lock_guard lock(Mutex());
    LastPublish() = std::chrono::steady_clock::now();
    auto& s = Stored();
    if (!s.valid)
    {
        s = sample;
        return;
    }
    // Exponential smoothing so the numbers can be read while the picture moves.
    constexpr float k = 0.15f;
    s.lumaRatio += (sample.lumaRatio - s.lumaRatio) * k;
    s.saturationOriginal += (sample.saturationOriginal - s.saturationOriginal) * k;
    s.saturationResult += (sample.saturationResult - s.saturationResult) * k;
    s.hueDeltaDeg += (sample.hueDeltaDeg - s.hueDeltaDeg) * k;
    s.samples = sample.samples;
    s.valid = true;
}

// The Advisor panel stamps this every frame it is drawn; the colour-drift meter (its measurement:
// stats writes in the resolve, a readback copy, a CPU read) runs only while the Advisor is open, so
// nothing measures for a collapsed panel.
inline std::chrono::steady_clock::time_point& AdvisorSeen()
{
    static std::chrono::steady_clock::time_point t {};
    return t;
}
inline void NoteAdvisorVisible() { AdvisorSeen() = std::chrono::steady_clock::now(); }
inline bool AdvisorVisible()
{
    return AdvisorSeen() != std::chrono::steady_clock::time_point {} &&
           std::chrono::steady_clock::now() - AdvisorSeen() < std::chrono::milliseconds(500);
}

inline DlssNrDriftResult Get()
{
    std::lock_guard lock(Mutex());
    return Stored();
}

inline void Reset()
{
    std::lock_guard lock(Mutex());
    Stored() = DlssNrDriftResult {};
    LastPublish() = std::chrono::steady_clock::time_point {};
}
} // namespace DlssNr::Drift
