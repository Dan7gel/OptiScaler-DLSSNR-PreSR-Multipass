#include "pch.h"
#include "DlssNr_TokenFit.h"
#include "DlssNrNative.h"

#include <algorithm>
#include <cmath>
#include <mutex>

namespace DlssNr::TokenFit
{
namespace
{
struct Fit
{
    bool active = false;
    bool rr = false;
    float base = 0.0f;
    float max = 0.0f;
    float step = 0.05f;
    float current = 0.0f;
    unsigned long long lastSequence = 0;
    std::vector<Row> rows;
    std::string status;
    float applied = 0.0f;
};

std::mutex fitMutex;
Fit fit;

std::string Percent(float scale) { return std::to_string((int) std::lround(scale * 100.0f)) + "%"; }
} // namespace

void Request(bool rayReconstruction, float baseScale, float maxScale, float step)
{
    std::lock_guard<std::mutex> guard(fitMutex);
    fit = Fit {};
    fit.rr = rayReconstruction;
    fit.base = std::clamp(baseScale, 0.25f, 2.0f);
    fit.max = std::clamp(maxScale, fit.base, 2.0f);
    fit.step = std::clamp(step, 0.01f, 0.25f);
    fit.current = fit.base;
    fit.lastSequence = DlssNrNative::Observed().sequence;
    fit.active = fit.max > fit.base + 1e-4f;
    fit.status = fit.active ? "Probing " + Percent(fit.base) + "..."
                            : "Nothing above the configured scale to probe.";
}

void Cancel()
{
    std::lock_guard<std::mutex> guard(fitMutex);
    if (fit.active)
        fit.status = "Cancelled.";
    fit.active = false;
}

std::optional<float> ScaleOverride(bool rayReconstruction)
{
    std::lock_guard<std::mutex> guard(fitMutex);
    if (!fit.active || fit.rr != rayReconstruction)
        return std::nullopt;
    return fit.current;
}

std::optional<float> OnModelEvaluated(bool rayReconstruction, float scaleUsed, uint32_t width, uint32_t height)
{
    std::lock_guard<std::mutex> guard(fitMutex);
    if (!fit.active || fit.rr != rayReconstruction)
        return std::nullopt;
    // A frame still running the previous size, or one where no expansion launch was recorded yet.
    if (std::fabs(scaleUsed - fit.current) > 1e-4f)
        return std::nullopt;
    const auto observed = DlssNrNative::Observed();
    if (observed.sequence == fit.lastSequence || observed.tokens == 0)
        return std::nullopt;
    fit.lastSequence = observed.sequence;
    fit.rows.push_back({ fit.current, width, height, observed.tokens, { observed.dims[0], observed.dims[1] } });

    const float next = fit.current + fit.step;
    if (next <= fit.max + 1e-4f)
    {
        fit.current = std::min(next, fit.max);
        fit.status = "Probing " + Percent(fit.current) + "... (" + std::to_string(fit.rows.size()) +
                     " sizes measured)";
        return std::nullopt;
    }

    // Settle: the largest scale that costs no more tokens than the configured one. Token counts are
    // not monotonic in scale, so every measured size is considered, not just the ones before a jump.
    fit.active = false;
    const uint64_t baseTokens = fit.rows.front().tokens;
    const Row* best = &fit.rows.front();
    const Row* cheapest = &fit.rows.front();
    for (const auto& row : fit.rows)
    {
        if (row.tokens <= baseTokens && row.scale > best->scale)
            best = &row;
        if (row.tokens < cheapest->tokens || (row.tokens == cheapest->tokens && row.scale > cheapest->scale))
            cheapest = &row;
    }
    fit.applied = best->scale;
    fit.status = "Applied " + Percent(best->scale) + ": M=" + std::to_string(best->tokens) + ", the token class of " +
                 Percent(fit.base) + ". Save the INI to keep it.";
    if (cheapest->tokens < baseTokens)
        fit.status += " Cheapest measured: " + Percent(cheapest->scale) + " (M=" +
                      std::to_string(cheapest->tokens) + ").";
    return best->scale;
}

Snapshot GetSnapshot()
{
    std::lock_guard<std::mutex> guard(fitMutex);
    return { fit.active, fit.rr, fit.status, fit.rows, fit.applied };
}
} // namespace DlssNr::TokenFit
