#pragma once

// Dedicated Ray Reconstruction route, restored from the v0.7.1 "Apply after Ray Reconstruction" design.
//
// RR already denoises and upscales. With ApplyAfterRR on, a native RR feature ignores the shared
// placement (RunBeforeSR / DeferredDLSS / ResidualAcrossRR / FinishedPicture) and runs the ordinary
// post-upscale NR pass once on RR's clean output -- before frame generation -- with its own pass
// count and model working scale. FinishedPicture still applies on this route (NR on the finished
// picture instead of right after RR). SR features are not affected, so one INI can hold pre-SR
// settings for SR games and post-RR settings for RR games. Off keeps the v0.8.x shared behaviour.
// Native Vulkan: placement and pass/scale selection follow this route; its finished-picture
// presentation stage still honours FinishedPicture on its own.

#include <Config.h>
#include "DlssNr_Placement.h"
#include "DlssNrFeature_Dx12.h"
#include <algorithm>
#include <cmath>

namespace DlssNr
{
inline bool DedicatedRrRoute(const ::Config& cfg, bool rayReconstruction)
{
    return rayReconstruction && cfg.DlssNrApplyAfterRR.value_or_default();
}

// Placement for one feature. The dedicated RR route never runs before RR and never uses the separate-edit
// path; it applies either right after RR+SR (linear buffer, white point from the frame) or, with
// FinishedPicture on, to the finished display-referred picture at presentation -- the same image a
// ReShade-side injector sees, so tone and colour match the game's own output without any white-point
// estimate. Otherwise the shared keys apply.
// RR route + finished picture, light form: the model runs at the RR seam inside the frame and only its
// edit is applied to the finished picture at presentation. Plain placement at the seam; the late
// compose picks the captured edit up as a residual-only slot.
inline bool RrFinishedLight(const ::Config& cfg, bool rayReconstruction)
{
    if (!cfg.DlssNrFinishedPicture.value_or_default() || !cfg.DlssNrRRFinishedLight.value_or_default())
        return false;
    if (DedicatedRrRoute(cfg, rayReconstruction))
        return true;
    // After-upscale SR features (pre-SR off) would otherwise run the whole model at presentation too;
    // pre-SR SR features keep their existing deferred form (private SR reconstructs the edit).
    return !rayReconstruction && !cfg.DlssNrRunBeforeSr.value_or_default() &&
           !cfg.DlssNrDeferredDlss.value_or_default();
}

inline Placement ResolvePlacementFor(const ::Config& cfg, bool rayReconstruction)
{
    if (RrFinishedLight(cfg, rayReconstruction))
        return { false, false, false };
    if (DedicatedRrRoute(cfg, rayReconstruction))
        return { false, false, cfg.DlssNrFinishedPicture.value_or_default() };
    return ResolvePlacement(cfg.DlssNrRunBeforeSr.value_or_default(), cfg.DlssNrDeferredDlss.value_or_default(),
                            cfg.DlssNrResidualAcrossRr.value_or_default(),
                            cfg.DlssNrFinishedPicture.value_or_default());
}

// Model working scale for one feature: finite and clamped to the supported 0.25..2.0 range.
inline float ModelWorkingScale(const ::Config& cfg, bool rayReconstruction)
{
    const bool dedicated = DedicatedRrRoute(cfg, rayReconstruction);
    float scale = dedicated ? cfg.DlssNrRRWorkingScale.value_or_default() : cfg.DlssNrWorkingScale.value_or_default();
    if (!std::isfinite(scale))
        scale = dedicated ? 0.5f : 1.0f;
    return std::clamp(scale, 0.25f, 2.0f);
}

// Model pass count for one feature, clamped to the configured ceiling.
inline unsigned int ModelPasses(const ::Config& cfg, bool rayReconstruction)
{
    const unsigned int requested = DedicatedRrRoute(cfg, rayReconstruction) ? cfg.DlssNrRRPasses.value_or_default()
                                                                             : cfg.DlssNrPasses.value_or_default();
    return std::clamp(requested, 1u, cfg.DlssNrUnlockPasses.value_or_default() ? MaxPassCount : DefaultMaxPassCount);
}
} // namespace DlssNr
