#pragma once

// Dedicated Ray Reconstruction route, restored from the v0.7.1 "Apply after Ray Reconstruction" design.
//
// RR already denoises and upscales. With ApplyAfterRR on, a native RR feature ignores the shared
// placement (RunBeforeSR / DeferredDLSS / ResidualAcrossRR / FinishedPicture) and runs the ordinary
// post-upscale NR pass once on RR's clean output -- before frame generation -- with its own pass
// count and model working scale. SR features are not affected, so one INI can hold pre-SR settings
// for SR games and post-RR settings for RR games. Off keeps the v0.8.x shared behaviour.
// Native Vulkan: placement and pass/scale selection follow this route; its finished-picture
// presentation stage still honours FinishedPicture on its own.

#include <Config.h>
#include "DlssNr_Placement.h"
#include "DlssNrFeature_Dx12.h"
#include <algorithm>
#include <cmath>

namespace DlssNr
{
inline bool DedicatedRrRoute(const ::Config& cfg, bool rayReconstruction)
{
    return rayReconstruction && cfg.DlssNrApplyAfterRR.value_or_default();
}

// Placement for one feature: the dedicated RR route is plain post-upscale, otherwise the shared keys apply.
inline Placement ResolvePlacementFor(const ::Config& cfg, bool rayReconstruction)
{
    if (DedicatedRrRoute(cfg, rayReconstruction))
        return { false, false, false };
    return ResolvePlacement(cfg.DlssNrRunBeforeSr.value_or_default(), cfg.DlssNrDeferredDlss.value_or_default(),
                            cfg.DlssNrResidualAcrossRr.value_or_default(),
                            cfg.DlssNrFinishedPicture.value_or_default());
}

// Model working scale for one feature: finite and clamped to the supported 0.25..2.0 range.
inline float ModelWorkingScale(const ::Config& cfg, bool rayReconstruction)
{
    const bool dedicated = DedicatedRrRoute(cfg, rayReconstruction);
    float scale = dedicated ? cfg.DlssNrRRWorkingScale.value_or_default() : cfg.DlssNrWorkingScale.value_or_default();
    if (!std::isfinite(scale))
        scale = dedicated ? 0.5f : 1.0f;
    return std::clamp(scale, 0.25f, 2.0f);
}

// Model pass count for one feature, clamped to the configured ceiling.
inline unsigned int ModelPasses(const ::Config& cfg, bool rayReconstruction)
{
    const unsigned int requested = DedicatedRrRoute(cfg, rayReconstruction) ? cfg.DlssNrRRPasses.value_or_default()
                                                                             : cfg.DlssNrPasses.value_or_default();
    return std::clamp(requested, 1u, cfg.DlssNrUnlockPasses.value_or_default() ? MaxPassCount : DefaultMaxPassCount);
}
} // namespace DlssNr
