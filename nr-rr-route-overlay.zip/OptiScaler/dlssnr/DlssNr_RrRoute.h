#pragma once

// Dedicated Ray Reconstruction route, restored from the v0.7.1 "Apply after Ray Reconstruction" design.
//
// RR already denoises and upscales. With ApplyAfterRR on, a native RR feature ignores the shared
// placement (RunBeforeSR / DeferredDLSS / ResidualAcrossRR / FinishedPicture) and runs the ordinary
// post-upscale NR pass once on RR's clean output -- before frame generation -- with its own pass
// count and model working scale. FinishedPicture still applies on this route (NR on the finished
// picture instead of right after RR). SR features are not affected, so one INI can hold pre-SR
// settings for SR games and post-RR settings for RR games. Off keeps the v0.8.x shared behaviour.
// Native Vulkan: placement and pass/scale selection follow this route; its finished-picture
// presentation stage still honours FinishedPicture on its own.

#include <Config.h>
#include "DlssNr_Placement.h"
#include "DlssNrFeature_Dx12.h"
#include <algorithm>
#include <cmath>

namespace DlssNr
{
inline bool DedicatedRrRoute(const ::Config& cfg, bool rayReconstruction)
{
    return rayReconstruction && cfg.DlssNrApplyAfterRR.value_or_default();
}

// Placement for one feature. The dedicated RR route never runs before RR and never uses the separate-edit
// path; it applies either right after RR+SR (linear buffer, white point from the frame) or, with
// FinishedPicture on, to the finished display-referred picture at presentation -- the same image a
// ReShade-side injector sees, so tone and colour match the game's own output without any white-point
// estimate. Otherwise the shared keys apply.
// RR route + finished picture, light form: the model runs at the RR seam inside the frame and only its
// edit is applied to the finished picture at presentation. Plain placement at the seam; the late
// compose picks the captured edit up as a residual-only slot.
// The finished picture's route settings, applied while the box is on (SR features). One place, called
// from the frame path and from the menu, so the INI, a stale tick or a slider cannot leave the route in
// another state: model at the game's render size from the clean frame, matched residual, box shrink,
// bilinear enlarge, Neutwo proxy + composed, game exposure, halo reduction 0.70 at 8 px, guard on.
inline void EnforceFinishedRoute(::Config& cfg, float renderRatio)
{
    if (!cfg.DlssNrFinishedPicture.value_or_default())
        return;
    cfg.DlssNrRunBeforeSr = false;
    cfg.DlssNrDeferredDlss = false;
    cfg.DlssNrResidualAcrossRr = false;
    // The model size through the Model resolution slider itself (the proven path): the game's render
    // ratio, 50% at 4K Performance, 67% at Quality; 50% when the ratio is not known yet.
    cfg.DlssNrModelAtRenderRes = false;
    const float ratio = (renderRatio > 0.2f && renderRatio <= 1.0f) ? renderRatio : 0.5f;
    cfg.DlssNrWorkingScale = std::round(ratio * 100.0f) / 100.0f;
    cfg.DlssNrTransfer = 2;
    cfg.DlssNrInputDownscaler = -1;
    cfg.DlssNrEnlargeFilter = 0;
    cfg.DlssNrReversibleMode = 1;
    cfg.DlssNrWhitePointSource = 1;
    cfg.DlssNrGlowSuppression = 0.7f;
    cfg.DlssNrGlowRadius = 8.0f;
}

inline bool RrFinishedLight(const ::Config& cfg, bool rayReconstruction)
{
    // The heavy form (whole model on the finished picture at presentation) is retired: its model sees
    // the post-processed frame and reacts to motion blur. The finished picture always takes the light form.
    if (!cfg.DlssNrFinishedPicture.value_or_default())
        return false;
    if (DedicatedRrRoute(cfg, rayReconstruction))
        return true;
    // SR features (no RR): after the upscaler only. The finished picture is not combined with pre-SR
    // (the raw render's noise would reach the screen unfiltered); with pre-SR on, the box is ignored.
    return !rayReconstruction && !cfg.DlssNrRunBeforeSr.value_or_default() && !cfg.DlssNrDeferredDlss.value_or_default();
}

inline Placement ResolvePlacementFor(const ::Config& cfg, bool rayReconstruction)
{
    if (RrFinishedLight(cfg, rayReconstruction))
        return { false, false, false };
    // Pre-SR with the finished box on: plain pre-SR (the box is ignored on this route).
    if (!rayReconstruction && cfg.DlssNrRunBeforeSr.value_or_default() && !cfg.DlssNrDeferredDlss.value_or_default())
        return { true, false, false };
    if (DedicatedRrRoute(cfg, rayReconstruction))
        return { false, false, cfg.DlssNrFinishedPicture.value_or_default() };
    return ResolvePlacement(cfg.DlssNrRunBeforeSr.value_or_default(), cfg.DlssNrDeferredDlss.value_or_default(),
                            cfg.DlssNrResidualAcrossRr.value_or_default(),
                            cfg.DlssNrFinishedPicture.value_or_default());
}

// Model working scale for one feature: finite and clamped to the supported 0.25..2.0 range.
inline float ModelWorkingScale(const ::Config& cfg, bool rayReconstruction)
{
    const bool dedicated = DedicatedRrRoute(cfg, rayReconstruction);
    float scale = dedicated ? cfg.DlssNrRRWorkingScale.value_or_default() : cfg.DlssNrWorkingScale.value_or_default();
    if (!std::isfinite(scale))
        scale = dedicated ? 0.5f : 1.0f;
    return std::clamp(scale, 0.25f, 2.0f);
}

// Model pass count for one feature, clamped to the configured ceiling.
inline unsigned int ModelPasses(const ::Config& cfg, bool rayReconstruction)
{
    const unsigned int requested = DedicatedRrRoute(cfg, rayReconstruction) ? cfg.DlssNrRRPasses.value_or_default()
                                                                             : cfg.DlssNrPasses.value_or_default();
    return std::clamp(requested, 1u, cfg.DlssNrUnlockPasses.value_or_default() ? MaxPassCount : DefaultMaxPassCount);
}
} // namespace DlssNr
