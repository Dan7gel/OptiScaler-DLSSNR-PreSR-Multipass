#pragma once
#include <string>
namespace DlssNrNative {
void* WrapNvapi(unsigned id,void* original);
void SetEnabled(bool enabled);
std::string Status();
// Token grid of the most recent model launch (any precision). sequence advances with every observed
// expansion launch; tokens == dims[0] * dims[1] is the model's cost unit.
struct ObservedShape { unsigned long long sequence; unsigned long long tokens; unsigned dims[2]; };
ObservedShape Observed();
}
