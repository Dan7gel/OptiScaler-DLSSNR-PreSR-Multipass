#include "pch.h"

#include "DlssNr.h"
#include "DlssNr_MenuSections.h"
#include <Config.h>
#include <menu/menu_common.h>
#include <algorithm>

namespace DlssNr::MenuSections
{
void RenderTemporal(Config* config, float menuResScale)
{
    (void) menuResScale;
    ImGui::TextWrapped("Run the model less often. Every frame is today's behaviour. Reuse: the model runs every N-th"
                       " rendered frame and the frames between get its last edit moved along the game's motion vectors,"
                       " with depth and colour checks and a soft fill where they fail. Async is reserved for the next"
                       " build. DX12, linear routes and the RR route; not the finished picture.");

    ImGui::PushItemWidth(240.0f);
    {
        const char* modes[] = { "Every frame", "Reuse: model every N-th frame", "Async (next build)" };
        int mode = (int) std::min(config->DlssNrTemporalMode.value_or_default(), 2u);
        if (ImGui::Combo("Temporal mode", &mode, modes, IM_ARRAYSIZE(modes)))
            config->DlssNrTemporalMode = (uint32_t) mode;
        if (mode == 2)
            ImGui::TextWrapped("Async is not in this build yet; it behaves as Every frame until then.");
    }

    const bool reuse = config->DlssNrTemporalMode.value_or_default() == 1;
    ImGui::BeginDisabled(!reuse);
    {
        int every = (int) std::clamp(config->DlssNrTemporalEvery.value_or_default(), 2u, 8u);
        ImGui::SliderInt("##TemporalEvery", &every, 2, 8, "%d", ImGuiSliderFlags_AlwaysClamp);
        const bool everyChanged = ImGui::IsItemDeactivatedAfterEdit();
        if (ArrowNudgeInt(&every, 1, 2, 8) || everyChanged)
            config->DlssNrTemporalEvery = (uint32_t) every;
        ImGui::SameLine();
        ImGui::Text("Model every N frames");
        HelpMarker("2 halves the average model cost; 3 and 4 go further, with more visible reuse on fast motion.");

        float depthTol = config->DlssNrTemporalDepthTol.value_or_default();
        if (ImGui::SliderFloat("##TemporalDepth", &depthTol, 0.01f, 0.3f, "%.3f", ImGuiSliderFlags_AlwaysClamp))
            config->DlssNrTemporalDepthTol = depthTol;
        if (ArrowNudge(&depthTol, 0.005f, 0.01f, 0.3f))
            config->DlssNrTemporalDepthTol = depthTol;
        ImGui::SameLine();
        ImGui::Text("Depth tolerance");
        if (ResetButton("Depth tolerance"))
            config->DlssNrTemporalDepthTol = 0.05f;
        HelpMarker("Relative depth difference allowed between the frame and the reprojected point. Larger keeps more"
                   "\nreused edit at silhouettes; smaller rejects more (cleaner edges, more fill).");

        float colourTol = config->DlssNrTemporalColourTol.value_or_default();
        if (ImGui::SliderFloat("##TemporalColour", &colourTol, 0.02f, 0.3f, "%.3f", ImGuiSliderFlags_AlwaysClamp))
            config->DlssNrTemporalColourTol = colourTol;
        if (ArrowNudge(&colourTol, 0.005f, 0.02f, 0.3f))
            config->DlssNrTemporalColourTol = colourTol;
        ImGui::SameLine();
        ImGui::Text("Colour tolerance");
        if (ResetButton("Colour tolerance"))
            config->DlssNrTemporalColourTol = 0.08f;
        HelpMarker("Chromaticity difference allowed (luma at twice this). Catches disocclusions the depth test misses,"
                   "\nHUD and transparency.");

        float fill = config->DlssNrTemporalFill.value_or_default();
        if (ImGui::SliderFloat("##TemporalFill", &fill, 0.0f, 1.0f, "%.2f", ImGuiSliderFlags_AlwaysClamp))
            config->DlssNrTemporalFill = fill;
        if (ArrowNudge(&fill, 0.05f, 0.0f, 1.0f))
            config->DlssNrTemporalFill = fill;
        ImGui::SameLine();
        ImGui::Text("Fill strength");
        if (ResetButton("Fill strength"))
            config->DlssNrTemporalFill = 1.0f;
        HelpMarker("Where the reprojection is rejected, this much of a soft (1/16) version of the edit is applied along"
                   "\nthe pixel's own colour, so moving silhouettes do not show a dark rim. 0 = raw frame there.");

        bool jitter = config->DlssNrTemporalJitter.value_or_default();
        if (ImGui::Checkbox("Jitter compensation (pre-SR)", &jitter))
            config->DlssNrTemporalJitter = jitter;
        HelpMarker("Before the upscaler the frame is shifted by a sub-pixel jitter every frame; the stored edit is moved"
                   "\nby the difference. Turn off if fine detail shimmers on reused frames.");
    }
    ImGui::EndDisabled();
    ImGui::PopItemWidth();
}
} // namespace DlssNr::MenuSections
