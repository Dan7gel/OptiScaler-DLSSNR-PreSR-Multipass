#include "pch.h"

#include "DlssNr.h"
#include "DlssNr_MenuSections.h"
#include "DlssNr_AsyncStatus.h"
#include <Config.h>
#include <menu/menu_common.h>
#include <algorithm>

namespace DlssNr::MenuSections
{
void RenderTemporal(Config* config, float menuResScale)
{
    (void) menuResScale;
    ImGui::TextWrapped("The model runs on its own high-priority GPU queue while the game renders the next frame, so"
                       " the frame never waits for it. Every frame is the original plus the last finished pass's edit"
                       " moved along the game's motion vectors, with depth and colour checks, a searched fill and"
                       " smoothing where they fail. Latency drops by about the model's time; the edit is one or two"
                       " frames old. DX12, linear routes and the RR route; not the finished picture.");

    bool on = config->DlssNrTemporalMode.value_or_default() == 2;
    if (ImGui::Checkbox("Enable ASYNC NR##asyncEnable", &on))
        config->DlssNrTemporalMode = on ? 2u : 0u;
    HelpMarker("Off: the model runs on the frame, as before. On: background queue. A change restarts NR's history;"
               "\nthe first one or two frames after switching on are the plain frame.");

    if (on)
    {
        const std::string status = DlssNr::AsyncStatus::Get();
        if (!status.empty())
            ImGui::TextWrapped("%s", status.c_str());
    }

    ImGui::BeginDisabled(!on);
    ImGui::PushItemWidth(240.0f);
    {
        int age = (int) std::min(config->DlssNrAsyncMaxAge.value_or_default(), 8u);
        // Committed immediately: a live constant, no rebuild, so the slider follows the mouse.
        if (ImGui::SliderInt("##AsyncMaxAge", &age, 0, 8, age == 0 ? "never wait" : "%d", ImGuiSliderFlags_AlwaysClamp))
            config->DlssNrAsyncMaxAge = (uint32_t) age;
        if (ArrowNudgeInt(&age, 1, 0, 8))
            config->DlssNrAsyncMaxAge = (uint32_t) age;
        ImGui::SameLine();
        ImGui::Text("Max pass age (frames)");
        if (ResetButton("Max pass age"))
            config->DlssNrAsyncMaxAge = 0u;
        HelpMarker("0 = the game's queue never waits for a pass; the edit on screen simply gets older until the"
                   "\nnext one lands. N = wait once the visible pass is N frames old. Any wait on the game's queue"
                   "\nalso stalls its frame generation, so leave this at 0 with DLSS-G / MFG.");

        float depthTol = config->DlssNrTemporalDepthTol.value_or_default();
        if (ImGui::SliderFloat("##TemporalDepth", &depthTol, 0.01f, 0.3f, "%.3f", ImGuiSliderFlags_AlwaysClamp))
            config->DlssNrTemporalDepthTol = depthTol;
        if (ArrowNudge(&depthTol, 0.005f, 0.01f, 0.3f))
            config->DlssNrTemporalDepthTol = depthTol;
        ImGui::SameLine();
        ImGui::Text("Depth tolerance");
        if (ResetButton("Depth tolerance"))
            config->DlssNrTemporalDepthTol = 0.05f;
        HelpMarker("Relative depth difference allowed between the frame and the reprojected point. Larger keeps more"
                   "\nedit at silhouettes; smaller rejects more (cleaner edges, more fill).");

        float colourTol = config->DlssNrTemporalColourTol.value_or_default();
        if (ImGui::SliderFloat("##TemporalColour", &colourTol, 0.02f, 0.3f, "%.3f", ImGuiSliderFlags_AlwaysClamp))
            config->DlssNrTemporalColourTol = colourTol;
        if (ArrowNudge(&colourTol, 0.005f, 0.02f, 0.3f))
            config->DlssNrTemporalColourTol = colourTol;
        ImGui::SameLine();
        ImGui::Text("Colour tolerance");
        if (ResetButton("Colour tolerance"))
            config->DlssNrTemporalColourTol = 0.08f;
        HelpMarker("Chromaticity difference allowed (luma at twice this). Catches disocclusions the depth test misses,"
                   "\nHUD and transparency.");

        float fill = config->DlssNrTemporalFill.value_or_default();
        if (ImGui::SliderFloat("##TemporalFill", &fill, 0.0f, 1.0f, "%.2f", ImGuiSliderFlags_AlwaysClamp))
            config->DlssNrTemporalFill = fill;
        if (ArrowNudge(&fill, 0.05f, 0.0f, 1.0f))
            config->DlssNrTemporalFill = fill;
        ImGui::SameLine();
        ImGui::Text("Fill strength");
        if (ResetButton("Fill strength"))
            config->DlssNrTemporalFill = 1.0f;
        HelpMarker("Where the reprojection is rejected, this much of a soft (1/16) version of the edit, found on a"
                   "\nmatching surface nearby, is applied along the pixel's own colour. 0 = raw frame there.");

        float blend = config->DlssNrTemporalBlend.value_or_default();
        if (ImGui::SliderFloat("##TemporalBlend", &blend, 0.0f, 0.9f, "%.2f", ImGuiSliderFlags_AlwaysClamp))
            config->DlssNrTemporalBlend = blend;
        if (ArrowNudge(&blend, 0.05f, 0.0f, 0.9f))
            config->DlssNrTemporalBlend = blend;
        ImGui::SameLine();
        ImGui::Text("Pass-to-pass blend");
        if (ResetButton("Pass-to-pass blend"))
            config->DlssNrTemporalBlend = 0.6f;
        HelpMarker("On each pass, how much of the previous pass's edit (moved to the new frame) is kept where the pixel"
                   "\nbarely moved. Stops teeth, nostrils and lips snapping between the model's answers. 0 = off.");

        bool jitter = config->DlssNrTemporalJitter.value_or_default();
        if (ImGui::Checkbox("Jitter compensation (pre-SR)", &jitter))
            config->DlssNrTemporalJitter = jitter;
        HelpMarker("Before the upscaler the frame is shifted by a sub-pixel jitter every frame; the stored edit is moved"
                   "\nby the difference. Turn off if fine detail shimmers.");
    }
    ImGui::PopItemWidth();
    ImGui::EndDisabled();
}
} // namespace DlssNr::MenuSections
