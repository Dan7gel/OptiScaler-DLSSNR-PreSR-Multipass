#include "pch.h"

#include "DlssNr.h"
#include "DlssNr_PipelineUi.h"
#include "DlssNr_Upscaler.h"
#include "DlssNr_MenuSections.h"
#include "DlssNr_Placement.h"
#include "DlssNr_RrRoute.h"
#include "DlssNr_TokenFit.h"
#include "DlssNrNative.h"
#include <Config.h>
#include <menu/menu_common.h>
#include <algorithm>
#include <cmath>

namespace DlssNr
{

void RenderMenu(Config* config, float menuResScale)
{
    using namespace MenuSections;
    ImGui::Spacing();
    if (auto header = ScopedCollapsingHeader("DLSS Neural Rendering"); header.IsHeaderOpen())
    {
        ScopedIndent indent {};
        const float toggleGap = ImGui::GetStyle().ItemSpacing.x;
        const float toggleWidth = (ImGui::GetContentRegionAvail().x - toggleGap) * 0.5f;
        const float toggleRight = ImGui::GetCursorPosX() + toggleWidth + toggleGap;
        bool enabled = config->DlssNrEnabled.value_or_default();
        if (PipelineUi::CheckboxWrapped("Enable Neural Rendering", &enabled, toggleWidth))
            config->DlssNrEnabled = enabled;
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip(
                "Enable NR processing.");

        bool applyModel = config->DlssNrApplyModel.value_or_default();
        if (PipelineUi::CheckboxWrapped("Apply model", &applyModel, toggleWidth))
            config->DlssNrApplyModel = applyModel;
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Show or hide the NR effect. The model still runs when hidden.\nDisable Enable Neural "
                              "Rendering to stop its GPU cost.");

        const auto feature = State::Instance().currentFeature;
        const bool rayReconstruction = feature && feature->GetUpscalerType() == Upscaler::DLSSD;
        // Dedicated RR route (v0.7.1 ApplyAfterRR): the shared placement below is ignored for a native RR feature.
        const bool dedicatedRr = DedicatedRrRoute(*config, rayReconstruction);
        ImGui::BeginDisabled(dedicatedRr);
        bool finished = config->DlssNrFinishedPicture.value_or_default();
        auto placement = ResolvePlacement(config->DlssNrRunBeforeSr.value_or_default(),
                                          config->DlssNrDeferredDlss.value_or_default(),
                                          config->DlssNrResidualAcrossRr.value_or_default(), finished);
        bool generateBefore = placement.beforeUpscale;
        ImGui::SameLine(toggleRight);
        ImGui::BeginDisabled(placement.deferred);
        if (PipelineUi::CheckboxWrapped("Generate model before upscale", &generateBefore, toggleWidth))
        {
            config->DlssNrRunBeforeSr = generateBefore;
            config->DlssNrResidualAcrossRr = false;
        }
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled))
            ImGui::SetTooltip(placement.deferred ? "The separate-edit path always generates before upscale."
                                               : "Run NR before the game's upscaler, including RR.");

        ImGui::EndDisabled();
        if (PipelineUi::CheckboxWrapped("Apply NR to the finished picture (SF colors / exposure)", &finished,
                                        toggleWidth))
        {
            config->DlssNrFinishedPicture = finished;
            DlssNr::RetryAfterFailure();
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Apply NR after game effects and HUD. Early generation carries the edit through a separate upscaler."
                              "\nOn the dedicated RR route this runs NR on the finished, tone-mapped picture instead"
                              "\nof right after RR: the game's own colours, no white-point estimate.");
        if (finished)
        {
            bool light = config->DlssNrRRFinishedLight.value_or_default();
            if (PipelineUi::CheckboxWrapped("Light form: model inside the frame, only its edit applied at presentation",
                                            &light, toggleWidth))
            {
                config->DlssNrRRFinishedLight = light;
                DlssNr::RetryAfterFailure();
            }
            if (ImGui::IsItemHovered())
                ImGui::SetTooltip("On: the model runs at its seam inside the frame (RR route, after the upscaler, or"
                                  "\nbefore it) and only its edit is applied to the finished picture at presentation."
                                  "\nOff: the heavy form, the whole model runs on the finished picture at presentation"
                                  "\n(the original finished route). Compare both; the status line counts what happens.");
            bool fgc = config->DlssNrFinishedFgConsistent.value_or_default();
            if (PipelineUi::CheckboxWrapped("Edit the frame-generation input too (generated frames match, HUD untouched)",
                                            &fgc, toggleWidth))
                config->DlssNrFinishedFgConsistent = fgc;
            if (ImGui::IsItemHovered())
                ImGui::SetTooltip("With native DLSS-G the finished edit used to land only on the real frames; the generated"
                                  "\nframes came from the HUD-less frame, unedited, so 1 in 2/3/4 displayed frames differed:"
                                  "\nflicker that reads as tearing. Now the same edit is applied to the HUD-less frame frame"
                                  "\ngeneration interpolates from, and the HUD-less frame also marks where the HUD sits, so"
                                  "\nmenus and HUD are left alone. Needs the game to tag its HUD-less frame as valid until present.");
            if (config->DlssNrRunBeforeSr.value_or_default())
            {
                bool autoSign = config->DlssNrFinishedJitterAuto.value_or_default();
                if (ImGui::Checkbox("Measure jitter sign (pre-SR finished edit)", &autoSign))
                    config->DlssNrFinishedJitterAuto = autoSign;
                if (ImGui::IsItemHovered())
                    ImGui::SetTooltip("Scores both jitter signs against the picture's edges every frame and uses the one whose"
                                      "\nedit lands on them. The status line shows both scores and which sign is in use.");
                ImGui::SameLine();
                bool flip = config->DlssNrFinishedJitterFlip.value_or_default();
                if (ImGui::Checkbox("Flip jitter sign (pre-SR finished edit)", &flip))
                    config->DlssNrFinishedJitterFlip = flip;
                if (ImGui::IsItemHovered())
                    ImGui::SetTooltip("Pre-SR + finished picture: the render-resolution edit is enlarged onto the finished picture"
                                      "\nwith the frame's jitter compensated. If thin detail looks doubled or noisy, flip and compare.");
            }
        }
        ImGui::BeginDisabled(dedicatedRr);

        placement = ResolvePlacement(config->DlssNrRunBeforeSr.value_or_default(),
                                     config->DlssNrDeferredDlss.value_or_default(),
                                     config->DlssNrResidualAcrossRr.value_or_default(), finished);
        ImGui::SameLine(toggleRight);
        bool deferred = placement.deferred;
        if (PipelineUi::CheckboxWrapped("Generate before upscale, apply after upscale", &deferred, toggleWidth))
        {
            config->DlssNrDeferredDlss = deferred;
            config->DlssNrResidualAcrossRr = false; // Clear the legacy alias when the unified option changes.
            if (deferred || finished)
                config->DlssNrRunBeforeSr = deferred;
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Keep the game's SR/RR input clean and upscale only the NR edit with a separate non-RR backend."
                              "\nApply after upscale, or at presentation when finished-picture mode is enabled.");
        ImGui::EndDisabled();
        if (dedicatedRr)
            ImGui::TextWrapped(config->DlssNrFinishedPicture.value_or_default()
                                   ? "Dedicated RR route active: NR runs once on the finished picture at the RR pass"
                                     " count and model resolution; the before/after controls above are ignored."
                                   : "Dedicated RR route active: NR runs once right after RR at the RR pass count and"
                                     " model resolution; the before/after controls above are ignored.");
        ImGui::Spacing();

        // Dedicated Ray Reconstruction route (v0.7.1 ApplyAfterRR): independent of the shared placement above.
        bool afterRr = config->DlssNrApplyAfterRR.value_or_default();
        if (PipelineUi::CheckboxWrapped("Dedicated RR route: NR after Ray Reconstruction", &afterRr,
                                        ImGui::GetContentRegionAvail().x))
            config->DlssNrApplyAfterRR = afterRr;
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("With a native RR feature, ignore the placement above and run NR once on RR's"
                              "\ndenoised, upscaled output (before frame generation) with its own pass count and"
                              "\nmodel resolution. RR keeps its untouched noisy inputs; SR-only games are unaffected."
                              "\nThis restores the v0.7.1 'Apply after Ray Reconstruction' pipeline.");
        if (afterRr)
        {
            static int pendingRrScale = -1;
            ImGui::PushItemWidth(std::min(220.0f * menuResScale, ImGui::GetContentRegionAvail().x * 0.42f));
            int rrPasses = (int) std::clamp(config->DlssNrRRPasses.value_or_default(), 1u, 3u);
            if (ImGui::SliderInt("RR passes", &rrPasses, 1, 3))
                config->DlssNrRRPasses = (uint32_t) rrPasses;
            if (ArrowNudgeInt(&rrPasses, 1, 1, 3))
                config->DlssNrRRPasses = (uint32_t) rrPasses;
            if (ResetButton("RR passes"))
                config->DlssNrRRPasses = 1u;
            int rrScale = pendingRrScale >= 0
                              ? pendingRrScale
                              : (int) lroundf(config->DlssNrRRWorkingScale.value_or_default() * 100.0f);
            static bool rrScaleByKey = false;
            if (ImGui::SliderInt("RR model resolution", &rrScale, 25, 200, "%d%%"))
                pendingRrScale = rrScale;
            const bool rrScaleReleased = ImGui::IsItemDeactivatedAfterEdit();
            if (ArrowNudgeInt(&rrScale, 1, 25, 200))
            {
                pendingRrScale = rrScale;
                rrScaleByKey = true;
            }
            // A drag commits on release; a key run commits once the key is let go (one rebuild).
            if (pendingRrScale >= 0 && (rrScaleReleased || (rrScaleByKey && !ArrowKeyHeld())))
            {
                config->DlssNrRRWorkingScale = std::clamp(pendingRrScale, 25, 200) / 100.0f;
                pendingRrScale = -1;
                rrScaleByKey = false;
            }
            if (ResetButton("RR model resolution"))
            {
                config->DlssNrRRWorkingScale = 1.0f;
                pendingRrScale = -1;
                rrScaleByKey = false;
            }
            ImGui::PopItemWidth();
            bool colourLock = config->DlssNrRRColourLock.value_or_default();
            if (PipelineUi::CheckboxWrapped("Keep the game's colours on the RR route", &colourLock,
                                            ImGui::GetContentRegionAvail().x))
                config->DlssNrRRColourLock = colourLock;
            if (ImGui::IsItemHovered())
                ImGui::SetTooltip("NR's edit is composed as light only: the game's hue and saturation stay exactly as"
                                  "\nrendered, the model decides brightness and detail. Fixes washed or pink-shifted"
                                  "\nneon and saturated reds on the RR route. Same as Colour strength 0, RR features only.");

            HelpMarker("Relative to RR's output. 100% is the reference; 90% measured the same picture for about 15%"
                       "\nless. Below 90% the enlarged tone lift can glow on skin: switch Enlargement (Input section)"
                       "\nto Matched residual + DLSS there, at the cost of a private DLSS pass.");
            if (!rayReconstruction)
            {
                ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled));
                ImGui::TextWrapped("Ray Reconstruction is not active on the current feature; "
                                   "the shared settings apply.");
                ImGui::PopStyleColor();
            }
            ImGui::Spacing();
        }

        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled));
        ImGui::TextWrapped("Sliders: hover one, then Left / Right moves it one step; hold to run. Model and"
                           " resolution sliders apply when the key is released.");
        ImGui::PopStyleColor();

        // Token-aware model size: the model's cost follows its token count, which depends on the input
        // dimensions in steps. Show the live count and offer a fit to the largest scale in the same class.
        {
            const auto fitSnap = TokenFit::GetSnapshot();
            const auto observed = DlssNrNative::Observed();
            if (observed.tokens != 0)
                ImGui::Text("Model tokens: M=%llu (grid %ux%u)", observed.tokens, observed.dims[0], observed.dims[1]);
            else
                ImGui::TextDisabled("Model tokens: waiting for the model to run");
            HelpMarker("The model tiles its input into tokens and its cost follows the token count, not the"
                       "\npixel count. The tile size depends on the input dimensions, so neighbouring scales"
                       "\ncan differ a lot.");
            ImGui::BeginDisabled(fitSnap.active || feature == nullptr);
            if (ImGui::Button("Fit model size to token class"))
                TokenFit::Request(rayReconstruction, ModelWorkingScale(*config, rayReconstruction), 1.0f, 0.05f);
            ImGui::EndDisabled();
            if (ImGui::IsItemHovered())
                ImGui::SetTooltip("Stand still. Probes 5% steps from the current scale up to 100%, a dozen frames"
                                  "\neach (a few seconds in total), then sets the largest scale that costs no more"
                                  "\ntokens than the current one. Save the INI afterwards to keep the result.");
            if (fitSnap.active)
            {
                ImGui::SameLine();
                if (ImGui::Button("Cancel fit"))
                    TokenFit::Cancel();
            }
            if (!fitSnap.status.empty())
                ImGui::TextWrapped("%s", fitSnap.status.c_str());
            if (!fitSnap.rows.empty() && ImGui::TreeNode("Measured sizes"))
            {
                for (const auto& row : fitSnap.rows)
                    ImGui::Text("%3d%%  %ux%u  M=%llu (grid %ux%u)", (int) lroundf(row.scale * 100.0f), row.width,
                                row.height, (unsigned long long) row.tokens, row.dims[0], row.dims[1]);
                ImGui::TreePop();
            }
            ImGui::Spacing();
        }

        placement = ResolvePlacement(config->DlssNrRunBeforeSr.value_or_default(),
                                     config->DlssNrDeferredDlss.value_or_default(),
                                     config->DlssNrResidualAcrossRr.value_or_default(), finished);
        const bool nativePrivateVk = feature && feature->Api() == API::Vulkan && !feature->IsWithDx12();
        if (placement.deferred && !nativePrivateVk)
        {
            int backend = (int) GetPrivateUpscaler(config->DlssNrPrivateUpscaler.value_or_default());
            if (ImGui::Combo("Private NR upscaler", &backend, "DLSS\0FSR 2.2\0FSR (FidelityFX)\0XeSS\0"))
                config->DlssNrPrivateUpscaler = backend;
            HelpMarker("Upscales only the NR edit, with or without game RR. FSR (FidelityFX) and XeSS need their runtimes.");
        }

        PipelineUi::View view;
        view.privateUpscaler = PrivateUpscalerName(GetPrivateUpscaler(config->DlssNrPrivateUpscaler.value_or_default()));
        view.enabled = enabled;
        view.applyModel = config->DlssNrApplyModel.value_or_default();
        view.passes = ModelPasses(*config, rayReconstruction);
        view.scalePercent = (int) lroundf(ModelWorkingScale(*config, rayReconstruction) * 100.0f);
        view.rayReconstruction = rayReconstruction;
        if (dedicatedRr)
            view.route = finished ? PipelineUi::Route::Finished : PipelineUi::Route::After;
        else if (finished)
            view.route = placement.deferred ? PipelineUi::Route::FinishedBefore : PipelineUi::Route::Finished;
        else if (placement.deferred)
            view.route = PipelineUi::Route::Deferred;
        else
            view.route = placement.beforeUpscale ? PipelineUi::Route::Before : PipelineUi::Route::After;

        static PipelineUi::Section selected = PipelineUi::Section::Placement;
        ImGui::Separator();
        PipelineUi::Draw(view, selected);
        ImGui::Separator();
        ImGui::Spacing();
        RenderStatus(config, menuResScale);
        ImGui::SeparatorText(PipelineUi::SectionName(selected));
        ImGui::PushItemWidth(std::min(220.0f * menuResScale, ImGui::GetContentRegionAvail().x * 0.42f));
        switch (selected)
        {
        case PipelineUi::Section::Placement:
            RenderPlacement(config, menuResScale);
            break;
        case PipelineUi::Section::Input:
            RenderInput(config, menuResScale);
            break;
        case PipelineUi::Section::Model:
            RenderModel(config, menuResScale);
            break;
        case PipelineUi::Section::Blend:
            RenderBlend(config, menuResScale);
            break;
        }
        ImGui::PopItemWidth();
        if (ImGui::CollapsingHeader("Advisor", ImGuiTreeNodeFlags_DefaultOpen))
            RenderAdvisor(config, menuResScale);
        if (ImGui::CollapsingHeader("Residual clean-up and faces"))
        {
            ImGui::PushItemWidth(std::min(220.0f * menuResScale, ImGui::GetContentRegionAvail().x * 0.42f));
            RenderCleanup(config, menuResScale);
            ImGui::PopItemWidth();
        }
        if (ImGui::CollapsingHeader("Inspect NR"))
        {
            ImGui::PushItemWidth(std::min(220.0f * menuResScale, ImGui::GetContentRegionAvail().x * 0.42f));
            RenderInspect(config, menuResScale);
            ImGui::PopItemWidth();
        }
    }
}

} // namespace DlssNr
