#include "pch.h"

#include "DlssNr_MenuSections.h"
#include "DlssNr_Status.h"
#include "DlssNrNative.h"
#include <Config.h>
#include <algorithm>
#include <cstring>
#include <string>
#include <unordered_map>

namespace DlssNr::MenuSections
{

// Model tuning rebuilds the feature; commit slider changes only on release.
template <typename Option>
static bool DeferredSlider(const char* label, Option* opt, float mn, float mx, float def, const char* fmt = "%.2f",
                           bool inheritReset = false)
{
    static std::unordered_map<ImGuiID, float> pending;
    const ImGuiID id = ImGui::GetID(label);

    auto it = pending.find(id);
    float value = it != pending.end() ? it->second : (opt->has_value() ? opt->value() : def);
    bool changed = false;

    if (ImGui::SliderFloat(label, &value, mn, mx, fmt))
        pending[id] = value;

    // Keys: a run of presses edits the pending value; the commit waits for the key to be released,
    // so a long press rebuilds the model once. Step is a hundredth of the range, rounded to the
    // slider's own display precision by the clamp below.
    static std::unordered_map<ImGuiID, bool> byKey;
    const bool released = ImGui::IsItemDeactivatedAfterEdit();
    if (ArrowNudge(&value, (mx - mn) / 100.0f, mn, mx))
    {
        pending[id] = value;
        byKey[id] = true;
    }
    if (released || (byKey[id] && !ArrowKeyHeld()))
    {
        auto committed = pending.find(id);

        if (committed != pending.end())
        {
            *opt = std::clamp(committed->second, mn, mx);
            pending.erase(committed);
            changed = true;
        }
        byKey[id] = false;
    }

    ImGui::SameLine();

    const std::string resetId = std::string("Reset##") + label;
    if (ImGui::SmallButton(resetId.c_str()))
    {
        if (inheritReset)
            *opt = std::optional<float> {};
        else
            *opt = def;
        pending.erase(id);
        changed = true;
    }

    if (std::strcmp(label, "Intensity") == 0)
        HelpMarker("Enhancement strength. 1 = default.");
    else if (std::strcmp(label, "Local structure") == 0)
        HelpMarker("Fine detail and local contrast. 1 = default.");
    else if (std::strcmp(label, "Local tone") == 0)
        HelpMarker("Broad lighting changes. Later passes default to 0.");
    else if (std::strcmp(label, "Skin structure") == 0)
        HelpMarker("Skin detail. -1 follows Local structure.");
    return changed;
}

// An absent later-pass setting inherits pass 1. The first combo item represents that absence; the
// remaining items map directly to the model's zero-based profile values.
static bool InheritedProfileCombo(const char* label, CustomOptional<uint32_t, NoDefault>* opt, const char* const* names,
                                  int nameCount)
{
    int selected = 0;

    if (opt->has_value())
        selected = std::clamp((int) opt->value(), 0, nameCount - 2) + 1;

    if (!ImGui::Combo(label, &selected, names, nameCount))
        return false;

    if (selected == 0)
        *opt = std::optional<uint32_t> {};
    else
        *opt = (uint32_t) (selected - 1);

    return true;
}

void RenderModel(Config* config, float menuResScale)
{
    // Model precision: original FP8 model, or the NVFP4 hybrid FFN kernels restored from v0.7.1.
    {
        int precisionChoice = config->DlssNrPrecision.value_or_default() == 2 ? 1 : 0;
        const char* precisions[] = { "FP8 (NVIDIA DLL)", "NVFP4 hybrid (Blackwell)" };
        if (ImGui::Combo("Model precision", &precisionChoice, precisions, IM_ARRAYSIZE(precisions)))
        {
            config->DlssNrPrecision = precisionChoice == 1 ? 2u : 0u;
            DlssNr::RetryAfterFailure(); // Rebuild the model features so the kernel interception restarts cleanly.
        }
        HelpMarker("NVFP4 hybrid replaces the model's FFN kernels with fused NVFP4 kernels: about 12% less NR"
                   "\ntime at 4K on Blackwell in v0.7.1. Needs the OptiScaler\\nvfp4\\hybrid assets from the v0.7.1"
                   "\npackage beside OptiScaler.dll and the original NVIDIA FP8 runtime. Unsupported shapes and"
                   "\nmodel sizes without a fused kernel keep FP8; the status line below reports which is active.");
        const auto hybridStatus = DlssNrNative::Status();
        if (hybridStatus.rfind("Restart required:", 0) == 0 ||
            (precisionChoice == 1 && hybridStatus.find("fallback") != std::string::npos))
            ImGui::TextWrapped("%s", hybridStatus.c_str());
    }

    // Model preset hint (DLSSNR.Hint.Render.Preset): a creation-time hint to NVIDIA's model, no per-frame
    // cost. Values are undocumented; the RenoDX injector runs 3. A change rebuilds the model feature.
    {
        static const unsigned int presetValues[] = { 0u, 1u, 2u, 3u, 6u };
        static const char* presetLabels[] = { "0 (default)", "1", "2", "3 (RenoDX default)", "6" };
        const unsigned int current = config->DlssNrPreset.value_or_default();
        int presetChoice = 0;
        for (int i = 0; i < 5; ++i)
            if (presetValues[i] == current)
                presetChoice = i;
        if (ImGui::Combo("Model preset hint", &presetChoice, presetLabels, IM_ARRAYSIZE(presetLabels)))
            config->DlssNrPreset = presetValues[presetChoice];
        HelpMarker("Hint passed to the NR model when its feature is built. Undocumented by NVIDIA; the RenoDX injector"
                   "\nruns 3, OptiScaler ran 0. Compare the ms number and the picture at the same spot; a change"
                   "\nrebuilds the model once and costs nothing per frame.");
    }

    bool unlockPasses = config->DlssNrUnlockPasses.value_or_default();
    const int menuPassLimit = unlockPasses ? 10 : 2;
    {
        static int passes = 1;
        static bool editingPasses = false;
        if (!editingPasses)
            passes = (int) std::clamp(config->DlssNrPasses.value_or_default(), 1u, (unsigned int) menuPassLimit);

        const auto text = ImGui::GetStyleColorVec4(ImGuiCol_Text);
        const float brightness = std::max({ text.x, text.y, text.z });
        const auto colour = passes == 1
                                ? ImVec4(brightness * 0.35f, brightness * 0.75f, brightness * 0.45f, text.w)
                                : ImVec4(brightness * 0.80f, brightness * 0.35f, brightness * 0.32f, text.w);
        ImGui::PushStyleColor(ImGuiCol_Text, colour);
        ImGui::SliderInt("##Model passes", &passes, 1, menuPassLimit, "%d", ImGuiSliderFlags_AlwaysClamp);
        static bool passesByKey = false;
        const bool passesReleased = ImGui::IsItemDeactivatedAfterEdit();
        if (ArrowNudgeInt(&passes, 1, 1, menuPassLimit))
            passesByKey = true;
        editingPasses = ImGui::IsItemActive() || passesByKey;
        if (passesReleased || (passesByKey && !ArrowKeyHeld()))
        {
            config->DlssNrPasses = (uint32_t) std::clamp(passes, 1, menuPassLimit);
            passesByKey = false;
        }
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::TextUnformatted("Model passes");
        if (ResetButton("Model passes"))
        {
            config->DlssNrPasses = 1u;
            passesByKey = false;
        }
    }
    if (ImGui::Checkbox("Unlock up to 10 passes", &unlockPasses))
    {
        config->DlssNrUnlockPasses = unlockPasses;
        config->DlssNrPasses = std::clamp(config->DlssNrPasses.value_or_default(), 1u, unlockPasses ? 10u : 2u);
    }

    static const char* styles[] = { "Standard", "Natural", "Cinematic" };
    static const char* inheritedStyles[] = { "Auto", "Standard", "Natural", "Cinematic" };

    if (ImGui::TreeNodeEx("Pass 1", ImGuiTreeNodeFlags_DefaultOpen))
    {
        int style = (int) std::min(config->DlssNrStyle.value_or_default(), 2u);
        if (ImGui::Combo("Style", &style, styles, IM_ARRAYSIZE(styles)))
            config->DlssNrStyle = (uint32_t) style;

        DeferredSlider("Intensity", &config->DlssNrIntensity, 0.0f, 2.0f, 1.0f);
        DeferredSlider("Local structure", &config->DlssNrLocalStructure, 0.0f, 2.0f, 1.0f);
        DeferredSlider("Local tone", &config->DlssNrLocalTone, 0.0f, 2.0f, 1.0f);
        DeferredSlider("Skin structure", &config->DlssNrSkinStructure, -1.0f, 2.0f, -1.0f);
        bool mask = config->DlssNrAutoMask.value_or_default();
        if (ImGui::Checkbox("Auto skin mask", &mask))
            config->DlssNrAutoMask = mask;
        HelpMarker("Model-based skin selection.");
        ImGui::TreePop();
    }

    if (config->DlssNrPasses.value_or_default() >= 2 && ImGui::TreeNodeEx("Pass 2", ImGuiTreeNodeFlags_DefaultOpen))
    {
        InheritedProfileCombo("Style", &config->DlssNrPass2Style, inheritedStyles, IM_ARRAYSIZE(inheritedStyles));
        DeferredSlider("Intensity", &config->DlssNrPass2Intensity, 0.0f, 2.0f,
                       config->DlssNrIntensity.value_or_default(), "%.2f", true);
        DeferredSlider("Local structure", &config->DlssNrPass2LocalStructure, 0.0f, 2.0f,
                       config->DlssNrLocalStructure.value_or_default(), "%.2f", true);
        DeferredSlider("Local tone", &config->DlssNrPass2LocalTone, 0.0f, 2.0f, 0.0f, "%.2f", true);
        DeferredSlider("Skin structure", &config->DlssNrPass2SkinStructure, -1.0f, 2.0f,
                       config->DlssNrSkinStructure.value_or_default(), "%.2f", true);
        bool mask = config->DlssNrPass2AutoMask.has_value() ? config->DlssNrPass2AutoMask.value()
                                                            : config->DlssNrAutoMask.value_or_default();
        if (ImGui::Checkbox("Auto skin mask", &mask))
            config->DlssNrPass2AutoMask = mask;
        ImGui::SameLine();
        if (ImGui::SmallButton("Reset##mask"))
            config->DlssNrPass2AutoMask = std::optional<bool> {};
        ImGui::TreePop();
    }

}

} // namespace DlssNr::MenuSections
