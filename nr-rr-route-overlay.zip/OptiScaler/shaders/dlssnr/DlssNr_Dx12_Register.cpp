#include "pch.h"
#include "DlssNr_Dx12_State.h"
#include <algorithm>
#include <cmath>

// Registration meter for the pre-SR finished edit. The finished-colour shader scores, for both jitter
// signs, how much of the enlarged edit lands on the picture's own edges; the sign whose edit sits on
// the edges is the one that registers. Scores travel to a readback ring and are folded in four frames
// later, the same cadence as the drift meter, so a buffer is never mapped while the GPU writes it.

auto DlssNr_Dx12::State::EnsureRegistrationMeter(unsigned int pictureWidth, unsigned int pictureHeight) -> bool
{
    if (late.device == nullptr)
        return false;
    const unsigned int cols = std::min(kRegMaxCols, (pictureWidth + 31) / 32);
    const unsigned int rows = std::min(kRegMaxRows, (pictureHeight + 31) / 32);
    if (reg.stats != nullptr && (reg.cols != cols || reg.rows != rows))
        ParkNrResource(reg.stats);
    if (reg.stats == nullptr)
    {
        reg.stats = CreateScratch(late.device.Get(), DXGI_FORMAT_R32G32B32A32_FLOAT, cols, rows);
        reg.cols = cols;
        reg.rows = rows;
        reg.frames = 0;
        reg.valid = false;
    }
    if (reg.stats == nullptr)
        return false;
    if (reg.readback[0] == nullptr)
    {
        D3D12_HEAP_PROPERTIES heap {};
        heap.Type = D3D12_HEAP_TYPE_READBACK;
        D3D12_RESOURCE_DESC desc {};
        desc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
        desc.Width = kRegBytes;
        desc.Height = 1;
        desc.DepthOrArraySize = 1;
        desc.MipLevels = 1;
        desc.Format = DXGI_FORMAT_UNKNOWN;
        desc.SampleDesc.Count = 1;
        desc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
        for (auto& rb : reg.readback)
            if (FAILED(late.device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &desc,
                                                            D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&rb))))
                rb = nullptr;
    }
    return reg.readback[0] != nullptr;
}

auto DlssNr_Dx12::State::CopyRegistrationToReadback(ID3D12GraphicsCommandList* cmd, unsigned int pictureWidth,
                                                    unsigned int pictureHeight) -> void
{
    if (reg.stats == nullptr)
        return;
    const unsigned int slot = (unsigned int) (reg.frames % 4);
    if (reg.readback[slot] == nullptr)
        return;
    reg.width[slot] = pictureWidth;
    reg.height[slot] = pictureHeight;
    D3D12_TEXTURE_COPY_LOCATION src {};
    src.pResource = reg.stats;
    src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    src.SubresourceIndex = 0;
    D3D12_TEXTURE_COPY_LOCATION dst {};
    dst.pResource = reg.readback[slot];
    dst.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
    dst.PlacedFootprint.Offset = 0;
    dst.PlacedFootprint.Footprint.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    dst.PlacedFootprint.Footprint.Width = reg.cols;
    dst.PlacedFootprint.Footprint.Height = reg.rows;
    dst.PlacedFootprint.Footprint.Depth = 1;
    dst.PlacedFootprint.Footprint.RowPitch = kRegRowBytes;
    Barrier(cmd, reg.stats, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
    cmd->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);
    Barrier(cmd, reg.stats, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    reg.frames++;
}

auto DlssNr_Dx12::State::ConsumeRegistrationReadback() -> void
{
    if (reg.frames < 4)
        return;
    const unsigned int slot = (unsigned int) (reg.frames % 4);
    ID3D12Resource* buffer = reg.readback[slot];
    if (buffer == nullptr)
        return;
    void* mapped = nullptr;
    D3D12_RANGE range { 0, kRegBytes };
    if (FAILED(buffer->Map(0, &range, &mapped)) || mapped == nullptr)
        return;
    const unsigned int cols = std::min(reg.cols, (reg.width[slot] + 31) / 32);
    const unsigned int rows = std::min(reg.rows, (reg.height[slot] + 31) / 32);
    double plus = 0.0, minus = 0.0, weight = 0.0;
    const auto* base = (const unsigned char*) mapped;
    for (unsigned int y = 0; y < rows; ++y)
    {
        const float* row = (const float*) (base + (size_t) y * kRegRowBytes);
        for (unsigned int x = 0; x < cols; ++x)
        {
            const float* c = row + (size_t) x * 4;
            if (!(c[3] > 0.5f) || !std::isfinite(c[0]) || !std::isfinite(c[1]) || !std::isfinite(c[2]))
                continue;
            plus += c[0];
            minus += c[1];
            weight += c[2];
        }
    }
    D3D12_RANGE none { 0, 0 };
    buffer->Unmap(0, &none);
    if (weight <= 0.0)
        return;
    // Per-pixel averages, smoothed over ~30 frames so a single frame's scene content cannot flip the sign.
    const double p = plus / weight, m = minus / weight;
    if (!reg.valid)
    {
        reg.plus = p;
        reg.minus = m;
        reg.valid = true;
    }
    else
    {
        reg.plus += (p - reg.plus) * 0.03;
        reg.minus += (m - reg.minus) * 0.03;
    }
    // Hysteresis: switch only when the other sign wins by more than 5%.
    const bool plusWins = reg.plus > reg.minus * 1.05, minusWins = reg.minus > reg.plus * 1.05;
    if (reg.usePlus && minusWins)
    {
        reg.usePlus = false;
        reg.decisions++;
    }
    else if (!reg.usePlus && plusWins)
    {
        reg.usePlus = true;
        reg.decisions++;
    }
}

auto DlssNr_Dx12::State::RegistrationSign() -> float
{
    const auto& cfg = *Config::Instance();
    if (cfg.DlssNrFinishedJitterFlip.value_or_default())
        return -1.0f; // manual override
    if (cfg.DlssNrFinishedJitterAuto.value_or_default() && reg.valid)
        return reg.usePlus ? 1.0f : -1.0f;
    return 1.0f;
}
