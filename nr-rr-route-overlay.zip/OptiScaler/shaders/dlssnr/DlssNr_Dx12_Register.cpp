#include "pch.h"
#include "DlssNr_Dx12_State.h"
#include <algorithm>

// Guard coverage history: one texel per 8x8-pixel block of the presented picture. The finished-colour
// shader reads last frame's coverage of each block and writes this frame's; the CPU never touches it.

auto DlssNr_Dx12::State::EnsureRegistrationMeter(unsigned int pictureWidth, unsigned int pictureHeight) -> bool
{
    if (late.device == nullptr)
        return false;
    const unsigned int cols = std::min(kRegMaxCols, (pictureWidth + 7) / 8);
    const unsigned int rows = std::min(kRegMaxRows, (pictureHeight + 7) / 8);
    if (reg.stats != nullptr && (reg.cols != cols || reg.rows != rows))
    {
        ParkNrResource(reg.stats);
        reg.fresh = true;
    }
    if (reg.stats == nullptr)
    {
        reg.stats = CreateScratch(late.device.Get(), DXGI_FORMAT_R32G32B32A32_FLOAT, cols, rows);
        reg.cols = cols;
        reg.rows = rows;
        reg.fresh = true;
    }
    return reg.stats != nullptr;
}
