#include "pch.h"
#include "DlssNr_Dx12_State.h"
#include <algorithm>
#include <cmath>

// Guard statistics: the finished-colour shader writes one texel per 8x8-pixel block (menu coverage on
// the GPU, and the blur-scale calibration sums); the sums travel to a readback ring and are folded in
// four frames later, the same cadence as the drift meter, so a buffer is never mapped while the GPU
// writes it.

auto DlssNr_Dx12::State::EnsureRegistrationMeter(unsigned int pictureWidth, unsigned int pictureHeight) -> bool
{
    if (late.device == nullptr)
        return false;
    const unsigned int cols = std::min(kRegMaxCols, (pictureWidth + 7) / 8);
    const unsigned int rows = std::min(kRegMaxRows, (pictureHeight + 7) / 8);
    if (reg.stats != nullptr && (reg.cols != cols || reg.rows != rows))
        ParkNrResource(reg.stats);
    if (reg.stats == nullptr)
    {
        reg.stats = CreateScratch(late.device.Get(), DXGI_FORMAT_R32G32B32A32_FLOAT, cols, rows);
        reg.cols = cols;
        reg.rows = rows;
        reg.frames = 0;
    }
    if (reg.stats == nullptr)
        return false;
    if (reg.readback[0] == nullptr)
    {
        D3D12_HEAP_PROPERTIES heap {};
        heap.Type = D3D12_HEAP_TYPE_READBACK;
        D3D12_RESOURCE_DESC desc {};
        desc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
        desc.Width = kRegBytes;
        desc.Height = 1;
        desc.DepthOrArraySize = 1;
        desc.MipLevels = 1;
        desc.Format = DXGI_FORMAT_UNKNOWN;
        desc.SampleDesc.Count = 1;
        desc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
        for (auto& rb : reg.readback)
            if (FAILED(late.device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &desc,
                                                            D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&rb))))
                rb = nullptr;
    }
    return reg.readback[0] != nullptr;
}

auto DlssNr_Dx12::State::CopyRegistrationToReadback(ID3D12GraphicsCommandList* cmd, unsigned int pictureWidth,
                                                    unsigned int pictureHeight) -> void
{
    if (reg.stats == nullptr)
        return;
    const unsigned int slot = (unsigned int) (reg.frames % 4);
    if (reg.readback[slot] == nullptr)
        return;
    reg.width[slot] = pictureWidth;
    reg.height[slot] = pictureHeight;
    D3D12_TEXTURE_COPY_LOCATION src {};
    src.pResource = reg.stats;
    src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    src.SubresourceIndex = 0;
    D3D12_TEXTURE_COPY_LOCATION dst {};
    dst.pResource = reg.readback[slot];
    dst.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
    dst.PlacedFootprint.Offset = 0;
    dst.PlacedFootprint.Footprint.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    dst.PlacedFootprint.Footprint.Width = reg.cols;
    dst.PlacedFootprint.Footprint.Height = reg.rows;
    dst.PlacedFootprint.Footprint.Depth = 1;
    dst.PlacedFootprint.Footprint.RowPitch = kRegRowBytes;
    Barrier(cmd, reg.stats, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
    cmd->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);
    Barrier(cmd, reg.stats, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    reg.frames++;
}

auto DlssNr_Dx12::State::ConsumeRegistrationReadback() -> void
{
    if (reg.frames < 4)
        return;
    const unsigned int slot = (unsigned int) (reg.frames % 4);
    ID3D12Resource* buffer = reg.readback[slot];
    if (buffer == nullptr)
        return;
    void* mapped = nullptr;
    D3D12_RANGE range { 0, kRegBytes };
    if (FAILED(buffer->Map(0, &range, &mapped)) || mapped == nullptr)
        return;
    const unsigned int cols = std::min(reg.cols, (reg.width[slot] + 7) / 8);
    const unsigned int rows = std::min(reg.rows, (reg.height[slot] + 7) / 8);
    // Cells: (coverage, sum k*w, sum w, 2) per block; every other block is enough for the fit.
    double calSum = 0.0, calW = 0.0;
    const auto* base = (const unsigned char*) mapped;
    for (unsigned int y = 0; y < rows; y += 2)
    {
        const float* row = (const float*) (base + (size_t) y * kRegRowBytes);
        for (unsigned int x = 0; x < cols; x += 2)
        {
            const float* c = row + (size_t) x * 4;
            if (!std::isfinite(c[1]) || !std::isfinite(c[2]) || !std::isfinite(c[3]) || !(c[3] > 1.5f))
                continue;
            calSum += c[1];
            calW += c[2];
        }
    }
    D3D12_RANGE none { 0, 0 };
    buffer->Unmap(0, &none);
    // Blur-scale calibration: weighted mean of per-pixel (streak length / speed), smoothed; valid once
    // enough edge pixels in motion have been seen. Clamped to what an engine blur can plausibly be.
    if (calW > 50.0)
    {
        const double k = std::clamp(calSum / calW, 0.05, 2.0);
        if (!reg.blurKValid)
        {
            reg.blurK = k;
            reg.blurKWeight = calW;
        }
        else
        {
            reg.blurK += (k - reg.blurK) * 0.05;
            reg.blurKWeight = std::min(reg.blurKWeight + calW, 1e9);
        }
        if (reg.blurKWeight > 2000.0)
            reg.blurKValid = true;
    }
}
