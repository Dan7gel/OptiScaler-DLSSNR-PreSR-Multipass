#include "pch.h"
#include "DlssNr_Dx12_State.h"
#include <dlssnr/DlssNr_Drift.h>
#include <algorithm>
#include <cmath>

// Colour drift meter: the resolve writes sparse (original, result) samples into nr.driftStats; they
// travel to a readback ring and are averaged on the CPU four frames later, the same cadence the white
// point meter uses so a buffer is never mapped while the GPU may still be writing it.

auto DlssNr_Dx12::State::CopyDriftToReadback(ID3D12GraphicsCommandList* cmdList, unsigned int width,
                                             unsigned int height) -> void
{
    if (nr.driftStats == nullptr)
        return;

    const unsigned int slot = (unsigned int) (nr.driftFrames % 4);
    if (nr.driftReadback[slot] == nullptr)
        return;

    nr.driftWidth[slot] = width;
    nr.driftHeight[slot] = height;

    D3D12_TEXTURE_COPY_LOCATION src {};
    src.pResource = nr.driftStats;
    src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    src.SubresourceIndex = 0;

    D3D12_TEXTURE_COPY_LOCATION dst {};
    dst.pResource = nr.driftReadback[slot];
    dst.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
    dst.PlacedFootprint.Offset = 0;
    dst.PlacedFootprint.Footprint.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    dst.PlacedFootprint.Footprint.Width = kDlssNrDriftCols * 2;
    dst.PlacedFootprint.Footprint.Height = kDlssNrDriftRows;
    dst.PlacedFootprint.Footprint.Depth = 1;
    dst.PlacedFootprint.Footprint.RowPitch = kDriftRowBytes;

    Barrier(cmdList, nr.driftStats, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
    cmdList->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);
    Barrier(cmdList, nr.driftStats, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);

    nr.driftFrames++;
}

auto DlssNr_Dx12::State::ConsumeDriftReadback() -> void
{
    if (nr.driftFrames < 4)
        return;

    const unsigned int slot = (unsigned int) (nr.driftFrames % 4);
    ID3D12Resource* buffer = nr.driftReadback[slot];
    if (buffer == nullptr)
        return;

    void* mapped = nullptr;
    D3D12_RANGE range { 0, kDriftBytes };
    if (FAILED(buffer->Map(0, &range, &mapped)) || mapped == nullptr)
        return;

    const unsigned int cols = std::min(kDlssNrDriftCols, nr.driftWidth[slot] / kDlssNrDriftStride + 1);
    const unsigned int rows = std::min(kDlssNrDriftRows, nr.driftHeight[slot] / kDlssNrDriftStride + 1);

    double sumOy = 0.0, sumRy = 0.0, sumOs = 0.0, sumRs = 0.0, sumHue = 0.0, hueWeight = 0.0;
    unsigned int samples = 0;
    const auto* base = (const unsigned char*) mapped;
    for (unsigned int y = 0; y < rows; ++y)
    {
        const float* row = (const float*) (base + (size_t) y * kDriftRowBytes);
        for (unsigned int x = 0; x < cols; ++x)
        {
            const float* a = row + (size_t) x * 4;
            const float* b = row + (size_t) (x + kDlssNrDriftCols) * 4;
            // b[2] == 1 marks a cell written by the resolve; anything else is stale or never written.
            if (!(b[2] > 0.5f) || !std::isfinite(a[0]) || !std::isfinite(a[1]) || !std::isfinite(b[0]))
                continue;
            sumOy += a[0];
            sumRy += a[1];
            sumOs += a[2];
            sumRs += a[3];
            const float w = std::max(b[1], 0.0f); // brighter of the pair: dark pixels carry little hue
            if (w > 0.02f)
            {
                sumHue += (double) b[0] * w;
                hueWeight += w;
            }
            ++samples;
        }
    }

    D3D12_RANGE nothingWritten { 0, 0 };
    buffer->Unmap(0, &nothingWritten);

    if (samples < 16)
        return;

    DlssNrDriftResult result;
    result.valid = true;
    result.lumaRatio = sumOy > 1e-6 ? (float) (sumRy / sumOy) : 1.0f;
    result.saturationOriginal = (float) (sumOs / samples);
    result.saturationResult = (float) (sumRs / samples);
    result.hueDeltaDeg = hueWeight > 0.0 ? (float) (sumHue / hueWeight) : 0.0f;
    result.samples = (float) samples;
    DlssNr::Drift::Publish(result);
}
