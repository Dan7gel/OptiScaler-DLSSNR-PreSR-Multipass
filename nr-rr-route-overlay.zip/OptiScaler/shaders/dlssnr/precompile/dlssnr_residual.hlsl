// ResidualAcrossRR v2 -- the MV-reprojected temporal accumulator for the pre-SR NR residual.
//
// Deliberately a SEPARATE shader from dlssnr.hlsl. Regenerating dlssnr.hlsl's blob with a current
// dxc produces materially different DXIL from the committed one (older compiler), and that shader
// carries every NR path -- post-SR, pre-SR, RR, DeferredDLSS. These two experimental
// modes get their own tiny blob and a second compute PSO instead, so the battle-tested one is
// never touched. The cbuffer and bindings mirror dlssnr.hlsl exactly so DlssNr_Dx12's existing
// root signature and descriptor table are reused as-is; only gResidualBlend is appended, and it
// fits inside DlssNrConstants' existing 256-byte alignment with no size change.
//
//   gMode == 0  Accumulate: (edited - original) blended into the MV-reprojected history layer.
//               history_t = lerp( reproject(history_{t-1}), edited - original, blend )
//               The per-frame ray-trace noise term of (edited - original) is temporally
//               uncorrelated and averages to zero; the enhancement term follows geometry and
//               persists. Invalid reprojection (off-screen / bad MV) -> the
//               history is treated as zero at that pixel and rebuilds over the next frames.
//   gMode == 1  Apply: base + delta * gTransferStrength, clamped non-negative. Run after RR+SR
//               with the upscaled history layer as the delta.

#ifdef VK_MODE
[[vk::binding(0, 0)]]
cbuffer Params : register(b0, space0)
#else
cbuffer Params : register(b0)
#endif
{
    uint  gMode;
    float gWhitePoint;
    uint  gWidth;
    uint  gHeight;
    float gTransferStrength;
    float gColourStrength;
    uint  gDebugView;
    float gMaxRatio;
    uint  gPassthrough;
    float gMvScaleX;
    float gMvScaleY;
    uint  gGuideWidth;
    uint  gGuideHeight;
    uint  gCompareMode;
    float gCompareSplit;
    float gCompareZoom;
    uint  gCompareSwap;
    uint  gTransfer;
    float gDebugScale;
    uint  gReversibleMode;
    uint  gApplyModel;
    uint  gUseGameExposure;
    float gExposurePreMul;
    uint  gSkinProtection;
    uint  gShowSkinMask;
    float gSkinDetail;
    float gSkinColour;
    float gEnvironmentDetail;
    float gEnvironmentColour;
    float gResidualBlend;   // v2 only: history blend rate, 0..1. 1 == no accumulation (== v1).
    uint gResidualHistoryValid;
    uint gResidualMotionBaseX;
    uint gResidualMotionBaseY;
};

// Same registers and the same SPIR-V binding numbers as dlssnr.hlsl, including the slots these
// modes do not read (gExposure t4, gKeep u1) -- DispatchResidualPass binds a stand-in into them
// exactly as DispatchPass does, and a future Vulkan host path needs the numbering to line up.
#ifdef VK_MODE
[[vk::binding(1, 0)]]
#endif
Texture2D<float4>   gSource   : register(t0);  // accumulate: the untouched pre-SR frame. apply: the RR+SR output.
#ifdef VK_MODE
[[vk::binding(2, 0)]]
#endif
Texture2D<float4>   gModel    : register(t1);  // accumulate: the NR-edited frame. apply: the upscaled delta layer.
#ifdef VK_MODE
[[vk::binding(3, 0)]]
#endif
Texture2D<float4>   gOriginal : register(t2);  // accumulate: the previous history layer.
#ifdef VK_MODE
[[vk::binding(4, 0)]]
#endif
Texture2D<float4>   gMotion   : register(t3);  // raw game motion; active size, offsets and scale come from the host.
#ifndef VK_MODE
Texture2D<float4>   gExposure : register(t4);  // unused here; bound for descriptor-table parity.
#endif
#ifdef VK_MODE
[[vk::binding(5, 0)]]
#endif
RWTexture2D<float4> gTarget   : register(u0);  // accumulate: the new history layer. apply: the composed frame.
#ifdef VK_MODE
[[vk::binding(6, 0)]]
#endif
RWTexture2D<float4> gKeep     : register(u1);  // unused here; bound for descriptor-table parity.
#ifdef VK_MODE
[[vk::binding(7, 0)]]
#endif
SamplerState        gLinear   : register(s0);  // history is sampled at the reprojected coordinate.

float  SanitizeFinite(float v, float fallback)   { return isfinite(v) ? v : fallback; }
float3 SanitizeFinite3(float3 v, float3 fallback)
{
    return float3(SanitizeFinite(v.x, fallback.x), SanitizeFinite(v.y, fallback.y),
                  SanitizeFinite(v.z, fallback.z));
}

[numthreads(8, 8, 1)]
void CSMain(uint3 id : SV_DispatchThreadID)
{
    if (id.x >= gWidth || id.y >= gHeight)
        return;

    if (gMode == 0)
    {
        float3 delta = SanitizeFinite3(gModel.Load(int3(id.xy, 0)).rgb -
                                       gSource.Load(int3(id.xy, 0)).rgb, float3(0.0, 0.0, 0.0));

        float2 uv = (float2(id.xy) + 0.5) / float2(gWidth, gHeight);
        uint2 guideSize = uint2(gGuideWidth, gGuideHeight);
        uint2 guidePos = min(uint2(uv * guideSize), guideSize - 1) +
                         uint2(gResidualMotionBaseX, gResidualMotionBaseY);
        float2 motion = gMotion.Load(int3(guidePos, 0)).xy * float2(gMvScaleX, gMvScaleY);

        // Weapon rule (gResidualHistoryValid bit 2): the first-person weapon, and a scope's lens image,
        // sit nearer than the threshold (gWhitePoint, depth units; bit 3 = reversed depth) and have no
        // usable motion vectors. Their history is taken in place (no reprojection), clamped below, so
        // they get the same temporal averaging as the world without trails.
        const bool weaponRuleOn = (gResidualHistoryValid & 4u) != 0;
        const bool inverted = (gResidualHistoryValid & 8u) != 0;
        bool near = false;
        if (weaponRuleOn)
        {
            float d = gExposure.SampleLevel(gLinear, uv, 0).r;
            near = inverted ? (d > gWhitePoint) : (d < gWhitePoint);
        }
        if (near)
            motion = 0.0;
        float2 prevUV = uv + motion;

        bool valid = gResidualHistoryValid != 0 && all(isfinite(motion)) && all(abs(motion) < 2.0) &&
                     all(prevUV >= 0.0) && all(prevUV <= 1.0);

        float3 history = valid ? gOriginal.SampleLevel(gLinear, prevUV, 0).rgb : float3(0.0, 0.0, 0.0);
        history = SanitizeFinite3(history, float3(0.0, 0.0, 0.0));

        // Clamped history (gResidualHistoryValid bit 1): the reprojected history is limited to the range
        // of the current edit in the 3x3 neighbourhood, so a revealed area or a wrongly reprojected one
        // (the weapon, whose vectors are poor) cannot carry an old edit; slow drift is averaged, trails
        // are not.
        // Speed of this pixel in frame pixels: slow pans (under a pixel per frame) get a long,
        // unclamped memory, since nothing can trail at that speed and the jitter-driven flicker needs
        // about eight frames to cancel; fast motion gets the short, clamped blend.
        float speedPx = length(motion * float2(gWidth, gHeight));
        float fast = near ? 1.0 : smoothstep(1.0, 3.0, speedPx);
        if (valid && (gResidualHistoryValid & 2u) != 0 && fast > 0.0)
        {
            float3 lo = delta, hi = delta;
            [unroll]
            for (int oy = -1; oy <= 1; ++oy)
                [unroll]
                for (int ox = -1; ox <= 1; ++ox)
                {
                    int2 p = clamp(int2(id.xy) + int2(ox, oy), int2(0, 0), int2(int(gWidth) - 1, int(gHeight) - 1));
                    float3 d = SanitizeFinite3(gModel.Load(int3(p, 0)).rgb - gSource.Load(int3(p, 0)).rgb, delta);
                    lo = min(lo, d); hi = max(hi, d);
                }
            float3 pad = (hi - lo) * 0.25 + 1e-4;
            history = lerp(history, clamp(history, lo - pad, hi + pad), fast);
        }

        // Invalid reprojection or a cold start/cut: the fresh edit at once rather than a fade-in.
        float a = valid ? clamp(gResidualBlend, 0.0, 1.0) : 1.0;
        if (valid && (gResidualHistoryValid & 2u) != 0)
            a = lerp(0.12, clamp(gResidualBlend, 0.0, 1.0), fast); // slow: ~8 frames; fast: the set blend

        // Weapon rule (gResidualHistoryValid bit 2): the first-person weapon has no usable motion
        // vectors. Pixels nearer than the threshold (gWhitePoint, in depth units; bit 3 = reversed depth,
        // near = large) take the fresh edit with no reprojection, and carry alpha 0 so the finished
        // picture's guard leaves them unstreaked.
        float weaponFlag = 1.0;
        if (weaponRuleOn)
        {
            float d = gExposure.SampleLevel(gLinear, uv, 0).r;
            // Silhouette: depth jumps between neighbours (hand and barrel against the world, thin scope
            // geometry). In log depth a jump of 0.5 is a distance ratio of ~1.6.
            float dl = log2(max(inverted ? d : 1.0 - d, 1e-6));
            float2 pxD = 1.0 / float2(gWidth, gHeight);
            float jump = 0.0;
            [unroll]
            for (int oy = -1; oy <= 1; ++oy)
                [unroll]
                for (int ox = -1; ox <= 1; ++ox)
                {
                    float dn = gExposure.SampleLevel(gLinear, uv + float2(ox, oy) * pxD, 0).r;
                    jump = max(jump, abs(log2(max(inverted ? dn : 1.0 - dn, 1e-6)) - dl));
                }
            bool silhouette = jump > 0.5;
            if (near)
                weaponFlag = 0.0;
            if (near || silhouette)
            {
                // No overshoot: the edited value may not leave the clean frame's 3x3 range, which is what
                // a thin bright rim on a silhouette is.
                float3 base = gSource.Load(int3(id.xy, 0)).rgb;
                float3 lo = base, hi = base;
                [unroll]
                for (int cy = -1; cy <= 1; ++cy)
                    [unroll]
                    for (int cx = -1; cx <= 1; ++cx)
                    {
                        int2 p = clamp(int2(id.xy) + int2(cx, cy), int2(0, 0), int2(int(gWidth) - 1, int(gHeight) - 1));
                        float3 s = gSource.Load(int3(p, 0)).rgb;
                        lo = min(lo, s); hi = max(hi, s);
                    }
                float3 tol = (hi - lo) * 0.1 + 1e-4;
                delta = clamp(base + delta, lo - tol, hi + tol) - base;
            }
        }

        gTarget[id.xy] = float4(lerp(history, delta, a), weaponFlag);
        return;
    }

    if (gMode == 1)
    {
        float4 base  = gSource.Load(int3(id.xy, 0));
        float2 uv = (float2(id.xy) + 0.5) / float2(gWidth, gHeight);
        float4 hist4 = gModel.SampleLevel(gLinear, uv, 0);
        float3 delta = SanitizeFinite3(hist4.rgb, float3(0.0, 0.0, 0.0));

        // Alpha carries the smoothing's weapon flag (0 = first-person weapon) to the carrier encode.
        gTarget[id.xy] = float4(max(base.rgb + delta * gTransferStrength, 0.0), isfinite(hist4.a) ? hist4.a : 1.0);
        return;
    }

    gTarget[id.xy] = gSource.Load(int3(id.xy, 0));
}
