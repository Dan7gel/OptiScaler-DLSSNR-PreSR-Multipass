// ResidualAcrossRR v2 -- the MV-reprojected temporal accumulator for the pre-SR NR residual.
//
// Deliberately a SEPARATE shader from dlssnr.hlsl. Regenerating dlssnr.hlsl's blob with a current
// dxc produces materially different DXIL from the committed one (older compiler), and that shader
// carries every NR path -- post-SR, pre-SR, RR, DeferredDLSS. These two experimental
// modes get their own tiny blob and a second compute PSO instead, so the battle-tested one is
// never touched. The cbuffer and bindings mirror dlssnr.hlsl exactly so DlssNr_Dx12's existing
// root signature and descriptor table are reused as-is; only gResidualBlend is appended, and it
// fits inside DlssNrConstants' existing 256-byte alignment with no size change.
//
//   gMode == 0  Accumulate: (edited - original) blended into the MV-reprojected history layer.
//               history_t = lerp( reproject(history_{t-1}), edited - original, blend )
//               The per-frame ray-trace noise term of (edited - original) is temporally
//               uncorrelated and averages to zero; the enhancement term follows geometry and
//               persists. Invalid reprojection (off-screen / bad MV) -> the
//               history is treated as zero at that pixel and rebuilds over the next frames.
//   gMode == 1  Apply: base + delta * gTransferStrength, clamped non-negative. Run after RR+SR
//               with the upscaled history layer as the delta.

#ifdef VK_MODE
[[vk::binding(0, 0)]]
cbuffer Params : register(b0, space0)
#else
cbuffer Params : register(b0)
#endif
{
    uint  gMode;
    float gWhitePoint;
    uint  gWidth;
    uint  gHeight;
    float gTransferStrength;
    float gColourStrength;
    uint  gDebugView;
    float gMaxRatio;
    uint  gPassthrough;
    float gMvScaleX;
    float gMvScaleY;
    uint  gGuideWidth;
    uint  gGuideHeight;
    uint  gCompareMode;
    float gCompareSplit;
    float gCompareZoom;
    uint  gCompareSwap;
    uint  gTransfer;
    float gDebugScale;
    uint  gReversibleMode;
    uint  gApplyModel;
    uint  gUseGameExposure;
    float gExposurePreMul;
    uint  gSkinProtection;
    uint  gShowSkinMask;
    float gSkinDetail;
    float gSkinColour;
    float gEnvironmentDetail;
    float gEnvironmentColour;
    float gResidualBlend;   // v2 only: history blend rate, 0..1. 1 == no accumulation (== v1).
    uint gResidualHistoryValid;
    uint gResidualMotionBaseX;
    uint gResidualMotionBaseY;
    // Padding to the shared layout, then the accumulate's own tone blend.
    float gGlowSuppression; float gGlowRadius; float gHaloGuard; float gResidualShadow; float gResidualLight;
    float gHueStability; uint gEnlargedInput; uint gDriftMeter;
    float gResidualLfBlend; // blend rate of the edit's low-frequency (tone) part; 1 = same as detail
    float gResidualJitterDX; // (previous - current) jitter of a jittered frame, in its pixels
    float gResidualJitterDY;
};

// Same registers and the same SPIR-V binding numbers as dlssnr.hlsl, including the slots these
// modes do not read (gExposure t4, gKeep u1) -- DispatchResidualPass binds a stand-in into them
// exactly as DispatchPass does, and a future Vulkan host path needs the numbering to line up.
#ifdef VK_MODE
[[vk::binding(1, 0)]]
#endif
Texture2D<float4>   gSource   : register(t0);  // accumulate: the untouched pre-SR frame. apply: the RR+SR output.
#ifdef VK_MODE
[[vk::binding(2, 0)]]
#endif
Texture2D<float4>   gModel    : register(t1);  // accumulate: the NR-edited frame. apply: the upscaled delta layer.
#ifdef VK_MODE
[[vk::binding(3, 0)]]
#endif
Texture2D<float4>   gOriginal : register(t2);  // accumulate: the previous history layer.
#ifdef VK_MODE
[[vk::binding(4, 0)]]
#endif
Texture2D<float4>   gMotion   : register(t3);  // raw game motion; active size, offsets and scale come from the host.
#ifndef VK_MODE
Texture2D<float4>   gExposure : register(t4);  // unused here; bound for descriptor-table parity.
#endif
#ifdef VK_MODE
[[vk::binding(5, 0)]]
#endif
RWTexture2D<float4> gTarget   : register(u0);  // accumulate: the new history layer. apply: the composed frame.
#ifdef VK_MODE
[[vk::binding(6, 0)]]
#endif
RWTexture2D<float4> gKeep     : register(u1);  // unused here; bound for descriptor-table parity.
#ifdef VK_MODE
[[vk::binding(7, 0)]]
#endif
SamplerState        gLinear   : register(s0);  // history is sampled at the reprojected coordinate.

float  SanitizeFinite(float v, float fallback)   { return isfinite(v) ? v : fallback; }
float3 SanitizeFinite3(float3 v, float3 fallback)
{
    return float3(SanitizeFinite(v.x, fallback.x), SanitizeFinite(v.y, fallback.y),
                  SanitizeFinite(v.z, fallback.z));
}

[numthreads(8, 8, 1)]
void CSMain(uint3 id : SV_DispatchThreadID)
{
    if (id.x >= gWidth || id.y >= gHeight)
        return;

    if (gMode == 0)
    {
        float3 delta = SanitizeFinite3(gModel.Load(int3(id.xy, 0)).rgb -
                                       gSource.Load(int3(id.xy, 0)).rgb, float3(0.0, 0.0, 0.0));
        // Bounds of the current edit over 3x3: the reprojected history is clamped into them, so the
        // accumulator denoises the edit but cannot ghost or lag beyond what the edit locally is now.
        float3 lo = delta, hi = delta, sum = 0.0, sumSq = 0.0;
        [unroll]
        for (int oy = -1; oy <= 1; ++oy)
            [unroll]
            for (int ox = -1; ox <= 1; ++ox)
            {
                int2 p = clamp(int2(id.xy) + int2(ox, oy), int2(0, 0), int2(int(gWidth) - 1, int(gHeight) - 1));
                float3 n = SanitizeFinite3(gModel.Load(int3(p, 0)).rgb - gSource.Load(int3(p, 0)).rgb, delta);
                lo = min(lo, n);
                hi = max(hi, n);
                sum += n;
                sumSq += n * n;
            }
        float3 slack = (hi - lo) * 0.15 + 1e-4;
        // Trimmed mean of the 3x3 (highest and lowest dropped): the edit's isolated noise pixels vanish
        // before accumulation, its edges stay, since a real edge fills most of the nine samples.
        delta = (sum - lo - hi) / 7.0;
        // Coherence of the edit over the 3x3: a real edge or gradient has neighbours that agree (mean
        // dominates the spread); path-traced sparkle in foliage or on a sunlit weapon has neighbours that
        // disagree (spread dominates). Incoherent edits are taken from the wider 5x5 mean below.
        float3 meanN = sum / 9.0;
        float3 varN = max(sumSq / 9.0 - meanN * meanN, 0.0);
        float m2 = dot(meanN, meanN), v2 = dot(varN, float3(1.0, 1.0, 1.0));
        float incoherent = saturate(v2 / (v2 + 2.0 * m2 + 1e-6) * 1.6 - 0.15);

        float2 uv = (float2(id.xy) + 0.5) / float2(gWidth, gHeight);
        uint2 guideSize = uint2(gGuideWidth, gGuideHeight);
        uint2 guidePos = min(uint2(uv * guideSize), guideSize - 1) +
                         uint2(gResidualMotionBaseX, gResidualMotionBaseY);
        float2 motion = gMotion.Load(int3(guidePos, 0)).xy * float2(gMvScaleX, gMvScaleY);
        // A jittered frame samples the scene at (pixel + jitter): the same content sat at
        // (pixel + motion + jitterPrev - jitterCur) last frame.
        float2 prevUV = uv + motion + float2(gResidualJitterDX, gResidualJitterDY) / float2(gWidth, gHeight);

        bool valid = gResidualHistoryValid != 0 && all(isfinite(motion)) && all(abs(motion) < 2.0) &&
                     all(prevUV >= 0.0) && all(prevUV <= 1.0);

        float3 history = valid ? gOriginal.SampleLevel(gLinear, prevUV, 0).rgb : float3(0.0, 0.0, 0.0);
        history = SanitizeFinite3(history, float3(0.0, 0.0, 0.0));

        // The edit has two parts that want different stability. Its low-frequency part is tone: how
        // bright, how much highlight lift, how much shadow lift over a region. That part must not react
        // frame by frame to what the model was shown (motion blur changes it the instant the camera
        // moves): it is accumulated slowly. Its high-frequency part is detail: accumulated at the normal
        // rate and clamped to the current edit's local range, so it denoises but never ghosts.
        float lfBlend = clamp(gResidualLfBlend, 0.0, 1.0);
        // Highlights: the brightest regions carry the most path-traced noise into the edit, and hold no
        // fine detail worth keeping in it (they sit at or near clipping). Above half the white point the
        // per-frame edit is taken from a 5x5 local mean in proportion to brightness.
        float3 srcHere = gSource.Load(int3(id.xy, 0)).rgb;
        float lumaHere = dot(srcHere, float3(0.2126, 0.7152, 0.0722));
        float bright = saturate((lumaHere / max(gWhitePoint, 1e-4) - 0.35) / 0.4);
        // Smoothing weight: incoherent edit, or a bright pixel (the sparkle's home), either or both.
        float smoothW = saturate(max(incoherent, bright * 0.7));
        // Edge-aware smoothing of the edit (5x5, stride 1): each neighbour weighted by how close its
        // luminance is to this pixel's, so the average never crosses a silhouette (no halo on a moving
        // weapon or object edge). Applied in proportion to smoothW.
        if (smoothW > 0.0)
        {
            float3 accS = 0.0;
            float wS = 0.0;
            float tol = max(lumaHere * 0.25, 1e-3);
            [unroll]
            for (int sy = -2; sy <= 2; ++sy)
                [unroll]
                for (int sx = -2; sx <= 2; ++sx)
                {
                    int2 p = clamp(int2(id.xy) + int2(sx, sy), int2(0, 0), int2(int(gWidth) - 1, int(gHeight) - 1));
                    float3 srcP = gSource.Load(int3(p, 0)).rgb;
                    float lumaP = dot(srcP, float3(0.2126, 0.7152, 0.0722));
                    float dl = (lumaP - lumaHere) / tol;
                    float w = exp(-dl * dl);
                    accS += w * SanitizeFinite3(gModel.Load(int3(p, 0)).rgb - srcP, delta);
                    wS += w;
                }
            float3 smoothCur = accS / max(wS, 1e-4);
            delta = lerp(delta, smoothCur, smoothW);
            lo = min(lo, delta);
            hi = max(hi, delta);
        }
        // Tone (low-frequency) part, only when its own blend is active.
        float3 lfCur = 0.0, lfHist = 0.0;
        if (lfBlend < 0.999)
        {
            [unroll]
            for (int by = -2; by <= 2; ++by)
                [unroll]
                for (int bx = -2; bx <= 2; ++bx)
                {
                    int2 p = clamp(int2(id.xy) + int2(bx, by) * 2, int2(0, 0), int2(int(gWidth) - 1, int(gHeight) - 1));
                    lfCur += SanitizeFinite3(gModel.Load(int3(p, 0)).rgb - gSource.Load(int3(p, 0)).rgb, delta);
                    if (valid)
                        lfHist += SanitizeFinite3(gOriginal.SampleLevel(gLinear, prevUV + float2(bx, by) * 2.0 / float2(gWidth, gHeight), 0).rgb, 0.0);
                }
            lfCur /= 25.0;
            lfHist /= 25.0;
        }
        float3 lfC = lfBlend < 0.999 ? lfCur : 0.0, lfH = lfBlend < 0.999 ? lfHist : 0.0;
        float3 hfCur = delta - lfC;
        // Rejection: a history that lands well outside the current local range was reprojected along a
        // wrong vector (view models, disocclusion). It is not clamped into place; the pixel restarts
        // from the fresh edit. Prevents trails on the weapon and behind moving objects.
        float3 rawH = history - lfH;
        float3 outside = max(lo - lfC - slack - rawH, 0.0) + max(rawH - (hi - lfC + slack), 0.0);
        float rangeMag = length(hi - lo) + 1e-3;
        float mismatch = length(outside) / rangeMag;
        if (mismatch > 0.5)
            valid = false;
        float3 hfHist = clamp(rawH, lo - lfC - slack, hi - lfC + slack);
        // Incoherent (noisy) pixels take more history: their blend rate halves. Clamp and rejection
        // still bound it, so this cannot trail on edges or moving objects.
        float aHf = valid ? clamp(gResidualBlend, 0.0, 1.0) * (1.0 - 0.5 * incoherent) : 1.0;
        float aLf = valid ? (lfBlend < 0.999 ? lfBlend : aHf) : 1.0;
        float3 blended = lerp(lfH, lfC, aLf) + lerp(hfHist, hfCur, aHf);

        gTarget[id.xy] = float4(blended, 1.0);
        return;
    }

    if (gMode == 1)
    {
        float4 base  = gSource.Load(int3(id.xy, 0));
        float2 uv = (float2(id.xy) + 0.5) / float2(gWidth, gHeight);
        float3 delta = SanitizeFinite3(gModel.SampleLevel(gLinear, uv, 0).rgb, float3(0.0, 0.0, 0.0));

        gTarget[id.xy] = float4(max(base.rgb + delta * gTransferStrength, 0.0), base.a);
        return;
    }

    gTarget[id.xy] = gSource.Load(int3(id.xy, 0));
}
