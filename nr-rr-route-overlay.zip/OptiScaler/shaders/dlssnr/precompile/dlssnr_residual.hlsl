// ResidualAcrossRR v2 -- the MV-reprojected temporal accumulator for the pre-SR NR residual.
//
// Deliberately a SEPARATE shader from dlssnr.hlsl. Regenerating dlssnr.hlsl's blob with a current
// dxc produces materially different DXIL from the committed one (older compiler), and that shader
// carries every NR path -- post-SR, pre-SR, RR, DeferredDLSS. These two experimental
// modes get their own tiny blob and a second compute PSO instead, so the battle-tested one is
// never touched. The cbuffer and bindings mirror dlssnr.hlsl exactly so DlssNr_Dx12's existing
// root signature and descriptor table are reused as-is; only gResidualBlend is appended, and it
// fits inside DlssNrConstants' existing 256-byte alignment with no size change.
//
//   gMode == 0  Accumulate: (edited - original) blended into the MV-reprojected history layer.
//               history_t = lerp( reproject(history_{t-1}), edited - original, blend )
//               The per-frame ray-trace noise term of (edited - original) is temporally
//               uncorrelated and averages to zero; the enhancement term follows geometry and
//               persists. Invalid reprojection (off-screen / bad MV) -> the
//               history is treated as zero at that pixel and rebuilds over the next frames.
//   gMode == 1  Apply: base + delta * gTransferStrength, clamped non-negative. Run after RR+SR
//               with the upscaled history layer as the delta.

#ifdef VK_MODE
[[vk::binding(0, 0)]]
cbuffer Params : register(b0, space0)
#else
cbuffer Params : register(b0)
#endif
{
    uint  gMode;
    float gWhitePoint;
    uint  gWidth;
    uint  gHeight;
    float gTransferStrength;
    float gColourStrength;
    uint  gDebugView;
    float gMaxRatio;
    uint  gPassthrough;
    float gMvScaleX;
    float gMvScaleY;
    uint  gGuideWidth;
    uint  gGuideHeight;
    uint  gCompareMode;
    float gCompareSplit;
    float gCompareZoom;
    uint  gCompareSwap;
    uint  gTransfer;
    float gDebugScale;
    uint  gReversibleMode;
    uint  gApplyModel;
    uint  gUseGameExposure;
    float gExposurePreMul;
    uint  gSkinProtection;
    uint  gShowSkinMask;
    float gSkinDetail;
    float gSkinColour;
    float gEnvironmentDetail;
    float gEnvironmentColour;
    float gResidualBlend;   // v2 only: history blend rate, 0..1. 1 == no accumulation (== v1).
    uint gResidualHistoryValid;
    uint gResidualMotionBaseX;
    uint gResidualMotionBaseY;
    // Padding to the shared layout, then the accumulate's own fields.
    float gGlowSuppression; float gGlowRadius; float gHaloGuard; float gResidualShadow; float gResidualLight;
    float gHueStability; uint gEnlargedInput; uint gDriftMeter;
    float gResidualJitterDX; // (previous - current) jitter of a jittered frame, in its pixels
    float gResidualJitterDY;

};

// Same registers and the same SPIR-V binding numbers as dlssnr.hlsl, including the slots these
// modes do not read (gExposure t4, gKeep u1) -- DispatchResidualPass binds a stand-in into them
// exactly as DispatchPass does, and a future Vulkan host path needs the numbering to line up.
#ifdef VK_MODE
[[vk::binding(1, 0)]]
#endif
Texture2D<float4>   gSource   : register(t0);  // accumulate: the untouched pre-SR frame. apply: the RR+SR output.
#ifdef VK_MODE
[[vk::binding(2, 0)]]
#endif
Texture2D<float4>   gModel    : register(t1);  // accumulate: the NR-edited frame. apply: the upscaled delta layer.
#ifdef VK_MODE
[[vk::binding(3, 0)]]
#endif
Texture2D<float4>   gOriginal : register(t2);  // accumulate: the previous history layer.
#ifdef VK_MODE
[[vk::binding(4, 0)]]
#endif
Texture2D<float4>   gMotion   : register(t3);  // raw game motion; active size, offsets and scale come from the host.
#ifndef VK_MODE
Texture2D<float4>   gExposure : register(t4);  // unused here; bound for descriptor-table parity.
#endif
#ifdef VK_MODE
[[vk::binding(5, 0)]]
#endif
RWTexture2D<float4> gTarget   : register(u0);  // accumulate: the new history layer. apply: the composed frame.
#ifdef VK_MODE
[[vk::binding(6, 0)]]
#endif
RWTexture2D<float4> gKeep     : register(u1);  // unused here; bound for descriptor-table parity.
#ifdef VK_MODE
[[vk::binding(7, 0)]]
#endif
SamplerState        gLinear   : register(s0);  // history is sampled at the reprojected coordinate.

float  SanitizeFinite(float v, float fallback)   { return isfinite(v) ? v : fallback; }
float3 SanitizeFinite3(float3 v, float3 fallback)
{
    return float3(SanitizeFinite(v.x, fallback.x), SanitizeFinite(v.y, fallback.y),
                  SanitizeFinite(v.z, fallback.z));
}

[numthreads(8, 8, 1)]
void CSMain(uint3 id : SV_DispatchThreadID)
{
    if (id.x >= gWidth || id.y >= gHeight)
        return;

    if (gMode == 0)
    {
        float3 deltaRaw = SanitizeFinite3(gModel.Load(int3(id.xy, 0)).rgb -
                                          gSource.Load(int3(id.xy, 0)).rgb, float3(0.0, 0.0, 0.0));
        float3 delta = deltaRaw;

        float2 uv = (float2(id.xy) + 0.5) / float2(gWidth, gHeight);
        uint2 guideSize = uint2(gGuideWidth, gGuideHeight);
        uint2 guidePos = min(uint2(uv * guideSize), guideSize - 1) +
                         uint2(gResidualMotionBaseX, gResidualMotionBaseY);
        float2 motion = gMotion.Load(int3(guidePos, 0)).xy * float2(gMvScaleX, gMvScaleY);
        // A jittered frame samples the scene at (pixel + jitter): the same content sat at
        // (pixel + motion + jitterPrev - jitterCur) last frame.
        float2 prevUV = uv + motion + float2(gResidualJitterDX, gResidualJitterDY) / float2(gWidth, gHeight);

        bool valid = gResidualHistoryValid != 0 && all(isfinite(motion)) && all(abs(motion) < 2.0) &&
                     all(prevUV >= 0.0) && all(prevUV <= 1.0);

        float4 hist4 = valid ? gOriginal.SampleLevel(gLinear, prevUV, 0) : float4(0.0, 0.0, 0.0, 0.0);
        float3 history = SanitizeFinite3(hist4.rgb, float3(0.0, 0.0, 0.0));
        // Temporal noise estimate of this pixel's edit (alpha of the history): the running mean of the
        // squared difference between the raw edit's luminance and the stabilised one. Clean areas stay
        // near zero and are left exactly alone; only pixels whose edit keeps disagreeing with its own
        // history (sunlit weapon, foliage, far fences) are treated.
        float varPrev = valid && isfinite(hist4.a) ? max(hist4.a, 0.0) : 0.0;
        const float3 lw = float3(0.2126, 0.7152, 0.0722);
        float rawL = dot(deltaRaw, lw), histL = dot(history, lw);
        float d2 = (rawL - histL) * (rawL - histL);
        float varNow = valid ? lerp(varPrev, d2, 0.1) : d2 * 0.5;
        float sigma = sqrt(max(varNow, 0.0));
        // Noise relative to the picture's scale: 1% of the white point is where sparkle starts to show.
        // No white point given (the deferred route's accumulate): no treatment, plain accumulation.
        float noisy = (gWhitePoint > 0.0 && gTransfer != 0) ? saturate(sigma / max(0.01 * gWhitePoint, 1e-5) - 0.3) : 0.0;

        // Bounds of the current edit over 3x3: the reprojected history is clamped into them, so the
        // accumulator cannot ghost or lag beyond what the edit locally is now.
        float3 lo = delta, hi = delta, sum = 0.0, sumSq = 0.0;
        [unroll]
        for (int oy = -1; oy <= 1; ++oy)
            [unroll]
            for (int ox = -1; ox <= 1; ++ox)
            {
                int2 p = clamp(int2(id.xy) + int2(ox, oy), int2(0, 0), int2(int(gWidth) - 1, int(gHeight) - 1));
                float3 n = SanitizeFinite3(gModel.Load(int3(p, 0)).rgb - gSource.Load(int3(p, 0)).rgb, delta);
                lo = min(lo, n);
                hi = max(hi, n);
                sum += n;
                sumSq += n * n;
            }
        // Coherence over the 3x3: neighbours agree on a real edge or gradient, disagree on sparkle.
        float3 meanN = sum / 9.0;
        float3 varN = max(sumSq / 9.0 - meanN * meanN, 0.0);
        float m2 = dot(meanN, meanN), v2 = dot(varN, float3(1.0, 1.0, 1.0));
        float incoherent = saturate(v2 / (v2 + 2.0 * m2 + 1e-6) * 1.6 - 0.15);
        // Treatment strength: the temporal estimate is the authority; spatial incoherence confirms it.
        // A clean pixel (both near zero) gets no treatment at all: its edit passes through unchanged.
        float treat = (gWhitePoint > 0.0 && gTransfer != 0)
                          ? saturate(max(noisy, incoherent * noisy + 0.5 * incoherent * incoherent)) : 0.0;
        // Clamp slack: tight where clean, opened by the measured noise where noisy, so the smooth history
        // is not dragged back into the current frame's noise.
        float3 slack = (hi - lo) * 0.15 + 1e-4 + treat * 2.0 * sigma;
        if (treat > 0.0)
        {
            // Trimmed mean of the 3x3 (highest and lowest dropped): isolated noise pixels vanish.
            delta = lerp(delta, (sum - lo - hi) / 7.0, treat);
            // Edge-aware 5x5 (stride 1) smoothing, weighted by luminance similarity of the source, so it
            // never crosses a silhouette; its share grows with the measured noise.
            float3 srcHere = gSource.Load(int3(id.xy, 0)).rgb;
            float lumaHere = dot(srcHere, lw);
            float3 accS = 0.0;
            float wS = 0.0;
            float tol = max(lumaHere * 0.25, 1e-3);
            [unroll]
            for (int sy = -2; sy <= 2; ++sy)
                [unroll]
                for (int sx = -2; sx <= 2; ++sx)
                {
                    int2 p = clamp(int2(id.xy) + int2(sx, sy), int2(0, 0), int2(int(gWidth) - 1, int(gHeight) - 1));
                    float3 srcP = gSource.Load(int3(p, 0)).rgb;
                    float lumaP = dot(srcP, lw);
                    float dl = (lumaP - lumaHere) / tol;
                    float w = exp(-dl * dl);
                    accS += w * SanitizeFinite3(gModel.Load(int3(p, 0)).rgb - srcP, delta);
                    wS += w;
                }
            delta = lerp(delta, accS / max(wS, 1e-4), treat);
            lo = min(lo, delta);
            hi = max(hi, delta);
        }
        // Soft rejection: a history landing well outside the current local range (beyond the slack the
        // noise estimate allows) was reprojected along a wrong vector (view models, disocclusion).
        float3 outside = max(lo - slack - history, 0.0) + max(history - (hi + slack), 0.0);
        float reject = saturate((length(outside) / (length(hi - lo) + 2.0 * sigma + 1e-3) - 0.15) / 0.6);
        history = clamp(history, lo - slack, hi + slack);
        // Blend: noisy pixels take more history (down to a third of the rate); clean pixels keep the
        // configured rate; rejected ones take the fresh edit; no usable history takes it at once.
        float rate = clamp(gResidualBlend, 0.0, 1.0) * (1.0 - 0.67 * treat);
        float a = valid ? lerp(rate, 1.0, reject) : 1.0;

        gTarget[id.xy] = float4(lerp(history, delta, a), varNow);
        return;
    }

    if (gMode == 1)
    {
        float4 base  = gSource.Load(int3(id.xy, 0));
        float2 uv = (float2(id.xy) + 0.5) / float2(gWidth, gHeight);
        float3 delta = SanitizeFinite3(gModel.SampleLevel(gLinear, uv, 0).rgb, float3(0.0, 0.0, 0.0));

        gTarget[id.xy] = float4(max(base.rgb + delta * gTransferStrength, 0.0), base.a);
        return;
    }

    gTarget[id.xy] = gSource.Load(int3(id.xy, 0));
}
