// DLSS-NR temporal reuse (ULTIMATE77): the model runs every N-th frame; the frames between receive
// the last full pass's edit, reprojected along the game's motion vectors with acceptance tests and a
// box-filtered fill where the reprojection is rejected. The design and the tests follow BeliyG3's
// Optimizer FPS for DLSS5 temporal passes (MIT), re-expressed for the NR resolve's target space:
// everything here works on the frame the resolve writes (linear light on the linear routes).
//
// Modes:
//   0 Residual    R = nrOut - original, depth of this frame at the same pixel      -> gOut0 (R), gOut1 (depth)
//   1 Downsample  Rlow = box-filtered R, 1/16 per axis                              -> gOut0
//   2 Accumulate  acc = mv + accPrev(p + mv)  (or 0 when gResetAccum)                -> gOut0 (RG)
//   3 Compose     out = original + lerp(Rlow(p), R(p + acc), w)                      -> gOut0 (frame)
//
// Motion vectors point from the current frame to the previous one (NGX convention); "acc" is the
// displacement from the current frame back to the frame whose residual is stored, in frame pixels.

cbuffer TemporalConstants : register(b0)
{
    uint  gMode;
    uint  gWidth;          // frame (target) size
    uint  gHeight;
    uint  gGuideWidth;     // depth texture valid region
    uint  gGuideHeight;
    uint  gGuideBaseX;
    uint  gGuideBaseY;
    uint  gMotionWidth;    // motion texture valid region
    uint  gMotionHeight;
    uint  gMotionBaseX;
    uint  gMotionBaseY;
    uint  gDepthInverted;
    float gMvScaleX;       // motion units -> frame pixels
    float gMvScaleY;
    float gJitterDX;       // (pass jitter - current jitter) in frame pixels, pre-SR only; 0 otherwise
    float gJitterDY;
    uint  gLowWidth;       // Rlow size
    uint  gLowHeight;
    uint  gResetAccum;     // mode 2: write zero displacement
    uint  gLinear;         // 1: frame is linear light (luma ratio fill scaling applies)
    float gDepthTol;       // 0.05
    float gColourTol;      // 0.08
    float gFillStrength;   // 0..1: how much of the box residual is used where rejected
    float gBlendMax;       // pass-to-pass blend weight where the pixel barely moved (0.6)
    uint  gTexWidth;       // allocation size of the frame-sized private textures (>= gWidth/gHeight)
    uint  gTexHeight;
};

Texture2D<float4> gIn0 : register(t0);
Texture2D<float4> gIn1 : register(t1);
Texture2D<float4> gIn2 : register(t2);
Texture2D<float4> gIn3 : register(t3);
Texture2D<float4> gIn4 : register(t4);
Texture2D<float4> gIn5 : register(t5);
Texture2D<float4> gIn6 : register(t6);

// Small hash for the noise-rotated smoothing disc.
float Hash12(float2 p)
{
    float3 p3 = frac(float3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return frac((p3.x + p3.y) * p3.z);
}

RWTexture2D<float4> gOut0 : register(u0);
RWTexture2D<float4> gOut1 : register(u1);

SamplerState gLinearClamp : register(s0);

static const float3 kLuma = float3(0.2126, 0.7152, 0.0722);

// Normalised coordinate into the frame-sized private textures, which are allocated at the texture
// size (the active size can be smaller under dynamic or custom resolution).
float2 FrameUv(float2 p) { return (p + 0.5) / float2(gTexWidth, gTexHeight); }
float2 TexSize() { return float2(gTexWidth, gTexHeight); }

// Guide (depth) texel for a frame pixel.
int2 GuideTexel(float2 p)
{
    float2 g = p * float2(gGuideWidth, gGuideHeight) / float2(gWidth, gHeight);
    int2 t = int2(floor(g));
    t = clamp(t, int2(0, 0), int2(gGuideWidth, gGuideHeight) - 1);
    return t + int2(gGuideBaseX, gGuideBaseY);
}

int2 MotionTexel(float2 p)
{
    float2 g = p * float2(gMotionWidth, gMotionHeight) / float2(gWidth, gHeight);
    int2 t = int2(floor(g));
    t = clamp(t, int2(0, 0), int2(gMotionWidth, gMotionHeight) - 1);
    return t + int2(gMotionBaseX, gMotionBaseY);
}

// Motion vector at a frame pixel, in frame pixels, pointing to the previous frame.
float2 MotionAt(Texture2D<float4> motion, float2 p)
{
    float2 mv = motion.Load(int3(MotionTexel(p), 0)).xy;
    mv = (isfinite(mv.x) && isfinite(mv.y)) ? mv : 0.0;
    return mv * float2(gMvScaleX, gMvScaleY);
}

// Depth comparable across frames: larger = farther, in [0,1].
float DepthAt(Texture2D<float4> depthTex, float2 p)
{
    float d = depthTex.Load(int3(GuideTexel(p), 0)).r;
    d = isfinite(d) ? d : 1.0;
    return gDepthInverted != 0 ? 1.0 - d : d;
}

// Catmull-Rom with five bilinear taps (corner taps dropped, as in Jimenez's TAA). The residual is
// fine detail and a plain bilinear fetch at a fractional position blurs it by an amount that changes
// every frame; Catmull-Rom keeps it.
float4 SampleCatmullRom(Texture2D<float4> tex, float2 pos, float2 size)
{
    float2 samplePos = pos + 0.5;
    float2 texPos1 = floor(samplePos - 0.5) + 0.5;
    float2 f = samplePos - texPos1;
    float2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    float2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    float2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    float2 w3 = f * f * (-0.5 + 0.5 * f);
    float2 w12 = w1 + w2;
    float2 offset12 = w2 / w12;
    float2 texPos0 = texPos1 - 1.0;
    float2 texPos3 = texPos1 + 2.0;
    float2 texPos12 = texPos1 + offset12;
    float2 inv = 1.0 / size;
    float4 result = 0.0;
    result += tex.SampleLevel(gLinearClamp, texPos12 * inv, 0) * (w12.x * w12.y);
    result += tex.SampleLevel(gLinearClamp, float2(texPos0.x, texPos12.y) * inv, 0) * (w0.x * w12.y);
    result += tex.SampleLevel(gLinearClamp, float2(texPos3.x, texPos12.y) * inv, 0) * (w3.x * w12.y);
    result += tex.SampleLevel(gLinearClamp, float2(texPos12.x, texPos0.y) * inv, 0) * (w12.x * w0.y);
    result += tex.SampleLevel(gLinearClamp, float2(texPos12.x, texPos3.y) * inv, 0) * (w12.x * w3.y);
    float norm = w12.x * w12.y + w0.x * w12.y + w3.x * w12.y + w12.x * w0.y + w12.x * w3.y;
    return result / max(norm, 1e-4);
}

// Colour consistency between this frame's colour c and the residual frame's colour cf at the
// reprojected point: chromaticity first (a change of lighting moves luma, a disocclusion moves hue),
// luma at twice the tolerance.
float ColourWeight(float3 c, float3 cf)
{
    float lc = max(dot(c, kLuma), 1e-4);
    float lf = max(dot(cf, kLuma), 1e-4);
    float3 chromaC = c / lc;
    float3 chromaF = cf / lf;
    float dChroma = length(chromaC - chromaF) * 0.5;
    float dLuma = abs(log2(lc / lf)) * 0.5;
    float w = 1.0 - saturate((dChroma - gColourTol) / max(gColourTol, 1e-4));
    w *= 1.0 - saturate((dLuma - 2.0 * gColourTol) / max(2.0 * gColourTol, 1e-4));
    return saturate(w);
}

// Depth consistency with a smooth fall-off from the tolerance to twice it (thin geometry gives noisy depth).
float DepthWeight(float dNow, float dThen)
{
    float rel = abs(dNow - dThen) / max(max(dNow, dThen), 1e-4);
    return 1.0 - saturate((rel - gDepthTol) / max(gDepthTol, 1e-4));
}

[numthreads(8, 8, 1)]
void CSMain(uint3 id : SV_DispatchThreadID)
{
    // ---------------------------------------------------------------- 0: residual of a full pass
    if (gMode == 0)
    {
        if (id.x >= gWidth || id.y >= gHeight) return;
        float3 outC = gIn0.Load(int3(id.xy, 0)).rgb;   // resolved output
        float3 orig = gIn1.Load(int3(id.xy, 0)).rgb;   // original (frame as it arrived)
        float3 r = outC - orig;
        r = (isfinite(r.x) && isfinite(r.y) && isfinite(r.z)) ? r : 0.0;
        float dNow = DepthAt(gIn2, float2(id.xy));

        // Pass-to-pass blend: the previous pass's residual moved to this frame, Catmull-Rom resampled,
        // clamped to the 3x3 neighbourhood of the new residual and used only where depth still matches.
        // Adaptive weight: gBlendMax where the pixel moved under 2 px with unchanged colour, fading out by
        // 6 px of motion or half the colour tolerance. This stops the model's answers snapping between
        // passes on a talking face.
        if (gBlendMax > 0.0)
        {
            float2 p = float2(id.xy);
            float2 size = float2(gWidth, gHeight);
            float4 acc = gIn4.Load(int3(id.xy, 0));
            float2 q = p + acc.xy + float2(gJitterDX, gJitterDY);
            if (acc.w > 0.5 && q.x >= 0.0 && q.y >= 0.0 && q.x < size.x && q.y < size.y)
            {
                float dThen = gIn5.SampleLevel(gLinearClamp, (q + 0.5) / TexSize(), 0).r;
                float3 cThen = gIn6.SampleLevel(gLinearClamp, (q + 0.5) / TexSize(), 0).rgb;
                float wd = DepthWeight(dNow, dThen);
                float wc = ColourWeight(orig, cThen);
                float motionPx = length(acc.xy);
                float wMotion = 1.0 - saturate((motionPx - 2.0) / 4.0);
                float wColour = 1.0 - saturate((1.0 - wc) / 0.5);
                float w = gBlendMax * wd * wMotion * wColour;
                if (w > 0.001)
                {
                    float3 rPrev = SampleCatmullRom(gIn3, q, TexSize()).rgb;
                    float3 lo = r, hi = r;
                    [unroll] for (int oy = -1; oy <= 1; ++oy)
                    [unroll] for (int ox = -1; ox <= 1; ++ox)
                    {
                        int2 pp = clamp(int2(id.xy) + int2(ox, oy), int2(0, 0), int2(size) - 1);
                        float3 rn = gIn0.Load(int3(pp, 0)).rgb - gIn1.Load(int3(pp, 0)).rgb;
                        rn = (isfinite(rn.x) && isfinite(rn.y) && isfinite(rn.z)) ? rn : r;
                        lo = min(lo, rn);
                        hi = max(hi, rn);
                    }
                    rPrev = clamp(rPrev, lo, hi);
                    r = lerp(r, rPrev, w);
                }
            }
        }
        gOut0[id.xy] = float4(r, 1.0);
        gOut1[id.xy] = float4(dNow, 0.0, 0.0, 0.0);
        return;
    }

    // ---------------------------------------------------------------- 6: model motion from the chain
    // Writes the motion texture handed to the model: the displacement to the last kick frame in the
    // game's motion units at motion-texture resolution (gOut0), and a frame-size snapshot of the chain
    // for the pass-to-pass blend (gOut1). Thread grid = motion texture.
    if (gMode == 6)
    {
        if (id.x >= gMotionWidth || id.y >= gMotionHeight) return;
        float2 fp = (float2(id.xy) + 0.5) * float2(gWidth, gHeight) / float2(gMotionWidth, gMotionHeight) - 0.5;
        float4 acc = gIn0.SampleLevel(gLinearClamp, FrameUv(fp), 0);
        float2 mvUnits = acc.xy / float2(max(abs(gMvScaleX), 1e-6) * sign(gMvScaleX), max(abs(gMvScaleY), 1e-6) * sign(gMvScaleY));
        gOut0[id.xy + uint2(gMotionBaseX, gMotionBaseY)] = float4(acc.w > 0.5 ? mvUnits : 0.0, 0.0, 0.0);
        // Snapshot: one frame pixel per motion texel is not enough, so every thread also copies its
        // own frame-size footprint.
        uint2 f0 = uint2(floor(float2(id.xy) * float2(gWidth, gHeight) / float2(gMotionWidth, gMotionHeight)));
        uint2 f1 = uint2(floor(float2(id.xy + 1) * float2(gWidth, gHeight) / float2(gMotionWidth, gMotionHeight)));
        for (uint y = f0.y; y < min(f1.y, gHeight); ++y)
            for (uint x = f0.x; x < min(f1.x, gWidth); ++x)
                gOut1[uint2(x, y)] = gIn0.Load(int3(x, y, 0));
        return;
    }

    // ---------------------------------------------------------------- 1: box-filtered residual
    if (gMode == 1)
    {
        if (id.x >= gLowWidth || id.y >= gLowHeight) return;
        uint2 start = id.xy * 16;
        float3 sum = 0.0;
        float n = 0.0;
        [loop] for (uint y = 0; y < 16; y += 2)
        [loop] for (uint x = 0; x < 16; x += 2)
        {
            uint2 p = start + uint2(x, y);
            if (p.x < gWidth && p.y < gHeight)
            {
                sum += gIn0.Load(int3(p, 0)).rgb;
                n += 1.0;
            }
        }
        gOut0[id.xy] = float4(n > 0.0 ? sum / n : 0.0, 1.0);
        return;
    }

    // ---------------------------------------------------------------- 2: accumulate displacement
    if (gMode == 2)
    {
        if (id.x >= gWidth || id.y >= gHeight) return;
        if (gResetAccum != 0)
        {
            gOut0[id.xy] = float4(0.0, 0.0, 0.0, 1.0);
            return;
        }
        float2 p = float2(id.xy);
        float2 mv = MotionAt(gIn1, p);
        float2 prev = p + mv;
        float2 accPrev = 0.0;
        float valid = 0.0;
        if (prev.x >= 0.0 && prev.y >= 0.0 && prev.x < (float) gWidth && prev.y < (float) gHeight)
        {
            float4 a = gIn0.SampleLevel(gLinearClamp, FrameUv(prev), 0);
            accPrev = a.xy;
            valid = a.w; // 0 where the chain was already broken
        }
        // The chain is validated link by link: a pixel whose previous position fell outside the frame,
        // or whose previous link was broken, carries no history.
        gOut0[id.xy] = float4(mv + accPrev, 0.0, valid > 0.5 ? 1.0 : 0.0);
        return;
    }

    // ---------------------------------------------------------------- 3: compose a skipped frame
    if (gMode == 3)
    {
        if (id.x >= gWidth || id.y >= gHeight) return;
        float2 p = float2(id.xy);
        float3 orig = gIn0.Load(int3(id.xy, 0)).rgb;        // current frame, as it arrived
        float4 acc = gIn3.Load(int3(id.xy, 0));             // displacement to the residual frame
        float2 q = p + acc.xy + float2(gJitterDX, gJitterDY);
        float2 size = float2(gWidth, gHeight);

        float w = acc.w;
        float3 rProj = 0.0;
        if (w > 0.5 && q.x >= 0.0 && q.y >= 0.0 && q.x < size.x && q.y < size.y)
        {
            float dNow = DepthAt(gIn4, p);
            float dThen = gIn5.SampleLevel(gLinearClamp, (q + 0.5) / TexSize(), 0).r;
            float3 cThen = gIn6.SampleLevel(gLinearClamp, (q + 0.5) / TexSize(), 0).rgb;
            float wd = DepthWeight(dNow, dThen);
            float wc = ColourWeight(orig, cThen);
            w = wd * wc;
            rProj = SampleCatmullRom(gIn1, q, TexSize()).rgb;
        }
        else
            w = 0.0;

        // Acceptance averaged over nine taps 3 px apart, so the boundary between reprojected residual
        // and fill is a ramp rather than a jittering edge.
        float wAvg = w;
        {
            float sum = 0.0;
            [unroll] for (int oy = -1; oy <= 1; ++oy)
            [unroll] for (int ox = -1; ox <= 1; ++ox)
            {
                float2 pp = p + float2(ox, oy) * 3.0;
                pp = clamp(pp, 0.0, size - 1.0);
                float4 a2 = gIn3.Load(int3(int2(pp), 0));
                float2 q2 = pp + a2.xy + float2(gJitterDX, gJitterDY);
                float w2 = 0.0;
                if (a2.w > 0.5 && q2.x >= 0.0 && q2.y >= 0.0 && q2.x < size.x && q2.y < size.y)
                {
                    float dN = DepthAt(gIn4, pp);
                    float dT = gIn5.SampleLevel(gLinearClamp, (q2 + 0.5) / TexSize(), 0).r;
                    float3 cN = gIn0.Load(int3(int2(pp), 0)).rgb;
                    float3 cT = gIn6.SampleLevel(gLinearClamp, (q2 + 0.5) / TexSize(), 0).rgb;
                    w2 = DepthWeight(dN, dT) * ColourWeight(cN, cT);
                }
                sum += w2;
            }
            wAvg = sum / 9.0;
        }

        // Fill for rejected pixels: the box-filtered residual, searched around the reprojected position
        // in two rings of eight points at 24 and 48 px for a depth match (a surface that IS in the pass
        // frame nearby), scaled by the luma ratio to the current frame and applied along the pixel's
        // own chroma, so a moving silhouette does not show a dark rim where the model's lift is missing.
        float3 rLow = gIn2.SampleLevel(gLinearClamp, FrameUv(p), 0).rgb;
        if (wAvg < 0.5)
        {
            float dNowC = DepthAt(gIn4, p);
            float2 centre = (acc.w > 0.5) ? q : p;
            float best = 0.0;
            [unroll] for (int ring = 1; ring <= 2; ++ring)
            [unroll] for (int k = 0; k < 8; ++k)
            {
                float ang = (float) k * 0.7853982;
                float2 s = centre + float2(cos(ang), sin(ang)) * (24.0 * (float) ring);
                if (s.x < 0.0 || s.y < 0.0 || s.x >= size.x || s.y >= size.y) continue;
                float dS = gIn5.SampleLevel(gLinearClamp, (s + 0.5) / TexSize(), 0).r;
                float wS = DepthWeight(dNowC, dS) / (float) ring;
                if (wS > best)
                {
                    best = wS;
                    rLow = gIn2.SampleLevel(gLinearClamp, (s + 0.5) / TexSize(), 0).rgb;
                }
            }
        }
        float lOrig = max(dot(orig, kLuma), 1e-4);
        float lLow = dot(rLow, kLuma);
        float3 rFill = (gLinear != 0) ? orig * (lLow / lOrig) : rLow;
        rFill *= gFillStrength;

        float3 r = lerp(rFill, rProj, wAvg);

        // Where acceptance is low, smooth the applied addition over 16 taps on a noise-rotated disc,
        // each tap weighted by the current frame's colour and depth similarity to this pixel, so the
        // patched region does not carry a visible texture of its own.
        if (wAvg < 0.5)
        {
            float rot = Hash12(p) * 6.2831853;
            float dNowC = DepthAt(gIn4, p);
            float3 sum = r;
            float wsum = 1.0;
            [unroll] for (int t = 0; t < 16; ++t)
            {
                float ang = rot + (float) t * 0.3926991;
                float rad = 2.0 + 4.0 * frac((float) t * 0.618034);
                float2 pp = clamp(p + float2(cos(ang), sin(ang)) * rad, 0.0, size - 1.0);
                float3 cN = gIn0.Load(int3(int2(pp), 0)).rgb;
                float dN = DepthAt(gIn4, pp);
                float4 aN = gIn3.Load(int3(int2(pp), 0));
                float2 qN = pp + aN.xy + float2(gJitterDX, gJitterDY);
                float3 rN = rFill;
                float wN = 0.0;
                if (aN.w > 0.5 && qN.x >= 0.0 && qN.y >= 0.0 && qN.x < size.x && qN.y < size.y)
                {
                    float dT = gIn5.SampleLevel(gLinearClamp, (qN + 0.5) / TexSize(), 0).r;
                    float3 cT = gIn6.SampleLevel(gLinearClamp, (qN + 0.5) / TexSize(), 0).rgb;
                    wN = DepthWeight(dN, dT) * ColourWeight(cN, cT);
                    rN = lerp(rFill, gIn1.SampleLevel(gLinearClamp, (qN + 0.5) / TexSize(), 0).rgb, wN);
                }
                float sim = ColourWeight(orig, cN) * DepthWeight(dNowC, dN);
                sum += rN * sim;
                wsum += sim;
            }
            r = sum / wsum;
        }
        float3 outC = orig + r;
        outC = (isfinite(outC.x) && isfinite(outC.y) && isfinite(outC.z)) ? outC : orig;
        gOut0[id.xy] = float4(max(outC, 0.0), gIn0.Load(int3(id.xy, 0)).a);
        return;
    }
}
