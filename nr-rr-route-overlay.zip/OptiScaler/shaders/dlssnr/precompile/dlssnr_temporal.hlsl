// DLSS-NR temporal reuse (ULTIMATE77): the model runs every N-th frame; the frames between receive
// the last full pass's edit, reprojected along the game's motion vectors with acceptance tests and a
// box-filtered fill where the reprojection is rejected. The design and the tests follow BeliyG3's
// Optimizer FPS for DLSS5 temporal passes (MIT), re-expressed for the NR resolve's target space:
// everything here works on the frame the resolve writes (linear light on the linear routes).
//
// Modes:
//   0 Residual    R = nrOut - original, depth of this frame at the same pixel      -> gOut0 (R), gOut1 (depth)
//   1 Downsample  Rlow = box-filtered R, 1/16 per axis                              -> gOut0
//   2 Accumulate  acc = mv + accPrev(p + mv)  (or 0 when gResetAccum)                -> gOut0 (RG)
//   3 Compose     out = original + lerp(Rlow(p), R(p + acc), w)                      -> gOut0 (frame)
//
// Motion vectors point from the current frame to the previous one (NGX convention); "acc" is the
// displacement from the current frame back to the frame whose residual is stored, in frame pixels.

cbuffer TemporalConstants : register(b0)
{
    uint  gMode;
    uint  gWidth;          // frame (target) size
    uint  gHeight;
    uint  gGuideWidth;     // depth texture valid region
    uint  gGuideHeight;
    uint  gGuideBaseX;
    uint  gGuideBaseY;
    uint  gMotionWidth;    // motion texture valid region
    uint  gMotionHeight;
    uint  gMotionBaseX;
    uint  gMotionBaseY;
    uint  gDepthInverted;
    float gMvScaleX;       // motion units -> frame pixels
    float gMvScaleY;
    float gJitterDX;       // (pass jitter - current jitter) in frame pixels, pre-SR only; 0 otherwise
    float gJitterDY;
    uint  gLowWidth;       // Rlow size
    uint  gLowHeight;
    uint  gResetAccum;     // mode 2: write zero displacement
    uint  gLinear;         // 1: frame is linear light (luma ratio fill scaling applies)
    float gDepthTol;       // 0.05
    float gColourTol;      // 0.08
    float gFillStrength;   // 0..1: how much of the box residual is used where rejected
    float gPad0;
};

Texture2D<float4> gIn0 : register(t0);
Texture2D<float4> gIn1 : register(t1);
Texture2D<float4> gIn2 : register(t2);
Texture2D<float4> gIn3 : register(t3);
Texture2D<float4> gIn4 : register(t4);
Texture2D<float4> gIn5 : register(t5);
Texture2D<float4> gIn6 : register(t6);

RWTexture2D<float4> gOut0 : register(u0);
RWTexture2D<float4> gOut1 : register(u1);

SamplerState gLinearClamp : register(s0);

static const float3 kLuma = float3(0.2126, 0.7152, 0.0722);

float2 FrameUv(float2 p) { return (p + 0.5) / float2(gWidth, gHeight); }

// Guide (depth) texel for a frame pixel.
int2 GuideTexel(float2 p)
{
    float2 g = p * float2(gGuideWidth, gGuideHeight) / float2(gWidth, gHeight);
    int2 t = int2(floor(g));
    t = clamp(t, int2(0, 0), int2(gGuideWidth, gGuideHeight) - 1);
    return t + int2(gGuideBaseX, gGuideBaseY);
}

int2 MotionTexel(float2 p)
{
    float2 g = p * float2(gMotionWidth, gMotionHeight) / float2(gWidth, gHeight);
    int2 t = int2(floor(g));
    t = clamp(t, int2(0, 0), int2(gMotionWidth, gMotionHeight) - 1);
    return t + int2(gMotionBaseX, gMotionBaseY);
}

// Motion vector at a frame pixel, in frame pixels, pointing to the previous frame.
float2 MotionAt(Texture2D<float4> motion, float2 p)
{
    float2 mv = motion.Load(int3(MotionTexel(p), 0)).xy;
    mv = (isfinite(mv.x) && isfinite(mv.y)) ? mv : 0.0;
    return mv * float2(gMvScaleX, gMvScaleY);
}

// Depth comparable across frames: larger = farther, in [0,1].
float DepthAt(Texture2D<float4> depthTex, float2 p)
{
    float d = depthTex.Load(int3(GuideTexel(p), 0)).r;
    d = isfinite(d) ? d : 1.0;
    return gDepthInverted != 0 ? 1.0 - d : d;
}

// Catmull-Rom with five bilinear taps (corner taps dropped, as in Jimenez's TAA). The residual is
// fine detail and a plain bilinear fetch at a fractional position blurs it by an amount that changes
// every frame; Catmull-Rom keeps it.
float4 SampleCatmullRom(Texture2D<float4> tex, float2 pos, float2 size)
{
    float2 samplePos = pos + 0.5;
    float2 texPos1 = floor(samplePos - 0.5) + 0.5;
    float2 f = samplePos - texPos1;
    float2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    float2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    float2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    float2 w3 = f * f * (-0.5 + 0.5 * f);
    float2 w12 = w1 + w2;
    float2 offset12 = w2 / w12;
    float2 texPos0 = texPos1 - 1.0;
    float2 texPos3 = texPos1 + 2.0;
    float2 texPos12 = texPos1 + offset12;
    float2 inv = 1.0 / size;
    float4 result = 0.0;
    result += tex.SampleLevel(gLinearClamp, texPos12 * inv, 0) * (w12.x * w12.y);
    result += tex.SampleLevel(gLinearClamp, float2(texPos0.x, texPos12.y) * inv, 0) * (w0.x * w12.y);
    result += tex.SampleLevel(gLinearClamp, float2(texPos3.x, texPos12.y) * inv, 0) * (w3.x * w12.y);
    result += tex.SampleLevel(gLinearClamp, float2(texPos12.x, texPos0.y) * inv, 0) * (w12.x * w0.y);
    result += tex.SampleLevel(gLinearClamp, float2(texPos12.x, texPos3.y) * inv, 0) * (w12.x * w3.y);
    float norm = w12.x * w12.y + w0.x * w12.y + w3.x * w12.y + w12.x * w0.y + w12.x * w3.y;
    return result / max(norm, 1e-4);
}

// Colour consistency between this frame's colour c and the residual frame's colour cf at the
// reprojected point: chromaticity first (a change of lighting moves luma, a disocclusion moves hue),
// luma at twice the tolerance.
float ColourWeight(float3 c, float3 cf)
{
    float lc = max(dot(c, kLuma), 1e-4);
    float lf = max(dot(cf, kLuma), 1e-4);
    float3 chromaC = c / lc;
    float3 chromaF = cf / lf;
    float dChroma = length(chromaC - chromaF) * 0.5;
    float dLuma = abs(log2(lc / lf)) * 0.5;
    float w = 1.0 - saturate((dChroma - gColourTol) / max(gColourTol, 1e-4));
    w *= 1.0 - saturate((dLuma - 2.0 * gColourTol) / max(2.0 * gColourTol, 1e-4));
    return saturate(w);
}

// Depth consistency with a smooth fall-off from the tolerance to twice it (thin geometry gives noisy depth).
float DepthWeight(float dNow, float dThen)
{
    float rel = abs(dNow - dThen) / max(max(dNow, dThen), 1e-4);
    return 1.0 - saturate((rel - gDepthTol) / max(gDepthTol, 1e-4));
}

[numthreads(8, 8, 1)]
void CSMain(uint3 id : SV_DispatchThreadID)
{
    // ---------------------------------------------------------------- 0: residual of a full pass
    if (gMode == 0)
    {
        if (id.x >= gWidth || id.y >= gHeight) return;
        float3 outC = gIn0.Load(int3(id.xy, 0)).rgb;   // resolved output
        float3 orig = gIn1.Load(int3(id.xy, 0)).rgb;   // original (frame as it arrived)
        float3 r = outC - orig;
        r = (isfinite(r.x) && isfinite(r.y) && isfinite(r.z)) ? r : 0.0;
        gOut0[id.xy] = float4(r, 1.0);
        gOut1[id.xy] = float4(DepthAt(gIn2, float2(id.xy)), 0.0, 0.0, 0.0);
        return;
    }

    // ---------------------------------------------------------------- 1: box-filtered residual
    if (gMode == 1)
    {
        if (id.x >= gLowWidth || id.y >= gLowHeight) return;
        uint2 start = id.xy * 16;
        float3 sum = 0.0;
        float n = 0.0;
        [loop] for (uint y = 0; y < 16; y += 2)
        [loop] for (uint x = 0; x < 16; x += 2)
        {
            uint2 p = start + uint2(x, y);
            if (p.x < gWidth && p.y < gHeight)
            {
                sum += gIn0.Load(int3(p, 0)).rgb;
                n += 1.0;
            }
        }
        gOut0[id.xy] = float4(n > 0.0 ? sum / n : 0.0, 1.0);
        return;
    }

    // ---------------------------------------------------------------- 2: accumulate displacement
    if (gMode == 2)
    {
        if (id.x >= gWidth || id.y >= gHeight) return;
        if (gResetAccum != 0)
        {
            gOut0[id.xy] = float4(0.0, 0.0, 0.0, 1.0);
            return;
        }
        float2 p = float2(id.xy);
        float2 mv = MotionAt(gIn1, p);
        float2 prev = p + mv;
        float2 accPrev = 0.0;
        float valid = 0.0;
        if (prev.x >= 0.0 && prev.y >= 0.0 && prev.x < (float) gWidth && prev.y < (float) gHeight)
        {
            float4 a = gIn0.SampleLevel(gLinearClamp, FrameUv(prev), 0);
            accPrev = a.xy;
            valid = a.w; // 0 where the chain was already broken
        }
        // The chain is validated link by link: a pixel whose previous position fell outside the frame,
        // or whose previous link was broken, carries no history.
        gOut0[id.xy] = float4(mv + accPrev, 0.0, valid > 0.5 ? 1.0 : 0.0);
        return;
    }

    // ---------------------------------------------------------------- 3: compose a skipped frame
    if (gMode == 3)
    {
        if (id.x >= gWidth || id.y >= gHeight) return;
        float2 p = float2(id.xy);
        float3 orig = gIn0.Load(int3(id.xy, 0)).rgb;        // current frame, as it arrived
        float4 acc = gIn3.Load(int3(id.xy, 0));             // displacement to the residual frame
        float2 q = p + acc.xy + float2(gJitterDX, gJitterDY);
        float2 size = float2(gWidth, gHeight);

        float w = acc.w;
        float3 rProj = 0.0;
        if (w > 0.5 && q.x >= 0.0 && q.y >= 0.0 && q.x < size.x && q.y < size.y)
        {
            float dNow = DepthAt(gIn4, p);
            float dThen = gIn5.SampleLevel(gLinearClamp, (q + 0.5) / size, 0).r;
            float3 cThen = gIn6.SampleLevel(gLinearClamp, (q + 0.5) / size, 0).rgb;
            float wd = DepthWeight(dNow, dThen);
            float wc = ColourWeight(orig, cThen);
            w = wd * wc;
            rProj = SampleCatmullRom(gIn1, q, size).rgb;
        }
        else
            w = 0.0;

        // Acceptance averaged over nine taps 3 px apart, so the boundary between reprojected residual
        // and fill is a ramp rather than a jittering edge.
        float wAvg = w;
        {
            float sum = 0.0;
            [unroll] for (int oy = -1; oy <= 1; ++oy)
            [unroll] for (int ox = -1; ox <= 1; ++ox)
            {
                float2 pp = p + float2(ox, oy) * 3.0;
                pp = clamp(pp, 0.0, size - 1.0);
                float4 a2 = gIn3.Load(int3(int2(pp), 0));
                float2 q2 = pp + a2.xy + float2(gJitterDX, gJitterDY);
                float w2 = 0.0;
                if (a2.w > 0.5 && q2.x >= 0.0 && q2.y >= 0.0 && q2.x < size.x && q2.y < size.y)
                {
                    float dN = DepthAt(gIn4, pp);
                    float dT = gIn5.SampleLevel(gLinearClamp, (q2 + 0.5) / size, 0).r;
                    float3 cN = gIn0.Load(int3(int2(pp), 0)).rgb;
                    float3 cT = gIn6.SampleLevel(gLinearClamp, (q2 + 0.5) / size, 0).rgb;
                    w2 = DepthWeight(dN, dT) * ColourWeight(cN, cT);
                }
                sum += w2;
            }
            wAvg = sum / 9.0;
        }

        // Fill for rejected pixels: the box-filtered residual at this position, scaled by the luma
        // ratio to the current frame and applied along the pixel's own chroma, so a moving silhouette
        // does not show a dark rim where the model's lift is missing.
        float3 rLow = gIn2.SampleLevel(gLinearClamp, FrameUv(p), 0).rgb;
        float lOrig = max(dot(orig, kLuma), 1e-4);
        float lLow = dot(rLow, kLuma);
        float3 rFill = (gLinear != 0) ? orig * (lLow / lOrig) : rLow;
        rFill *= gFillStrength;

        float3 r = lerp(rFill, rProj, wAvg);
        float3 outC = orig + r;
        outC = (isfinite(outC.x) && isfinite(outC.y) && isfinite(outC.z)) ? outC : orig;
        gOut0[id.xy] = float4(max(outC, 0.0), gIn0.Load(int3(id.xy, 0)).a);
        return;
    }
}
