// HDR10 <-> linear Rec.709 in scRGB units (1 = 80 nits).
// Separate from the existing NR shader so SDR and ordinary NR keep their compiled code.
#ifdef VULKAN
[[vk::binding(0, 0)]]
#endif
cbuffer Params : register(b0)
{
    uint mode; float exposureScale; uint width; uint height;
    float sceneIsLinear; float curveUpdateWeight; uint curveHistoryValid; float maxRatio;
    // Same layout as the shared constants: next fields in order. carrierJitter = the frame's DLSS
    // jitter in carrier pixels, carrierW/H = the carrier's size (0 or equal to the picture: no resampling).
    uint passthrough; float carrierJitterX; float carrierJitterY; uint carrierW; uint carrierH;
    // Motion guard (curveHistoryValid == 3): reference = clean seam frame (linear), refW/refH its size,
    // refExposure its white point, guardStrength 0..1.
    uint refW; float refExposure; float guardStrength; uint refH;
    // Motion vectors for the directional guard (t3 = motion, when mvValid): region mvW x mvH at base
    // mvBase (x | y << 16), scale mvScaleX/Y to input-frame UV displacement.
    uint mvW; float mvScaleX; uint mvH; uint mvValid; uint mvBase; float mvScaleY;
};
SamplerState carrierSampler : register(s0);
// Guard statistics (passthrough bit 3): u1 = one texel per 8x8 block (coverage, calibration sums, tag).
RWTexture2D<float4> regStats : register(u1);
// Block coverage (light form, motion guard active): per 8x8 group, seam-frame contrast, finished-picture
// contrast and speed. A block whose finished picture has lost most of the seam frame's structure while
// nothing moves is covered by something drawn on top (a menu panel): the edit is withheld there.
groupshared float gsSeam[64];
groupshared float gsFin[64];
groupshared float gsSpeed[64];
groupshared float gsCover;
// Coverage history (passthrough bit 3): u1 holds one texel per 8x8 block, the block's smoothed coverage.
// Read by every pixel bilinearly over the four nearest blocks, updated by thread 0 for the next frame.
float Luma709(float3 c) { return dot(c, float3(0.2126, 0.7152, 0.0722)); }
#ifdef VULKAN
[[vk::binding(1, 0)]]
#endif
Texture2D<float4> source : register(t0);
#ifdef VULKAN
[[vk::binding(2, 0)]]
#endif
Texture2D<float4> reference : register(t1);
#ifdef VULKAN
[[vk::binding(3, 0)]]
#endif
Texture2D<float4> original : register(t2);
#ifdef VULKAN
[[vk::binding(4, 0)]]
#endif
Texture2D<float4> response : register(t3);
#ifdef VULKAN
[[vk::binding(5, 0)]]
#endif
RWTexture2D<float4> target : register(u0);

float3 DecodePQ(float3 code)
{
    const float m1 = 2610.0 / 16384.0, m2 = 2523.0 / 32.0;
    const float c1 = 3424.0 / 4096.0, c2 = 2413.0 / 128.0, c3 = 2392.0 / 128.0;
    float3 p = pow(saturate(code), 1.0 / m2);
    return pow(max(p - c1, 0.0) / max(c2 - c3 * p, 1e-6), 1.0 / m1) * 125.0;
}
float3 EncodePQ(float3 light)
{
    const float m1 = 2610.0 / 16384.0, m2 = 2523.0 / 32.0;
    const float c1 = 3424.0 / 4096.0, c2 = 2413.0 / 128.0, c3 = 2392.0 / 128.0;
    float3 p = pow(saturate(light / 125.0), m1);
    return pow((c1 + c2 * p) / (1.0 + c3 * p), m2);
}

// Modes 0..5 retain their original meanings. 6/7 fit scRGB/PQ response;
// 8/9 apply it. The curve is 48 half-stop bins in exposure-normalised scene light.
// Match kDlssNrHdrCurveBins in DlssNr_Common.h.
static const uint kCurveBins = 48;
static const float kCurveMin = -12.0, kCurveStep = 0.5;
static const float3 kLuma = float3(0.2126, 0.7152, 0.0722);
static const float3x3 kTo709 = {
     1.6604910, -0.5876411, -0.0728499,
    -0.1245505,  1.1328999, -0.0083494,
    -0.0181508, -0.1005789,  1.1187297 };

float3 DisplayLight(float3 code, bool pq)
{
    return pq ? mul(kTo709, DecodePQ(code)) : code;
}

bool CurvePair(uint sampleIndex, uint2 size, bool pq, out float2 pair)
{
    uint2 cell = uint2(sampleIndex % 64, sampleIndex / 64);
    uint2 at = min(uint2((float2(cell) + 0.5) * float2(size) / float2(64, 16)), size - 1);
    float3 scene = reference.Load(int3(at, 0)).rgb;
    float3 display = DisplayLight(source.Load(int3(at, 0)).rgb, pq);
    float x = dot(scene, kLuma) / max(exposureScale, 1e-4);
    float y = dot(display, kLuma);
    pair = float2(log2(max(x, 1e-12)), log2(max(y, 1e-12)));
    return all(isfinite(scene)) && all(isfinite(display)) && x > 1e-6 && y > 1e-6;
}

float4 FitResponse(uint bin, bool pq)
{
    uint w, h;
    source.GetDimensions(w, h);
    uint rw, rh;
    reference.GetDimensions(rw, rh);
    if (w != rw || h != rh || bin >= kCurveBins) return 0.0;
    float center = kCurveMin + (bin + 0.5) * kCurveStep;
    float4 fit = 0.0;
    // A local linear fit, then robust refit to suppress inconsistent HUD/effect samples.
    // No CPU readback or histogram atomics; about 98K paired samples across all bins.
    [loop] for (uint iteration = 0; iteration < 2; ++iteration)
    {
        float total = 0.0, sx = 0.0, sy = 0.0, sxx = 0.0, sxy = 0.0, syy = 0.0;
        [loop] for (uint i = 0; i < 1024; ++i)
        {
            float2 pair;
            if (!CurvePair(i, uint2(w, h), pq, pair)) continue;
            float x = pair.x - center, y = pair.y;
            float weight = saturate(1.0 - abs(x) / 0.75);
            if (iteration != 0)
            {
                float error = (y - (fit.x + fit.y * x)) / 0.5;
                weight *= saturate(1.0 - error * error);
            }
            total += weight;
            sx += weight * x; sy += weight * y;
            sxx += weight * x * x; sxy += weight * x * y; syy += weight * y * y;
        }
        if (total < 4.0) return 0.0;
        float mx = sx / total, my = sy / total;
        float variance = max(sxx / total - mx * mx, 0.0);
        if (variance < 0.005) return 0.0; // A flat scene cannot identify a brightness response.
        float covariance = sxy / total - mx * my;
        float slope = covariance / variance;
        if (!isfinite(slope) || slope < -0.05 || slope > 2.0) return 0.0;
        slope = max(slope, 0.0);
        float errorVariance = max(syy / total - my * my - 2.0 * slope * covariance + slope * slope * variance, 0.0);
        float confidence = saturate(total / 12.0) * saturate(variance / 0.04) *
                           saturate(1.0 - errorVariance / 0.04);
        fit = float4(my - slope * mx, slope, confidence, 1.0);
    }
    if (curveHistoryValid != 0 && fit.z > 0.5)
    {
        float4 previous = original.Load(int3(bin, 0, 0));
        // Reuse only a consistent fit. Scene/exposure changes must not drag an old curve forward.
        if (all(isfinite(previous)) && previous.z > 0.5 && abs(previous.x - fit.x) < 0.25 &&
            abs(previous.y - fit.y) < 0.25)
            fit.xy = lerp(previous.xy, fit.xy, clamp(curveUpdateWeight, 0.1, 1.0));
    }
    return all(isfinite(fit)) ? fit : 0.0;
}

// x = predicted log2 display luminance, y = confidence. No extrapolation outside observed bins.
float2 LookupResponse(float sceneLog)
{
    float at = (sceneLog - kCurveMin) / kCurveStep - 0.5;
    if (!isfinite(at) || at < 0.0 || at >= kCurveBins - 1.0) return 0.0;
    uint index = uint(at);
    float4 a = response.Load(int3(index, 0, 0));
    float4 b = response.Load(int3(index + 1, 0, 0));
    if (!all(isfinite(a)) || !all(isfinite(b)) || b.x < a.x) return 0.0;
    return float2(lerp(a.x, b.x, frac(at)), min(a.z, b.z));
}

float3 MatchBrightness(float3 light, float3 scene, float3 gain)
{
    float3 fallback = light * gain;
    float baseY = dot(scene, kLuma) / max(exposureScale, 1e-4);
    float editedY = dot(scene * gain, kLuma) / max(exposureScale, 1e-4);
    float finalY = dot(light, kLuma), fallbackY = dot(fallback, kLuma);
    if (!all(isfinite(scene)) || min(min(baseY, editedY), min(finalY, fallbackY)) <= 1e-6) return fallback;
    float2 baseFit = LookupResponse(log2(baseY)), editedFit = LookupResponse(log2(editedY));
    // Per-pixel agreement also rejects many overlays/bloom regions that do not follow the global fit.
    float confidence = min(baseFit.y, editedFit.y) * saturate(1.0 - abs(log2(finalY) - baseFit.x) / 0.35);
    if (confidence <= 0.0) return fallback;
    float delta = exp2(editedFit.x) - exp2(baseFit.x);
    if (!isfinite(delta) || delta * (editedY - baseY) < 0.0) return fallback;
    float limit = clamp(maxRatio, 1.0, 8.0);
    float wantedY = clamp(finalY + delta, finalY / limit, finalY * limit);
    // Correct luminance only; retain the existing RGB transfer's chromaticity approximation.
    // A common scale preserves chromaticity while keeping every RGB gain inside the original bounds.
    float minScale = (1.0 / limit) / min(gain.r, min(gain.g, gain.b));
    float maxScale = limit / max(gain.r, max(gain.g, gain.b));
    float3 matched = fallback * clamp(wantedY / fallbackY, minScale, maxScale);
    return all(isfinite(matched)) ? lerp(fallback, matched, confidence) : fallback;
}
[numthreads(8, 8, 1)]
void CSMain(uint3 id : SV_DispatchThreadID, uint3 gid : SV_GroupID, uint gi : SV_GroupIndex)
{
    // Motion-guard measures for this pixel, filled in the first block and reused by the guard.
    float gSeamContrast = 0.0, gFinishedContrast = 0.0;
    float2 gMotionPx = 0.0;
    bool gHaveMotion = false, gMeasured = false;
    float gBlockCover = 0.0;
    // Guard statistics first: the group reduction's barriers must be reached by every thread, so this
    // block is unconditional (contributions are zero when the guard is off or out of picture) and sits
    // before any early return.
    {
        // Motion-guard measures for this pixel, computed once here (reused by the guard below).
        if (mode >= 2 && curveHistoryValid == 3 && refW != 0 && refH != 0 && id.x < width && id.y < height)
        {
            float2 px0 = 1.0 / float2(width, height);
            float2 uvA = (float2(id.xy) + 0.5) * px0;
            bool refSmallerA = refW != width || refH != height;
            float2 ruvA = uvA + (refSmallerA ? float2(carrierJitterX, carrierJitterY) / float2(refW, refH) : 0.0);
            const float2 dirsA[2] = { float2(2, 0), float2(0, 2) };
            [unroll]
            for (int d = 0; d < 2; ++d)
            {
                float2 o = dirsA[d] * px0;
                float ra = log2(max(Luma709(reference.SampleLevel(carrierSampler, ruvA + o, 0).rgb), 1e-5));
                float rb = log2(max(Luma709(reference.SampleLevel(carrierSampler, ruvA - o, 0).rgb), 1e-5));
                gSeamContrast += abs(ra - rb);
                int2 pa = clamp(int2(round(float2(id.xy) + dirsA[d])), int2(0, 0), int2(int(width) - 1, int(height) - 1));
                int2 pb = clamp(int2(round(float2(id.xy) - dirsA[d])), int2(0, 0), int2(int(width) - 1, int(height) - 1));
                float3 fa = source.Load(int3(pa, 0)).rgb, fb = source.Load(int3(pb, 0)).rgb;
                float la, lb;
                bool pqA = mode == 4 || mode == 9;
                if (mode == 2)
                { la = Luma709(pow(max(fa, 0.0), 2.2)); lb = Luma709(pow(max(fb, 0.0), 2.2)); }
                else if (pqA)
                { la = Luma709(mul(float3x3(1.6604910, -0.5876411, -0.0728499, -0.1245505, 1.1328999, -0.0083494, -0.0181508, -0.1005789, 1.1187297), DecodePQ(fa)));
                  lb = Luma709(mul(float3x3(1.6604910, -0.5876411, -0.0728499, -0.1245505, 1.1328999, -0.0083494, -0.0181508, -0.1005789, 1.1187297), DecodePQ(fb))); }
                else
                { la = Luma709(fa); lb = Luma709(fb); }
                gFinishedContrast += abs(log2(max(la, 1e-5)) - log2(max(lb, 1e-5)));
            }
            // Two directions instead of four: doubled to keep the thresholds' scale.
            gSeamContrast *= 2.0;
            gFinishedContrast *= 2.0;
            if (mvValid != 0 && mvW != 0 && mvH != 0)
            {
                uint2 mbaseA = uint2(mvBase & 0xffff, mvBase >> 16);
                uint2 mposA = min(uint2(uvA * float2(mvW, mvH)), uint2(mvW - 1, mvH - 1)) + mbaseA;
                float2 mvA = response.Load(int3(mposA, 0)).xy;
                float2 uvMotionA = mvA * float2(mvScaleX, mvScaleY) / float2(mvW, mvH);
                gMotionPx = all(isfinite(uvMotionA)) ? uvMotionA * float2(width, height) : 0.0;
                gHaveMotion = true;
            }
            gMeasured = true;
        }
        gsSeam[gi] = gMeasured ? gSeamContrast : 0.0;
        gsFin[gi] = gMeasured ? gFinishedContrast : 0.0;
        gsSpeed[gi] = gMeasured ? length(gMotionPx) : 0.0;

        GroupMemoryBarrierWithGroupSync();
        [unroll]
        for (uint s = 32; s > 0; s >>= 1)
        {
            if (gi < s)
            {
                gsSeam[gi] += gsSeam[gi + s]; gsFin[gi] += gsFin[gi + s]; gsSpeed[gi] += gsSpeed[gi + s];
            }
            GroupMemoryBarrierWithGroupSync();
        }
        // Block coverage, soft and smoothed: the seam frame has structure in this block and the finished
        // picture has lost much of it while the block is at rest (something drawn on top). 0 = open,
        // 1 = covered, with a wide transition so no block ever snaps; smoothed over frames through the
        // coverage history when it is bound, so a decision cannot flicker.
        float coverNow = 0.0;
        if (gMeasured && gsSeam[0] > 64.0 * 0.12 && (gsSpeed[0] / 64.0) < 0.75)
        {
            float ratioBlock = gsFin[0] / max(gsSeam[0], 1e-4);
            coverNow = saturate((0.6 - ratioBlock) / 0.3);
        }
        if (gi == 0)
        {
            float coverUsed = coverNow;
            if ((passthrough & 8) != 0)
            {
                float4 cell = (passthrough & 16) != 0 ? float4(0.0, 0.0, 0.0, 0.0) : regStats[gid.xy];
                float prev = (cell.w > 1.5 && isfinite(cell.x)) ? saturate(cell.x) : 0.0;
                coverUsed = lerp(prev, coverNow, 0.2);
                regStats[gid.xy] = float4(coverUsed, 0.0, 0.0, 2.0);
            }
            gsCover = coverUsed;
        }
        GroupMemoryBarrierWithGroupSync();
        // Per pixel: bilinear over the four nearest blocks' smoothed coverage, so block edges are soft.
        if ((passthrough & 8) != 0 && (passthrough & 16) == 0 && gMeasured)
        {
            float2 bpos = (float2(id.xy) + 0.5) / 8.0 - 0.5;
            int2 b0 = int2(floor(bpos));
            float2 f = bpos - float2(b0);
            uint2 nb = uint2((width + 7) / 8, (height + 7) / 8);
            float c00 = regStats[uint2(clamp(b0, int2(0, 0), int2(nb) - 1))].x;
            float c10 = regStats[uint2(clamp(b0 + int2(1, 0), int2(0, 0), int2(nb) - 1))].x;
            float c01 = regStats[uint2(clamp(b0 + int2(0, 1), int2(0, 0), int2(nb) - 1))].x;
            float c11 = regStats[uint2(clamp(b0 + int2(1, 1), int2(0, 0), int2(nb) - 1))].x;
            gBlockCover = lerp(lerp(c00, c10, f.x), lerp(c01, c11, f.x), f.y);
            gBlockCover = isfinite(gBlockCover) ? saturate(gBlockCover) : gsCover;
        }
        else
            gBlockCover = gsCover;
    }
    if (id.x >= width || id.y >= height) return;
    if (mode == 10)
    {
        // Half-resolution luminance of a linear frame (the motion guard's reference): a 2x2 average.
        int2 p = int2(id.xy) * 2;
        float3 sum = source.Load(int3(p, 0)).rgb + source.Load(int3(p + int2(1, 0), 0)).rgb +
                     source.Load(int3(p + int2(0, 1), 0)).rgb + source.Load(int3(p + int2(1, 1), 0)).rgb;
        float l = Luma709(sum * 0.25);
        target[id.xy] = float4(isfinite(l) ? max(l, 0.0) : 0.0, 0.0, 0.0, 1.0);
        return;
    }
    if (mode == 6 || mode == 7)
    {
        target[id.xy] = FitResponse(id.x, mode == 7);
        return;
    }
    float4 pixel = source.Load(int3(id.xy, 0));
    const float3x3 to709 = {
         1.6604910, -0.5876411, -0.0728499,
        -0.1245505,  1.1328999, -0.0083494,
        -0.0181508, -0.1005789,  1.1187297 };
    const float3x3 to2020 = {
        0.6274039, 0.3292830, 0.0433131,
        0.0690973, 0.9195404, 0.0113623,
        0.0163914, 0.0880133, 0.8955953 };
    if (mode == 5)
    {
        // Carry a bounded relative change through DLSS. An absolute signed residual
        // around 0.5 loses small dark-scene edits when stored in FP16; dividing that
        // quantization error by the dark SR reference produces large colour noise.
        float3 base = max(pixel.rgb, 0.0);
        float3 edited = max(reference.Load(int3(id.xy, 0)).rgb, 0.0);
        if (!all(isfinite(base)) || !all(isfinite(edited)))
        { target[id.xy] = float4(0.5, 0.5, 0.5, 1.0); return; }
        if (sceneIsLinear < 0.5)
        { base = pow(base, 2.2); edited = pow(edited, 2.2); }
        float floorValue = max(max(base.r, max(base.g, base.b)) * 0.02,
                               max(exposureScale, 1e-4) * 1e-4);
        float limit = clamp(maxRatio, 1.0, 8.0);
        float3 gain = clamp(1.0 + (edited - base) / max(base, floorValue), 1.0 / limit, limit);
        target[id.xy] = float4(0.5 + log2(gain) / 8.0, 1.0);
        return;
    }
    if (mode >= 2)
    {
        // t0 = finished picture, t2 = log-gain carrier upscaled by private DLSS.
        // Apply bounded relative changes in linear light. This approximates the game's
        // unknown tonemapper and colour grading; no scene-linear delta is added to display code.
        float3 carrier = original.Load(int3(id.xy, 0)).rgb;
        if (!all(isfinite(carrier)) || all(carrier == 0.5))
        { target[id.xy] = pixel; return; }
        float limit = clamp(maxRatio, 1.0, 8.0);
        float3 gain = exp2(clamp((carrier - 0.5) * 8.0, -log2(limit), log2(limit)));
        bool pq = mode == 4 || mode == 9;
        float3 light = mode == 2 ? pow(max(pixel.rgb, 0.0), 2.2) :
                       pq ? mul(to709, DecodePQ(pixel.rgb)) : pixel.rgb;
        light = (mode == 8 || mode == 9) ? MatchBrightness(light, reference.Load(int3(id.xy, 0)).rgb, gain)
                                        : light * gain;
        float3 result = mode == 2 ? pow(saturate(light), 1.0 / 2.2) :
                        pq ? EncodePQ(mul(to2020, light)) : light;
        // Motion guard (curveHistoryValid == 3): the edit was computed on the seam frame (t1, linear,
        // sharp). Where the finished picture is blurrier than that frame (motion blur, depth of field,
        // distortion), a sharp edit would draw a second line inside the blur. Two measures, so the
        // picture in motion keeps NR's brightness and tone but never a sharp structure the finished
        // picture no longer has: (1) the edit itself is blurred to the finished picture's blur (a box
        // over the carrier, radius growing with the blur), (2) what remains is withheld in proportion.
        // Local log-luminance contrast over +-1 output pixel, on both pictures at the same spatial
        // scale; tone curves cancel to first order in the ratio.
        if (curveHistoryValid == 3 && refW != 0 && refH != 0 && gMeasured)
        {
            float2 px = 1.0 / float2(width, height);
            float2 uv0 = (float2(id.xy) + 0.5) * px;
            float seamContrast = gSeamContrast, finishedContrast = gFinishedContrast;
            // Flat in the seam frame: nothing to blur, keep the edit. Otherwise the finished picture's
            // contrast relative to the seam frame's is the blur measure; grain and texture only add
            // contrast and never trip it. Acts only below 85% of the seam frame's contrast.
            float ratio = seamContrast < 0.1 ? 1.0 : saturate((finishedContrast + 0.02) / (seamContrast + 0.02));
            float blurred = saturate((0.85 - ratio) / 0.6);      // 0 sharp .. 1 fully blurred
            // Flat in the seam frame (sky, walls, and anything drawn on top later such as a menu panel):
            // there is no detail for the edit to carry, so it is applied from a 3x3 local average of the
            // carrier. Per-pixel noise in the edit cannot survive that; detail elsewhere is untouched.
            if (seamContrast < 0.1)
            {
                float2 cpxF = (carrierW != 0 && carrierH != 0) ? 1.0 / float2(carrierW, carrierH) : px;
                float2 cuvF = uv0 + ((carrierW != 0 && carrierH != 0 && (carrierW != width || carrierH != height))
                                     ? float2(carrierJitterX, carrierJitterY) / float2(carrierW, carrierH) : 0.0);
                float3 accF = 0.0;
                [unroll]
                for (int fy = -1; fy <= 1; ++fy)
                    [unroll]
                    for (int fx = -1; fx <= 1; ++fx)
                        accF += original.SampleLevel(carrierSampler, cuvF + float2(fx, fy) * cpxF, 0).rgb;
                float3 gainF = exp2(clamp((accF / 9.0 - 0.5) * 8.0, -log2(limit), log2(limit)));
                float3 lightF = (mode == 2 ? pow(max(pixel.rgb, 0.0), 2.2) : pq ? mul(to709, DecodePQ(pixel.rgb)) : pixel.rgb) * gainF;
                result = mode == 2 ? pow(saturate(lightF), 1.0 / 2.2) : pq ? EncodePQ(mul(to2020, lightF)) : lightF;
            }
            float2 motionPx = gMotionPx;
            bool haveMotion = gHaveMotion;
            float speed = length(motionPx);
            // Covered (menu panel over the scene at rest): the original pixel, in proportion.
            if (gBlockCover > 0.999)
            {
                target[id.xy] = pixel;
                return;
            }
            // At rest there is no motion blur to match: keep the edit whole, skip the rest.
            if (haveMotion && speed < 0.75)
                blurred = 0.0;
            if (blurred > 0.05)
            {
                float2 cpx = (carrierW != 0 && carrierH != 0) ? 1.0 / float2(carrierW, carrierH) : px;
                float2 cuv = uv0 + ((carrierW != 0 && carrierH != 0 && (carrierW != width || carrierH != height))
                                    ? float2(carrierJitterX, carrierJitterY) / float2(carrierW, carrierH) : 0.0);
                float3 carrierBlur;
                if (haveMotion)
                {
                    // Directional: the edit is streaked along the motion, like the game's blur, and stays
                    // crisp across it. A moving power line keeps its shape (a thin streak), only its NR
                    // edit is spread along the streak instead of drawn as a second sharp line inside it.
                    float2 dir = motionPx / max(speed, 1e-3);
                    float len = min(speed * 0.5, 16.0) * saturate(blurred * 2.0);  // in output pixels
                    float2 step = dir * len / 3.0 * px;
                    float3 acc = 0.0;
                    [unroll]
                    for (int t = -3; t <= 3; ++t)
                        acc += original.SampleLevel(carrierSampler, cuv + step * float(t), 0).rgb;
                    carrierBlur = acc / 7.0;
                }
                else
                {
                    // No motion vectors: isotropic, radius up to 4 output pixels.
                    float r = lerp(1.0, 4.0, saturate(blurred)) * ((carrierW != 0 && carrierW != width) ? float(carrierW) / float(width) : 1.0);
                    float3 acc = 0.0;
                    [unroll]
                    for (int oy = -1; oy <= 1; ++oy)
                        [unroll]
                        for (int ox = -1; ox <= 1; ++ox)
                            acc += original.SampleLevel(carrierSampler, cuv + float2(ox, oy) * cpx * r, 0).rgb;
                    carrierBlur = acc / 9.0;
                }
                float3 gainBlur = exp2(clamp((carrierBlur - 0.5) * 8.0, -log2(limit), log2(limit)));
                float3 lightBlur = (mode == 8 || mode == 9) ? light : (mode == 2 ? pow(max(pixel.rgb, 0.0), 2.2) :
                                    pq ? mul(to709, DecodePQ(pixel.rgb)) : pixel.rgb) * gainBlur;
                float3 resultBlur = mode == 2 ? pow(saturate(lightBlur), 1.0 / 2.2) :
                                    pq ? EncodePQ(mul(to2020, lightBlur)) : lightBlur;
                // Blurred picture: streaked edit; the sharp edit fades out with the blur.
                result = lerp(resultBlur, result, 1.0 - saturate(guardStrength) * saturate(blurred * 2.0));
                // With the edit streaked along the motion it stays consistent with the picture, so only a
                // little is withheld; without motion data the old proportional hold applies.
                float keep = haveMotion ? 1.0 - 0.3 * saturate(guardStrength) * blurred
                                        : 1.0 - saturate(guardStrength) * blurred;
                keep *= keep;
                result = lerp(pixel.rgb, result, keep);
            }
            result = lerp(result, pixel.rgb, gBlockCover);
        }
        target[id.xy] = float4(all(isfinite(result)) ? result : pixel.rgb, pixel.a);
        return;
    }
    if (mode == 0)
    {
        // Negative components carry wide-gamut colours; retain them in FP16.
        target[id.xy] = float4(mul(to709, DecodePQ(pixel.rgb)), pixel.a);
    }
    else
    {
        float4 base = original.Load(int3(id.xy, 0));
        float3 result = EncodePQ(mul(to2020, pixel.rgb));
        target[id.xy] = float4(all(isfinite(result)) ? result : base.rgb, base.a);
    }
}
