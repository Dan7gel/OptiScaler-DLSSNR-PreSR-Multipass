#include "pch.h"
#include "DlssNr_Dx12_State.h"
#include <menu/menu_overlay_base.h>

namespace
{
// The game's own menus (pause, PDA, inventory) show the system cursor; gameplay hides it. While the game
// shows it and our overlay is not the one asking for it, the finished compose is skipped: the frame goes
// out as the game drew it, so panels are never edited (no transparency change, no noise on them).
// "Press any key" screens after loading: frame generation is on and no cursor shows, but the player
// has not touched anything yet. After every switch-on of frame generation the finished picture waits
// for the first input (any key or mouse movement, from the session's last-input time) before resuming.
bool AwaitingFirstInput()
{
    static bool wasOn = false;
    static bool awaiting = false;
    static DWORD onSince = 0;
    const bool on = ::State::Instance().dlssgGameRequestedOn;
    if (on && !wasOn)
    {
        onSince = GetTickCount();
        awaiting = true;
    }
    wasOn = on;
    if (!on)
        return false;
    if (awaiting)
    {
        LASTINPUTINFO lii {};
        lii.cbSize = sizeof(lii);
        if (GetLastInputInfo(&lii) && (DWORD) (lii.dwTime - onSince) < 0x7FFFFFFFu && lii.dwTime != onSince &&
            (DWORD) (lii.dwTime - onSince) > 0)
            awaiting = false;
    }
    return awaiting;
}

bool GameMenuOpen()
{
    if (MenuOverlayBase::IsVisible())
        return false;
    CURSORINFO ci {};
    ci.cbSize = sizeof(ci);
    if (!GetCursorInfo(&ci))
        return false;
    return (ci.flags & CURSOR_SHOWING) != 0;
}
} // namespace

auto DlssNr_Dx12::State::ApplyFinishedColor(ID3D12Resource* color, ID3D12CommandQueue* queue, DXGI_COLOR_SPACE_TYPE colorSpace,
                                          bool gameFrameHandoff, ID3D12Resource* ui, D3D12_RESOURCE_STATES uiState,
                                          ID3D12Resource* hudless, D3D12_RESOURCE_STATES hudlessState) -> bool
{
    if (!Config::Instance()->DlssNrFinishedPicture.value_or_default() ||
        !Config::Instance()->DlssNrEnabled.value_or_default())
    {
        late.Cancel();
        return false;
    }
    LateContext::ComPtr<ID3D12Device> currentDevice;
    if (FAILED(queue->GetDevice(IID_PPV_ARGS(&currentDevice))) || currentDevice != late.device)
        return false;
    ID3D12CommandQueue* realQueue = nullptr;
    if (!Util::CheckForRealObject(__FUNCTION__, queue, (IUnknown**) &realQueue))
        realQueue = queue;
    const auto desc = color->GetDesc();
    const bool pq = colorSpace == DXGI_COLOR_SPACE_RGB_FULL_G2084_NONE_P2020;
    const bool scrgb = colorSpace == DXGI_COLOR_SPACE_RGB_FULL_G10_NONE_P709;
    const bool sdr = colorSpace == DXGI_COLOR_SPACE_RGB_FULL_G22_NONE_P709;
    if ((!sdr && !pq && !scrgb) || (scrgb && desc.Format != DXGI_FORMAT_R16G16B16A16_FLOAT) ||
        (!scrgb && desc.Format != DXGI_FORMAT_R8G8B8A8_UNORM && desc.Format != DXGI_FORMAT_R10G10B10A2_UNORM))
    {
        late.Cancel();
        late.Say("This screen colour format is not supported.");
        return false;
    }
    LateContext::Slot* latest = nullptr;
    const auto epoch = ::State::Instance().frameCount;
    const auto& cfg = *Config::Instance();
    const bool residualOnly = DlssNr::ResolvePlacement(
        cfg.DlssNrRunBeforeSr.value_or_default(), cfg.DlssNrDeferredDlss.value_or_default(),
        cfg.DlssNrResidualAcrossRr.value_or_default(), true).deferred;
    late.Tick();
    unsigned sawNotSubmitted = 0, sawNotReady = 0, sawStale = 0;
    for (auto& slot : late.slots)
    {
        if (!slot.pending)
            continue;
        if (!slot.submitted)
        {
            sawNotSubmitted++;
            continue;
        }
        // Native FG's internal Present counter includes generated frames and is not an app-frame identity.
        if (!gameFrameHandoff && (epoch < slot.frame.SubmissionEpoch || epoch - slot.frame.SubmissionEpoch > 1))
        {
            slot.pending = false;
            late.reset = true;
            sawStale++;
            continue;
        }
        if (!DlssNr::FinishedInputReady(slot.producerQueue.Get() == realQueue,
                                        slot.fence->GetCompletedValue(), slot.ready))
        {
            if (!late.reportedQueueDelay)
            {
                LOG_INFO("DLSS-NR finished picture: skipping unfinished cross-queue input to avoid a present/render fence cycle");
                late.reportedQueueDelay = true;
            }
            sawNotReady++;
            continue;
        }
        // The slot's own route decides its form: an RR feature on the dedicated route is captured as
        // ordinary finished NR even while the shared keys describe the separate-edit form for SR.
        const bool slotResidualOnly =
            DlssNr::RrFinishedLight(cfg, slot.frame.RayReconstruction)
                ? true
                : DlssNr::ResolvePlacementFor(cfg, slot.frame.RayReconstruction).deferred;
        if (slot.residualOnly == slotResidualOnly && slot.frame.OutputWidth == desc.Width &&
            slot.frame.OutputHeight == desc.Height && (!latest || slot.serial > latest->serial))
            latest = &slot;
    }
    // A tuning change may need a few model warm-up frames. Keep displaying the last
    // held edit in that gap rather than exposing live/rotating game backbuffers.
    if (!latest && residualOnly && Config::Instance()->DlssNrHoldFrame.value_or_default() && inputHold.active &&
        late.heldValid && late.heldGeneration == inputHold.generation && late.heldSlot &&
        late.heldSlot->serial == late.heldSlotSerial && !late.heldSlot->pending &&
        late.heldSlot->frame.OutputWidth == desc.Width && late.heldSlot->frame.OutputHeight == desc.Height)
    {
        auto& held = *late.heldSlot;
        if (late.Finished(held))
            latest = &held;
    }
    // Game menu, loading screen, shader compilation: the frame passes through untouched. Two signals: the
    // game shows its cursor, or (native DLSS-G) the game has switched frame generation off. The slot is
    // consumed so its fence bookkeeping stays in step; nothing is recorded or submitted.
    if (latest && latest->residualOnly)
    {
        // Frame generation off, or not yet ever on (the game's start-up loading, before it reaches gameplay
        // and asks for frame generation the first time): the finished picture waits.
        const bool fgGate = Config::Instance()->DlssNrFinishedOnlyWithFrameGen.value_or_default();
        const bool fgOff = fgGate && (!::State::Instance().dlssgGameEverOn || !::State::Instance().dlssgGameRequestedOn);
        const bool waitInput = fgGate && !fgOff && AwaitingFirstInput();
        if (fgOff || waitInput || GameMenuOpen())
        {
            latest->pending = false;
            late.Say(fgOff ? "paused: the game has frame generation off (menu, loading, shader compilation)"
                     : waitInput ? "paused: waiting for the first input after loading (press-any-key screen)"
                                 : "paused: the game's menu is open (cursor shown); the finished picture is left as drawn");
            return false;
        }
    }
    // No fresh edit for this present (loading screen, a menu without the cursor, a paused world): the
    // frame is left exactly as the game drew it. A previous frame's edit is never re-applied.
    if (!latest)
    {
        late.tally.noSlot++;
        late.tally.notSubmitted += sawNotSubmitted;
        late.tally.notReady += sawNotReady;
        late.tally.stale += sawStale;
        return false; // loading screen, another swapchain, or this real frame was already consumed
    }
    auto& slot = *latest;
    const bool holdFinished = slot.residualOnly && Config::Instance()->DlssNrHoldFrame.value_or_default() &&
                              inputHold.active;
    if (!holdFinished)
        late.heldValid = false;
    if (holdFinished)
    {
        if (late.heldFailed)
            return false;
        if (late.heldFinished && !SameHoldShape(late.heldFinished->GetDesc(), desc))
        {
            // Defer replacement rather than blocking a presentation needed by the old work.
            if (late.heldFence && !DlssNr::FinishedInputReady(false, late.heldFence->GetCompletedValue(), late.heldReady))
                return false;
            late.heldFinished.Reset();
            late.heldValid = false;
        }
        if (!late.heldFinished)
        {
            late.heldFinished.Attach(CreateScratch(late.device.Get(), desc.Format, (unsigned) desc.Width, desc.Height));
            late.heldState = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
        }
        if (late.heldFence && !DlssNr::FinishedInputReady(late.heldQueue.Get() == realQueue,
                                                        late.heldFence->GetCompletedValue(), late.heldReady))
            return false;
        if (!late.heldFinished)
        {
            late.Say("Could not hold the finished frame.");
            return false;
        }
    }
    // Drop other submitted evaluates from this picture, not their in-flight resources.
    for (auto& other : late.slots)
        if (other.submitted && other.serial <= slot.serial)
            other.pending = false;
    // Input is complete or ordered earlier on this queue. Never insert a wait on future render work here.
    if (FAILED(slot.allocator->Reset()) ||
        FAILED(slot.commands->Reset(slot.allocator.Get(), nullptr)))
    {
        late.reset = true;
        late.Say("Could not prepare the finished picture.");
        return false;
    }
    auto* cmd = slot.commands.Get();
    if (holdFinished)
    {
        const bool capture = !late.heldValid || late.heldGeneration != inputHold.generation ||
                             late.heldSpace != colorSpace;
        if (capture)
        {
            Barrier(cmd, color, D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_COPY_SOURCE);
            Barrier(cmd, late.heldFinished.Get(), late.heldState, D3D12_RESOURCE_STATE_COPY_DEST);
            cmd->CopyResource(late.heldFinished.Get(), color);
            Barrier(cmd, late.heldFinished.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COPY_SOURCE);
            Barrier(cmd, color, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_PRESENT);
            late.heldState = D3D12_RESOURCE_STATE_COPY_SOURCE;
            late.heldGeneration = inputHold.generation;
            late.heldSpace = colorSpace;
            late.heldValid = true;
        }
        else
        {
            Barrier(cmd, color, D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_COPY_DEST);
            cmd->CopyResource(color, late.heldFinished.Get());
            Barrier(cmd, color, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_PRESENT);
        }
    }
    const auto before = nr.successfulDispatches;
    bool appliedResidual = false;
    bool matchedResponse = false;
    if (slot.residualOnly)
    {
        if (slot.encoded &&
            (slot.encoded->GetDesc().Width != desc.Width || slot.encoded->GetDesc().Height != desc.Height ||
             slot.encoded->GetDesc().Format != desc.Format))
            slot.encoded.Reset();
        if (!slot.encoded)
            slot.encoded.Attach(CreateScratch(late.device.Get(), desc.Format, (unsigned) desc.Width, desc.Height));
        if (slot.encoded && Config::Instance()->DlssNrApplyModel.value_or_default())
        {
            Barrier(cmd, slot.residual.Get(), slot.residualState, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            Barrier(cmd, color, D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            DlssNrConstants apply {};
            apply.Mode = pq ? 4 : scrgb ? 3 : 2;
            apply.Width = (unsigned) desc.Width;
            apply.Height = desc.Height;
            apply.WhitePoint = slot.frame.PreExposure;
            apply.TransferStrength = slot.sceneLinear ? 1.0f : 0.0f;
            // Edit strength for the finished picture (log-gain multiplier) rides in SkinDetail.
            apply.SkinDetail = std::clamp(Config::Instance()->DlssNrFinishedEditGain.value_or_default(), 0.25f, 3.0f);
            apply.MaxRatio = std::clamp(Config::Instance()->DlssNrMaxRatio.value_or_default(), 1.0f, 8.0f);
            const bool measure = Config::Instance()->DlssNrHdrTransfer.value_or_default() && slot.cleanSceneValid &&
                                 slot.sceneLinear && (pq || scrgb) && slot.cleanScene &&
                                 slot.cleanScene->GetDesc().Width == desc.Width &&
                                 slot.cleanScene->GetDesc().Height == desc.Height;
            {
                const auto rd = slot.residual->GetDesc();
                apply.GuideWidth = (unsigned) rd.Width;
                apply.GuideHeight = rd.Height;
                apply.MvScaleX = 0.0f;
                apply.MvScaleY = 0.0f;
            }
            if (measure)
            {
                Barrier(cmd, slot.cleanScene.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                for (auto& curve : slot.response)
                {
                    if (!curve)
                    {
                        curve.Attach(CreateScratch(late.device.Get(), DXGI_FORMAT_R32G32B32A32_FLOAT,
                                                   kDlssNrHdrCurveBins, 1));
                        if (curve)
                            Barrier(cmd, curve.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                        slot.responseValid = false;
                    }
                }
                if (slot.response[0] && slot.response[1])
                {
                    const unsigned next = slot.responseIndex ^ 1u;
                    DlssNrConstants fit {};
                    fit.Mode = pq ? 7 : 6;
                    fit.Width = kDlssNrHdrCurveBins;
                    fit.Height = 1;
                    fit.WhitePoint = slot.frame.PreExposure;
                    fit.ColourStrength = 0.35f; // new weight, only for fits that agree with their history
                    fit.DebugView = slot.responseValid && !slot.frame.Reset && !late.reset &&
                                    slot.responseWidth == desc.Width && slot.responseHeight == desc.Height &&
                                    slot.responseSpace == colorSpace && epoch >= slot.responseEpoch &&
                                    epoch - slot.responseEpoch <= 8 &&
                                    slot.frame.PreExposure >= slot.responseExposure * 0.8f &&
                                    slot.frame.PreExposure <= slot.responseExposure * 1.25f;
                    Barrier(cmd, slot.response[next].Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                            D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
                    matchedResponse = shader.DispatchResidualPass(cmd, fit, color, slot.cleanScene.Get(),
                                                                  slot.response[slot.responseIndex].Get(), nullptr,
                                                                  slot.response[next].Get(), true);
                    Barrier(cmd, slot.response[next].Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                            D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                    slot.responseValid = matchedResponse;
                    if (matchedResponse)
                    {
                        slot.responseIndex = next;
                        slot.responseWidth = (unsigned) desc.Width;
                        slot.responseHeight = desc.Height;
                        slot.responseSpace = colorSpace;
                        slot.responseExposure = slot.frame.PreExposure;
                        slot.responseEpoch = epoch;
                        apply.Mode = pq ? 9 : 8;
                    }
                }
            }
            else
                slot.responseValid = false;
            // Guard flag rides in the curveHistoryValid slot of the finished-colour constants: 3 = motion guard
            // (reference = the clean seam frame); the response fit modes keep their own reference.
            const float motionGuard = std::clamp(Config::Instance()->DlssNrFinishedMotionGuard.value_or_default(), 0.0f, 1.0f);
            // In the response-fit modes t1 is the full clean frame (also the guard's reference) and t3 the
            // response curve, so the motion vectors ride in t4 (passthrough bit 1). Otherwise the guard's
            // reference is the half-resolution luminance in t1 and the motion vectors ride in t3.
            const bool cleanGuard = motionGuard > 0.0f &&
                                    (matchedResponse ? true : (slot.guideLumaValid && slot.guideLuma != nullptr));
            apply.DebugView = cleanGuard ? 3u : 0u;
            const bool guardMotion = cleanGuard && slot.residualMotion && slot.motion;
            if (cleanGuard)
            {
                const auto cd = matchedResponse ? slot.cleanScene->GetDesc() : slot.guideLuma->GetDesc();
                apply.CompareMode = (unsigned) cd.Width;
                apply.CompareSwap = cd.Height;
                apply.CompareZoom = motionGuard;
                apply.CompareSplit = slot.frame.PreExposure;
                if (!matchedResponse)
                    Barrier(cmd, slot.guideLuma.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                            D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                if (matchedResponse && guardMotion)
                    apply.Passthrough |= 2u; // bit 1: motion vectors in t4
                if (Config::Instance()->DlssNrFinishedGuardSteady.value_or_default() != 0)
                    apply.Passthrough |= 4u; // bit 2: steady (3x3 median of the measured blur length)
                if (guardMotion)
                {
                    // Motion vectors ride in t3 (free outside the response-fit modes): region, base and
                    // scale in the next constants after the guard's.
                    apply.Transfer = slot.frame.GuideWidth;
                    apply.ReversibleMode = slot.frame.GuideHeight;
                    apply.DebugScale = slot.frame.MvScaleX;
                    apply.ExposurePreMul = slot.frame.MvScaleY;
                    apply.ApplyModel = 1u;
                    apply.UseGameExposure = slot.frame.MotionSubrectBaseX | (slot.frame.MotionSubrectBaseY << 16);
                    Barrier(cmd, slot.motion.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
                            D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                }
            }
            ID3D12Resource* extraUav = nullptr;
            // HUD mask: the game's UI colour+alpha buffer in t4 (bit 3), when t4 is not carrying the motion
            // vectors of the response-fit modes. Where its alpha says UI, the original pixel is kept.
            ID3D12Resource* uiMask = nullptr;
            D3D12_RESOURCE_STATES uiMaskState = D3D12_RESOURCE_STATE_COMMON;
            if (Config::Instance()->DlssNrFinishedUiMask.value_or_default() && !(matchedResponse && guardMotion))
            {
                // Preferred: the UI alpha layer (bit 3). Fallback: the HUD-less frame (bit 4), where UI is
                // wherever the finished frame differs from it.
                if (ui != nullptr)
                {
                    const auto ud = ui->GetDesc();
                    if (ud.Width == desc.Width && ud.Height == desc.Height && ud.Dimension == desc.Dimension)
                    {
                        uiMask = ui;
                        uiMaskState = uiState;
                        apply.Passthrough |= 8u;
                    }
                }
                if (uiMask == nullptr && hudless != nullptr)
                {
                    const auto hd = hudless->GetDesc();
                    if (hd.Width == desc.Width && hd.Height == desc.Height && hd.Dimension == desc.Dimension &&
                        hd.Format == desc.Format)
                    {
                        uiMask = hudless;
                        uiMaskState = hudlessState;
                        apply.Passthrough |= 16u;
                    }
                }
                if (uiMask != nullptr && uiMaskState != D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE)
                    Barrier(cmd, uiMask, uiMaskState, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            }
            appliedResidual = shader.DispatchResidualPass(
                cmd, apply, color, matchedResponse ? slot.cleanScene.Get() : cleanGuard ? slot.guideLuma.Get() : nullptr,
                slot.residual.Get(),
                matchedResponse ? slot.response[slot.responseIndex].Get() : guardMotion ? slot.motion.Get() : nullptr,
                slot.encoded.Get(), true, extraUav,
                (matchedResponse && guardMotion) ? slot.motion.Get() : uiMask);
            if (uiMask != nullptr && uiMaskState != D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE)
                Barrier(cmd, uiMask, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, uiMaskState);
            if (guardMotion)
                Barrier(cmd, slot.motion.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                        D3D12_RESOURCE_STATE_COPY_DEST);
            if (cleanGuard && !matchedResponse)
                Barrier(cmd, slot.guideLuma.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                        D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            if (appliedResidual)
            {
                late.tally.composes++;
                late.lastLight = &slot;
                late.lastLightSerial = slot.serial;
            }
            {
                char msg[256];
                const auto& t = late.lastTally;
                snprintf(msg, sizeof(msg),
                         "running: edit applied to the finished picture at presentation | per s: captures %u, composes %u",
                         t.captures, t.composes);
                lightTally = msg;
                if (slot.residualOnly)
                    late.Say(msg);
            }
            if (measure)
                Barrier(cmd, slot.cleanScene.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                        D3D12_RESOURCE_STATE_COPY_DEST);
            if (!appliedResidual)
                slot.responseValid = false;
            if (appliedResidual)
            {
                Barrier(cmd, slot.encoded.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_COPY_SOURCE);
                Barrier(cmd, color, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
                cmd->CopyResource(color, slot.encoded.Get());
                Barrier(cmd, color, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                Barrier(cmd, slot.encoded.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
                        D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            }
            Barrier(cmd, color, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_PRESENT);
            Barrier(cmd, slot.residual.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, slot.residualState);
        }
    }
    else
    {
        auto frame = slot.frame;
        frame.ColourIsLinearHdr = pq || scrgb;
        // Absolute display encodings: 203-nit reference white, in 80-nit scRGB units.
        frame.WhitePointOverride = (pq || scrgb) ? 203.0f / 80.0f : 0.0f;
        frame.Reset |= late.reset;
        frame.SubmissionEpoch = epoch;
        Barrier(cmd, slot.depth.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
                D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        Barrier(cmd, slot.motion.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
                D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        ID3D12Resource* nrColor = color;
        bool colorReady = true;
        DlssNrConstants conversion {};
        conversion.Width = (unsigned) desc.Width;
        conversion.Height = desc.Height;
        if (pq)
        {
            auto ensure = [&](LateContext::ComPtr<ID3D12Resource>& resource, DXGI_FORMAT format)
            {
                if (resource && (resource->GetDesc().Width != desc.Width ||
                                 resource->GetDesc().Height != desc.Height || resource->GetDesc().Format != format))
                    resource.Reset();
                if (!resource)
                    resource.Attach(CreateScratch(late.device.Get(), format, (unsigned) desc.Width, desc.Height));
                return resource != nullptr;
            };
            colorReady = ensure(slot.linear, DXGI_FORMAT_R16G16B16A16_FLOAT) && ensure(slot.encoded, desc.Format);
            if (colorReady)
            {
                Barrier(cmd, color, D3D12_RESOURCE_STATE_PRESENT,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                colorReady = shader.DispatchResidualPass(cmd, conversion, color, nullptr, nullptr, nullptr,
                                                         slot.linear.Get(), true);
                Barrier(cmd, color, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                        D3D12_RESOURCE_STATE_PRESENT);
                // Dispatch reads the converted colour; its transition out of UAV orders the conversion.
                nrColor = slot.linear.Get();
                frame.OutputArrivalState = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
            }
        }
        if (colorReady)
            Run(cmd, nrColor, slot.depth.Get(), slot.motion.Get(), nrColor, frame, queue);
        if (pq && colorReady && nr.successfulDispatches > before &&
            Config::Instance()->DlssNrApplyModel.value_or_default())
        {
            conversion.Mode = 1;
            Barrier(cmd, slot.linear.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            Barrier(cmd, color, D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            if (shader.DispatchResidualPass(cmd, conversion, slot.linear.Get(), nullptr, color, nullptr,
                                            slot.encoded.Get(), true))
            {
                Barrier(cmd, slot.encoded.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_COPY_SOURCE);
                Barrier(cmd, color, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                        D3D12_RESOURCE_STATE_COPY_DEST);
                cmd->CopyResource(color, slot.encoded.Get());
                Barrier(cmd, color, D3D12_RESOURCE_STATE_COPY_DEST,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                Barrier(cmd, slot.encoded.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
                        D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            }
            Barrier(cmd, color, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_PRESENT);
            Barrier(cmd, slot.linear.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        }
        Barrier(cmd, slot.motion.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                D3D12_RESOURCE_STATE_COPY_DEST);
        Barrier(cmd, slot.depth.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                D3D12_RESOURCE_STATE_COPY_DEST);
    }
    if (FAILED(cmd->Close()))
    {
        late.heldFailed |= holdFinished;
        late.Say("Could not finish the picture. Restart the game to retry.");
        slot.pending = true; // quarantine the slot; do not reuse possibly recorded NR resources
        slot.submitted = false;
        return false;
    }
    ID3D12CommandList* lists[] = { cmd };
    queue->ExecuteCommandLists(1, lists);
    slot.done = std::max(slot.done, slot.ready) + 1; // held replays also need a fresh completion value
    if (FAILED(queue->Signal(slot.fence.Get(), slot.done)))
    {
        late.heldFailed |= holdFinished;
        late.Say("The graphics queue stopped. Restart the game to retry.");
        return false;
    }
    if (holdFinished)
    {
        late.heldFence = slot.fence;
        late.heldQueue = realQueue;
        late.heldReady = slot.done;
        late.heldSlot = &slot;
        late.heldSlotSerial = slot.serial;
    }
    const bool ran = slot.residualOnly ? appliedResidual : nr.successfulDispatches > before;
    late.reset = !ran;
    if (slot.residualOnly && ran && Config::Instance()->DlssNrApplyModel.value_or_default() && !lightTally.empty())
    {
        // Light forms: keep the line with the per-second counters (set above) instead of the generic text.
    }
    else
        late.Say(!Config::Instance()->DlssNrApplyModel.value_or_default() ? "NR changes are hidden."
             : ran                                                    ? (slot.residualOnly
                                                                             ? (matchedResponse
                                                                                    ? "Applying pre-SR changes with HDR brightness matching (local fallback enabled)."
                                                                                    : "Applying the pre-SR changes to the finished picture.")
                                                                             : "Applying NR to the finished picture.")
                                                                      : "Preparing NR for the finished picture.");
    if (ran && (++late.successes == 1 || late.successes % 300 == 0))
        LOG_INFO("DLSS-NR finished picture: {} frames, {}x{}, OptiScaler FG {}, same producer queue {}, game-frame handoff {}", late.successes, desc.Width, desc.Height,
                 ::State::Instance().currentFG && ::State::Instance().currentFG->IsActive() &&
                     !::State::Instance().currentFG->IsPaused(), slot.producerQueue.Get() == realQueue, gameFrameHandoff);
    return ran;
}
