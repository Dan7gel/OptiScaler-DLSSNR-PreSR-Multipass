#include "pch.h"
#include "DlssNr_Dx12_State.h"

// Temporal reuse surfaces: created at the frame size the first time reuse is wanted, dropped on a
// size change and with the other NR surfaces. All rest in UAV state between frames.

auto DlssNr_Dx12::State::EnsureTemporalSurfaces(ID3D12Device* device, unsigned int width, unsigned int height) -> bool
{
    if (device == nullptr || width == 0 || height == 0 || nr.hdrCopy == nullptr)
        return false;

    if (nr.tempResidual != nullptr &&
        (nr.tempWidth != width || nr.tempHeight != height ||
         (nr.tempPassColour != nullptr && nr.tempPassColour->GetDesc().Format != nr.hdrCopy->GetDesc().Format)))
        ReleaseTemporalSurfaces();

    if (nr.temporal == nullptr)
        nr.temporal = new DlssNrTemporal_Dx12("DLSS-NR temporal reuse", device);
    if (nr.temporal == nullptr || !nr.temporal->IsInit())
        return false;

    if (nr.tempResidual == nullptr)
    {
        const unsigned int lowW = (width + 15) / 16, lowH = (height + 15) / 16;
        nr.tempResidual = CreateScratch(device, DXGI_FORMAT_R16G16B16A16_FLOAT, width, height);
        nr.tempResidualLow = CreateScratch(device, DXGI_FORMAT_R16G16B16A16_FLOAT, lowW, lowH);
        nr.tempPassDepth = CreateScratch(device, DXGI_FORMAT_R32_FLOAT, width, height);
        nr.tempPassColour = CreateScratch(device, nr.hdrCopy->GetDesc().Format, width, height);
        nr.tempAccum[0] = CreateScratch(device, DXGI_FORMAT_R16G16B16A16_FLOAT, width, height);
        nr.tempAccum[1] = CreateScratch(device, DXGI_FORMAT_R16G16B16A16_FLOAT, width, height);
        nr.tempWidth = width;
        nr.tempHeight = height;
        nr.tempValid = false;
        nr.tempCounter = 0;
        nr.tempAccumIndex = 0;
        if (nr.tempResidual == nullptr || nr.tempResidualLow == nullptr || nr.tempPassDepth == nullptr ||
            nr.tempPassColour == nullptr || nr.tempAccum[0] == nullptr || nr.tempAccum[1] == nullptr)
        {
            LOG_WARN("DLSS-NR temporal reuse: surfaces could not be created; running every frame");
            ReleaseTemporalSurfaces();
            return false;
        }
    }
    return true;
}

auto DlssNr_Dx12::State::ReleaseTemporalSurfaces() -> void
{
    if (nr.tempResidual != nullptr)
        ParkNrResource(nr.tempResidual);
    if (nr.tempResidualLow != nullptr)
        ParkNrResource(nr.tempResidualLow);
    if (nr.tempPassDepth != nullptr)
        ParkNrResource(nr.tempPassDepth);
    if (nr.tempPassColour != nullptr)
        ParkNrResource(nr.tempPassColour);
    for (auto& a : nr.tempAccum)
        if (a != nullptr)
            ParkNrResource(a);
    if (nr.temporal != nullptr)
    {
        lifetime.Retire([t = nr.temporal] { delete t; });
        nr.temporal = nullptr;
    }
    nr.tempWidth = nr.tempHeight = 0;
    nr.tempValid = false;
    nr.tempCounter = 0;
}
