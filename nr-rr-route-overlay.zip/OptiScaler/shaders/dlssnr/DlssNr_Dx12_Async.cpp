#include "pch.h"
#include "DlssNr_Dx12_State.h"
#include <dlssnr/DlssNr_AsyncStatus.h>
#include <shaders/dlssnr/DlssNr_Guides.h>
#include <algorithm>
#include <cmath>
#include <cstdio>

// ASYNC NR (ULTIMATE77)
//
// The model never sits on the frame's critical path. At the NR seam of frame N the host list copies the
// frame's colour, depth and motion into a private slot and the model pass for that slot is recorded on
// an owned list and queued on an owned high-priority queue behind a fence the host queue signals once
// the frame's list has actually been submitted. Meanwhile the host list composes this frame from the
// last FINISHED pass: original + that pass's residual reprojected along the chain of motion vectors
// accumulated since the pass frame, with the same acceptance tests, fill and smoothing as before.
//
// Two chains are kept: the main chain (this frame -> the pass on screen) and the pending chain (this
// frame -> the frame of the last kick). The pending chain is what the next model pass receives as its
// motion input, so the model's own history stays aligned across the frames it did not see; when a
// pass is adopted the pending chain becomes the main chain.
//
// Cross-queue safety: a slot is written only by its own job and read by the host only after fModel
// reached the job; the other slot is the visible one and is never written while a job runs. The host
// waits on the GPU for a pass only when the visible pass is older than the age cap.

namespace
{
using Microsoft::WRL::ComPtr;

ID3D12Resource* CreateTyped(ID3D12Device* device, DXGI_FORMAT format, unsigned int width, unsigned int height,
                            D3D12_RESOURCE_STATES initial)
{
    D3D12_HEAP_PROPERTIES heap {};
    heap.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC desc {};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    desc.Width = width;
    desc.Height = height;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.Format = format;
    desc.SampleDesc.Count = 1;
    desc.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;
    desc.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
    ID3D12Resource* out = nullptr;
    if (FAILED(device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &desc, initial, nullptr,
                                               IID_PPV_ARGS(&out))))
        return nullptr;
    return out;
}
} // namespace

auto DlssNr_Dx12::State::EnsureAsync(ID3D12Device* device, unsigned int width, unsigned int height,
                                     DXGI_FORMAT colourFormat, ID3D12Resource* depthIn, ID3D12Resource* motionIn)
    -> bool
{
    if (device == nullptr || width == 0 || height == 0 || depthIn == nullptr || motionIn == nullptr)
        return false;

    const auto dd = depthIn->GetDesc();
    const auto md = motionIn->GetDesc();
    if (async.queue && (async.width != width || async.height != height || async.colourFormat != colourFormat ||
                        async.depthFormat != dd.Format || async.motionFormat != md.Format ||
                        async.depthWidth != dd.Width || async.depthHeight != dd.Height ||
                        async.motionWidth != md.Width || async.motionHeight != md.Height))
        ReleaseAsync();

    if (nr.temporal == nullptr)
        nr.temporal = new DlssNrTemporal_Dx12("DLSS-NR async temporal", device);
    if (nr.temporal == nullptr || !nr.temporal->IsInit())
        return false;

    if (async.queue)
        return true;

    // A COMPUTE queue is the one that runs concurrently with the game's graphics work on NVIDIA (async
    // compute); two DIRECT queues are time-sliced instead, which serialises the model behind the frame
    // and costs far more than it saves. Direct is kept as a fallback for a runtime that refuses to
    // evaluate on a compute list. Normal priority: the model must not starve the frame.
    async.queueType = async.useDirect ? D3D12_COMMAND_LIST_TYPE_DIRECT : D3D12_COMMAND_LIST_TYPE_COMPUTE;
    D3D12_COMMAND_QUEUE_DESC qd {};
    qd.Type = async.queueType;
    qd.Priority = D3D12_COMMAND_QUEUE_PRIORITY_NORMAL;
    if (FAILED(device->CreateCommandQueue(&qd, IID_PPV_ARGS(&async.queue))))
    {
        async.status = "ASYNC NR: the background queue could not be created.";
        return false;
    }
    if (FAILED(device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&async.fInputs))) ||
        FAILED(device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&async.fModel))))
    {
        ReleaseAsync();
        async.status = "ASYNC NR: fences could not be created.";
        return false;
    }

    const unsigned int lowW = (width + 15) / 16, lowH = (height + 15) / 16;
    bool ok = true;
    for (auto& slot : async.slots)
    {
        slot.colour = CreateTyped(device, colourFormat, width, height, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        slot.output = CreateTyped(device, colourFormat, width, height, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        slot.depth = CreateTyped(device, dd.Format, (unsigned int) dd.Width, dd.Height,
                                 D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        slot.motion = CreateTyped(device, md.Format, (unsigned int) md.Width, md.Height,
                                  D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        slot.chain = CreateTyped(device, DXGI_FORMAT_R16G16B16A16_FLOAT, width, height,
                                 D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        slot.residual = CreateTyped(device, DXGI_FORMAT_R16G16B16A16_FLOAT, width, height,
                                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        slot.residualLow = CreateTyped(device, DXGI_FORMAT_R16G16B16A16_FLOAT, lowW, lowH,
                                       D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        slot.passDepth = CreateTyped(device, DXGI_FORMAT_R32_FLOAT, width, height,
                                     D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        ok = ok && slot.colour && slot.output && slot.depth && slot.motion && slot.chain && slot.residual &&
             slot.residualLow && slot.passDepth;
        if (ok && (FAILED(device->CreateCommandAllocator(async.queueType, IID_PPV_ARGS(&slot.allocator))) ||
                   FAILED(device->CreateCommandList(0, async.queueType, slot.allocator.Get(), nullptr,
                                                    IID_PPV_ARGS(&slot.commands))) ||
                   FAILED(slot.commands->Close())))
            ok = false;
        slot.valid = false;
        slot.job = 0;
    }
    async.orig = CreateTyped(device, colourFormat, width, height, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    async.scratch = CreateTyped(device, colourFormat, width, height, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    for (auto& c : async.mainChain)
        c = CreateTyped(device, DXGI_FORMAT_R16G16B16A16_FLOAT, width, height, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    for (auto& c : async.pendingChain)
        c = CreateTyped(device, DXGI_FORMAT_R16G16B16A16_FLOAT, width, height, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    ok = ok && async.orig && async.scratch && async.mainChain[0] && async.mainChain[1] && async.pendingChain[0] &&
         async.pendingChain[1];
    if (!ok)
    {
        ReleaseAsync();
        async.status = "ASYNC NR: private surfaces could not be created.";
        LOG_WARN("DLSS-NR async: private surfaces could not be created; running on the frame");
        return false;
    }

    async.width = width;
    async.height = height;
    async.colourFormat = colourFormat;
    async.depthFormat = dd.Format;
    async.motionFormat = md.Format;
    async.depthWidth = (unsigned int) dd.Width;
    async.depthHeight = dd.Height;
    async.motionWidth = (unsigned int) md.Width;
    async.motionHeight = md.Height;
    async.visible = -1;
    async.inflight = false;
    async.discard = false;
    async.mainValid = async.pendingValid = false;
    async.age = async.sinceKick = 0;
    async.kickCmd = nullptr;
    async.pendingSignal = 0;
    async.status.clear();
    LOG_INFO("DLSS-NR async: background {} queue ready ({}x{})",
             async.queueType == D3D12_COMMAND_LIST_TYPE_COMPUTE ? "compute" : "direct", width, height);
    return true;
}

auto DlssNr_Dx12::State::ReleaseAsync() -> void
{
    // Nothing here is released while the background queue may still be reading it.
    if (async.queue && async.fModel && async.jobId > 0 && async.fModel->GetCompletedValue() < async.jobId)
    {
        HANDLE event = CreateEventW(nullptr, FALSE, FALSE, nullptr);
        if (event != nullptr)
        {
            if (SUCCEEDED(async.fModel->SetEventOnCompletion(async.jobId, event)))
                WaitForSingleObject(event, 2000);
            CloseHandle(event);
        }
    }
    for (auto& slot : async.slots)
    {
        for (ID3D12Resource** r : { &slot.colour, &slot.output, &slot.depth, &slot.motion, &slot.chain, &slot.residual,
                                    &slot.residualLow, &slot.passDepth })
            if (*r != nullptr)
                ParkNrResource(*r);
        slot.commands.Reset();
        slot.allocator.Reset();
        slot.valid = false;
        slot.job = 0;
    }
    for (ID3D12Resource** r : { &async.orig, &async.scratch, &async.mainChain[0], &async.mainChain[1],
                                &async.pendingChain[0], &async.pendingChain[1] })
        if (*r != nullptr)
            ParkNrResource(*r);
    async.fInputs.Reset();
    async.fModel.Reset();
    async.queue.Reset();
    async.width = async.height = 0;
    async.visible = -1;
    async.inflight = false;
    async.mainValid = async.pendingValid = false;
    async.kickCmd = nullptr;
    async.pendingSignal = 0;
    if (nr.temporal != nullptr)
    {
        lifetime.Retire([t = nr.temporal] { delete t; });
        nr.temporal = nullptr;
    }
}

// Called from the ExecuteCommandLists hook after the real submission: the host list carrying a
// kick's input copies is now queued, so the job's input fence can be signalled behind it.
auto DlssNr_Dx12::State::AsyncSubmitted(ID3D12CommandQueue* queue, UINT count, ID3D12CommandList* const* lists) -> void
{
    if (async.pendingSignal == 0 || async.kickCmd == nullptr || queue == nullptr || !async.fInputs)
        return;
    for (UINT i = 0; i < count; ++i)
    {
        ID3D12CommandList* list = lists[i];
        ID3D12CommandList* real = nullptr;
        if (Util::CheckForRealObject(__FUNCTION__, list, (IUnknown**) &real))
            list = real;
        if (list == async.kickCmd)
        {
            queue->Signal(async.fInputs.Get(), async.pendingSignal);
            async.pendingSignal = 0;
            async.kickCmd = nullptr;
            return;
        }
    }
}

auto DlssNr_Dx12::State::RunAsync(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* target, ID3D12Resource* depth,
                                  ID3D12Resource* motion, const DlssNrFrameInfo& frame, ID3D12CommandQueue* timingQueue)
    -> void
{
    std::lock_guard<std::recursive_mutex> nrLock(mutex);
    (void) timingQueue;
    if (nr.failed || cmdList == nullptr || target == nullptr || depth == nullptr || motion == nullptr)
        return;

    ID3D12Device* device = nullptr;
    if (FAILED(cmdList->GetDevice(IID_PPV_ARGS(&device))) || device == nullptr)
        return;
    lifetime.Record(cmdList);

    const Config& cfg = *Config::Instance();
    const auto desc = target->GetDesc();
    const unsigned int width = frame.Width != 0 ? frame.Width : (unsigned int) desc.Width;
    const unsigned int height = frame.Height != 0 ? frame.Height : (unsigned int) desc.Height;
    const bool targetSupportsUav = (desc.Flags & D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS) != 0;
    const D3D12_RESOURCE_STATES arrival =
        frame.PipelineManagedStates ? D3D12_RESOURCE_STATE_UNORDERED_ACCESS
        : frame.BeforeUpscale ? (!frame.PrivateColorCopy && cfg.ColorResourceBarrier.has_value()
                                     ? (D3D12_RESOURCE_STATES) cfg.ColorResourceBarrier.value()
                                     : D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE)
        : cfg.OutputResourceBarrier.has_value() ? (D3D12_RESOURCE_STATES) cfg.OutputResourceBarrier.value()
                                                : D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    D3D12_RESOURCE_STATES targetState = arrival;
    const auto TransitionTarget = [&](D3D12_RESOURCE_STATES to)
    {
        if (targetState == to)
            return;
        Barrier(cmdList, target, targetState, to);
        targetState = to;
    };

    ID3D12Resource* depthIn = ReadableGuide(device, cmdList, depth, &nr.depthClone);
    ID3D12Resource* motionIn = ReadableGuide(device, cmdList, motion, &nr.motionClone);
    // Private surfaces follow the texture's allocation, not the active size: dynamic resolution and custom
    // resolutions move the active size every frame inside a fixed allocation.
    const unsigned int texWidth = (unsigned int) desc.Width, texHeight = desc.Height;
    if (depthIn == nullptr || motionIn == nullptr || width > texWidth || height > texHeight ||
        !EnsureAsync(device, texWidth, texHeight, desc.Format, depthIn, motionIn))
    {
        // Async unavailable: the frame path runs as before.
        device->Release();
        Run(cmdList, target, depth, motion, target, frame, timingQueue);
        return;
    }

    auto& A = async;
    const auto dd = depthIn->GetDesc();
    const auto md = motionIn->GetDesc();
    const unsigned int maxAge = std::clamp(cfg.DlssNrAsyncMaxAge.value_or_default(), 1u, 8u);
    const auto guides = DlssNr::ResolveGuideRegions(
        { (unsigned int) dd.Width, dd.Height }, { (unsigned int) md.Width, md.Height },
        { frame.RenderSubrectWidth, frame.RenderSubrectHeight }, { frame.OutputWidth, frame.OutputHeight },
        frame.MotionVectorsLowResolution, frame.DepthSubrectBaseX, frame.DepthSubrectBaseY,
        frame.MotionSubrectBaseX, frame.MotionSubrectBaseY);
    if (!guides.depth.valid() || !guides.motion.valid())
    {
        device->Release();
        return;
    }
    // The private output rests in the state the model pass expects it to arrive in.
    const D3D12_RESOURCE_STATES jobArrival =
        frame.BeforeUpscale ? D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE : D3D12_RESOURCE_STATE_UNORDERED_ACCESS;

    // Constants shared by the temporal passes this frame.
    DlssNrTemporalConstants tc;
    tc.Width = width;
    tc.Height = height;
    tc.GuideWidth = guides.depth.width;
    tc.GuideHeight = guides.depth.height;
    tc.GuideBaseX = guides.depth.x;
    tc.GuideBaseY = guides.depth.y;
    tc.MotionWidth = guides.motion.width;
    tc.MotionHeight = guides.motion.height;
    tc.MotionBaseX = guides.motion.x;
    tc.MotionBaseY = guides.motion.y;
    tc.DepthInverted = frame.DepthInverted ? 1u : 0u;
    tc.MvScaleX = frame.MvScaleX;
    tc.MvScaleY = frame.MvScaleY;
    tc.LowWidth = (width + 15) / 16;
    tc.LowHeight = (height + 15) / 16;
    tc.Linear = frame.ColourIsLinearHdr ? 1u : 0u;
    tc.DepthTol = std::clamp(cfg.DlssNrTemporalDepthTol.value_or_default(), 0.005f, 0.5f);
    tc.ColourTol = std::clamp(cfg.DlssNrTemporalColourTol.value_or_default(), 0.01f, 0.5f);
    tc.FillStrength = std::clamp(cfg.DlssNrTemporalFill.value_or_default(), 0.0f, 1.0f);
    tc.BlendMax = std::clamp(cfg.DlssNrTemporalBlend.value_or_default(), 0.0f, 0.9f);
    tc.TexWidth = A.width;
    tc.TexHeight = A.height;

    // 0. This frame's colour, readable, for the compose and as the pass colour of a kick.
    TransitionTarget(D3D12_RESOURCE_STATE_COPY_SOURCE);
    Barrier(cmdList, A.orig, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
    cmdList->CopyResource(A.orig, target);
    Barrier(cmdList, A.orig, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);

    if (frame.Reset || A.activeWidth != width || A.activeHeight != height)
    {
        A.mainValid = A.pendingValid = false;
        A.visible = -1;
        if (A.inflight)
            A.discard = true;
        if (frame.Reset)
            nr.reset = true;
        A.activeWidth = width;
        A.activeHeight = height;
    }

    // 1. Chains: extend both by this frame's motion.
    const auto Accumulate = [&](ID3D12Resource** chain, unsigned int& idx, bool& valid, bool reset)
    {
        const unsigned int prev = idx, cur = 1 - idx;
        DlssNrTemporalConstants c = tc;
        c.Mode = 2;
        c.ResetAccum = reset ? 1u : 0u;
        if (!reset)
            Barrier(cmdList, chain[prev], D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        ID3D12Resource* ins[7] = { reset ? motionIn : chain[prev], motionIn, nullptr, nullptr, nullptr, nullptr, nullptr };
        ID3D12Resource* outs[2] = { chain[cur], nullptr };
        nr.temporal->Dispatch(cmdList, c, ins, outs, width, height);
        if (!reset)
            Barrier(cmdList, chain[prev], D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        idx = cur;
        valid = true;
    };
    if (A.mainValid)
        Accumulate(A.mainChain, A.mainIdx, A.mainValid, false);
    if (A.pendingValid)
        Accumulate(A.pendingChain, A.pendingIdx, A.pendingValid, false);

    // The kick's input copies are signalled by the ExecuteCommandLists hook. If that hook never saw the
    // host list (a queue OptiScaler does not observe), signal from the host queue now: the copies were
    // recorded frames ago and have long been submitted.
    if (A.pendingSignal != 0 && A.sinceKick > 8)
    {
        auto* host = (ID3D12CommandQueue*) ::State::Instance().currentCommandQueue;
        if (host != nullptr && SUCCEEDED(host->Signal(A.fInputs.Get(), A.pendingSignal)))
        {
            A.pendingSignal = 0;
            A.kickCmd = nullptr;
        }
    }

    // 2. Adopt the finished pass, or make the host queue wait for it when the visible pass is too old.
    bool ready = A.inflight && A.fModel->GetCompletedValue() >= A.jobId;
    if (!ready && A.inflight && A.age >= maxAge && A.pendingSignal == 0)
    {
        auto* host = (ID3D12CommandQueue*) ::State::Instance().currentCommandQueue;
        if (host != nullptr && SUCCEEDED(host->Wait(A.fModel.Get(), A.jobId)))
        {
            ++A.forcedWaits;
            ready = true;
        }
    }
    if (ready)
    {
        A.inflight = false;
        if (!A.discard)
        {
            A.visible = (int) A.inflightSlot;
            A.slots[A.inflightSlot].valid = true;
            // The pending chain (this frame -> the kick frame) is exactly the main chain for the new pass.
            std::swap(A.mainChain[0], A.pendingChain[0]);
            std::swap(A.mainChain[1], A.pendingChain[1]);
            A.mainIdx = A.pendingIdx;
            A.mainValid = A.pendingValid;
            A.pendingValid = false;
            A.age = 0;
            ++A.passes;
        }
        A.discard = false;
    }

    // 3. Kick a new pass when none is in flight: private copies on the host list, the model pass on
    //    the owned list, queued behind the input fence.
    if (!A.inflight && !nr.failed)
    {
        const unsigned int s = A.visible == 0 ? 1u : 0u;
        auto& slot = A.slots[s];
        const AsyncSlot* prev = A.visible >= 0 ? &A.slots[A.visible] : nullptr;

        // Colour: the frame as it arrived (pass colour) and the in-place edit base.
        {
            Barrier(cmdList, A.orig, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_SOURCE);
            Barrier(cmdList, slot.colour, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
            cmdList->CopyResource(slot.colour, A.orig);
            Barrier(cmdList, slot.colour, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            Barrier(cmdList, slot.output, slot.outputArrival, D3D12_RESOURCE_STATE_COPY_DEST);
            cmdList->CopyResource(slot.output, A.orig);
            Barrier(cmdList, slot.output, D3D12_RESOURCE_STATE_COPY_DEST, jobArrival);
            Barrier(cmdList, A.orig, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        }
        // Depth: typed copy of the readable depth.
        Barrier(cmdList, slot.depth, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
        Barrier(cmdList, depthIn, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_SOURCE);
        cmdList->CopyResource(slot.depth, depthIn);
        Barrier(cmdList, depthIn, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        Barrier(cmdList, slot.depth, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        // Motion for the model: the displacement to the frame of the previous kick when one exists
        // (the model's history is that frame), else this frame's own vectors. And a snapshot of the
        // pending chain for the pass-to-pass blend.
        const bool chained = A.pendingValid && prev != nullptr;
        Barrier(cmdList, slot.motion, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        Barrier(cmdList, slot.chain, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        if (chained)
        {
            Barrier(cmdList, A.pendingChain[A.pendingIdx], D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            {
                DlssNrTemporalConstants c = tc;
                c.Mode = 6;
                ID3D12Resource* ins[7] = { A.pendingChain[A.pendingIdx], nullptr, nullptr, nullptr, nullptr, nullptr, nullptr };
                ID3D12Resource* outs[2] = { slot.motion, slot.chain };
                nr.temporal->Dispatch(cmdList, c, ins, outs, (unsigned int) md.Width, md.Height);
            }
            Barrier(cmdList, A.pendingChain[A.pendingIdx], D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        }
        else
        {
            Barrier(cmdList, slot.motion, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_DEST);
            Barrier(cmdList, motionIn, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_SOURCE);
            cmdList->CopyResource(slot.motion, motionIn);
            Barrier(cmdList, motionIn, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            Barrier(cmdList, slot.motion, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        }
        Barrier(cmdList, slot.motion, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        Barrier(cmdList, slot.chain, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        slot.jitterX = frame.JitterX;
        slot.jitterY = frame.JitterY;
        slot.outputArrival = jobArrival;

        // The model pass, recorded on the slot's own list.
        bool recorded = false;
        if (SUCCEEDED(slot.allocator->Reset()) && SUCCEEDED(slot.commands->Reset(slot.allocator.Get(), nullptr)))
        {
            DlssNrFrameInfo job = frame;
            job.PrivateColorCopy = frame.BeforeUpscale;      // pre-SR: arrives/returns readable
            job.PipelineManagedStates = !frame.BeforeUpscale; // after: arrives/returns as a UAV
            job.IndependentCommands = true;
            job.FinishedPicture = false;
            job.OutputArrivalState = (uint32_t) jobArrival;
            job.Reset = nr.reset;
            ID3D12GraphicsCommandList* list = slot.commands.Get();
            const bool failedBefore = nr.failed;
            // No root-signature restore on the owned list: a restore issues graphics-state calls that a
            // compute list must never see, and there is no game state on this list to restore anyway.
            const bool tracking = D3D12Hooks::IsRootSignatureTrackingEnabled();
            D3D12Hooks::SetRootSignatureTracking(false);
            Run(list, slot.output, slot.depth, slot.motion, slot.output, job, A.queue.Get());
            D3D12Hooks::SetRootSignatureTracking(tracking);
            nr.reset = false;
            if (nr.failed && !failedBefore && !A.useDirect)
            {
                // The runtime would not evaluate on a compute list: rebuild on a direct queue once.
                LOG_WARN("DLSS-NR async: the model refused the compute queue; switching to a direct queue");
                list->Close();
                A.useDirect = true;
                RetryAfterFailure();
                ReleaseAsync();
                device->Release();
                return;
            }

            // Residual of this pass (with the pass-to-pass blend against the visible pass moved along the
            // snapshot chain), its depth, and the 1/16 box residual.
            if (jobArrival != D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE)
                Barrier(list, slot.output, jobArrival, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            for (ID3D12Resource* r : { slot.residual, slot.passDepth, slot.residualLow })
                Barrier(list, r, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            {
                DlssNrTemporalConstants c = tc;
                c.Mode = 0;
                c.BlendMax = chained ? c.BlendMax : 0.0f;
                if (frame.BeforeUpscale && cfg.DlssNrTemporalJitter.value_or_default() && prev != nullptr)
                {
                    c.JitterDX = frame.JitterX - prev->jitterX;
                    c.JitterDY = frame.JitterY - prev->jitterY;
                }
                ID3D12Resource* ins[7] = { slot.output, slot.colour, slot.depth,
                                           chained ? prev->residual : nullptr, chained ? slot.chain : nullptr,
                                           chained ? prev->passDepth : nullptr, chained ? prev->colour : nullptr };
                ID3D12Resource* outs[2] = { slot.residual, slot.passDepth };
                nr.temporal->Dispatch(list, c, ins, outs, width, height);
            }
            Barrier(list, slot.residual, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            {
                DlssNrTemporalConstants c = tc;
                c.Mode = 1;
                ID3D12Resource* ins[7] = { slot.residual, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr };
                ID3D12Resource* outs[2] = { slot.residualLow, nullptr };
                nr.temporal->Dispatch(list, c, ins, outs, c.LowWidth, c.LowHeight);
            }
            for (ID3D12Resource* r : { slot.passDepth, slot.residualLow })
                Barrier(list, r, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            if (jobArrival != D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE)
                Barrier(list, slot.output, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, jobArrival);
            recorded = SUCCEEDED(list->Close());
        }

        if (recorded)
        {
            ++A.jobId;
            slot.job = A.jobId;
            slot.valid = false;
            A.inflightSlot = s;
            A.inflight = true;
            A.discard = false;
            A.sinceKick = 0;
            ID3D12GraphicsCommandList* real = nullptr;
            A.kickCmd = Util::CheckForRealObject(__FUNCTION__, cmdList, (IUnknown**) &real) ? real : cmdList;
            A.pendingSignal = A.jobId;
            ID3D12CommandList* lists[] = { slot.commands.Get() };
            A.queue->Wait(A.fInputs.Get(), A.jobId);
            A.queue->ExecuteCommandLists(1, lists);
            A.queue->Signal(A.fModel.Get(), A.jobId);
            FinishedPictureSubmitted(A.queue.Get(), 1, lists); // lifetime + model submission bookkeeping
            // The pending chain restarts at this frame.
            Accumulate(A.pendingChain, A.pendingIdx, A.pendingValid, true);
        }
        else
            A.status = "ASYNC NR: the model pass could not be recorded.";
    }

    // 4. Compose: original + the visible pass's residual reprojected along the main chain.
    bool composed = false;
    if (A.visible >= 0 && A.mainValid && A.slots[A.visible].valid)
    {
        const auto& vis = A.slots[A.visible];
        ID3D12Resource* composeTarget = targetSupportsUav ? target : A.scratch;
        if (targetSupportsUav)
            TransitionTarget(D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        Barrier(cmdList, A.mainChain[A.mainIdx], D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        {
            DlssNrTemporalConstants c = tc;
            c.Mode = 3;
            if (frame.BeforeUpscale && cfg.DlssNrTemporalJitter.value_or_default())
            {
                c.JitterDX = frame.JitterX - vis.jitterX;
                c.JitterDY = frame.JitterY - vis.jitterY;
            }
            ID3D12Resource* ins[7] = { A.orig, vis.residual, vis.residualLow, A.mainChain[A.mainIdx],
                                       depthIn, vis.passDepth, vis.colour };
            ID3D12Resource* outs[2] = { composeTarget, nullptr };
            composed = nr.temporal->Dispatch(cmdList, c, ins, outs, width, height);
        }
        Barrier(cmdList, A.mainChain[A.mainIdx], D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        if (composed && !targetSupportsUav)
        {
            Barrier(cmdList, A.scratch, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
            TransitionTarget(D3D12_RESOURCE_STATE_COPY_DEST);
            cmdList->CopyResource(target, A.scratch);
            Barrier(cmdList, A.scratch, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        }
    }
    TransitionTarget(arrival);

    ++A.age;
    ++A.sinceKick;
    modelRunning = composed;
    if (composed)
        ++nr.successfulDispatches;
    {
        char buf[160];
        snprintf(buf, sizeof(buf), "ASYNC NR (%s queue): %s, pass age %u frame%s, %llu passes, %llu forced waits",
                 A.queueType == D3D12_COMMAND_LIST_TYPE_COMPUTE ? "compute" : "direct",
                 composed ? "composing" : "waiting for the first pass", A.age, A.age == 1 ? "" : "s",
                 (unsigned long long) A.passes, (unsigned long long) A.forcedWaits);
        A.status = buf;
        DlssNr::AsyncStatus::Set(A.status);
    }

    if (depthIn == nr.depthClone)
        Barrier(cmdList, nr.depthClone, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
    if (motionIn == nr.motionClone)
        Barrier(cmdList, nr.motionClone, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
    device->Release();
}
