#include "pch.h"
#include <dlssnr/DlssNr_TokenFit.h>
#include "DlssNr_Dx12_State.h"
#include <utility>

auto DlssNr_Dx12::State::Run(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* colour, ID3D12Resource* depth, ID3D12Resource* motion,
             ID3D12Resource* output, const DlssNrFrameInfo& frame, ID3D12CommandQueue* timingQueue) -> void
{
    std::lock_guard<std::recursive_mutex> nrLock(mutex);
    const Config& cfg = *Config::Instance();

    if (nr.failed || cmdList == nullptr || colour == nullptr || depth == nullptr || motion == nullptr ||
        output == nullptr)
    {
        ReportSkipOnce(nr.failed ? "it already failed this session" : "a resource was missing");
        return;
    }

    ID3D12Resource* target = output;

    // Guard creation and dispatch together: either can record GPU work and alter compute bindings.
    const bool restoreRequired =
        cfg.RestoreComputeSignature.value_or_default() || cfg.RestoreGraphicSignature.value_or_default();
    if (restoreRequired && !frame.IndependentCommands && !D3D12Hooks::CanRestoreRootSignature(cmdList))
    {
        ReportSkipOnce("the upscaler could not restore state this frame");
        return;
    }
    lifetime.Record(cmdList);
    ScopedNrStateEnvelope stateEnvelope(cmdList);

    // A completed upscaler output normally arrives as a UAV. The pre-SR colour input instead arrives
    // readable. Track every transition so both paths return the resource exactly as their caller gave
    // it to us; a pre-SR resource without UAV support is written through a scratch-and-copy fallback.
    const D3D12_RESOURCE_STATES outputArrival =
        frame.PipelineManagedStates ? D3D12_RESOURCE_STATE_UNORDERED_ACCESS
        : frame.FinishedPicture     ? (D3D12_RESOURCE_STATES) frame.OutputArrivalState
        : frame.BeforeUpscale ? (!frame.PrivateColorCopy && Config::Instance()->ColorResourceBarrier.has_value()
                                     ? (D3D12_RESOURCE_STATES) Config::Instance()->ColorResourceBarrier.value()
                                     : D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE)
        : Config::Instance()->OutputResourceBarrier.has_value()
            ? (D3D12_RESOURCE_STATES) Config::Instance()->OutputResourceBarrier.value()
            : D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    D3D12_RESOURCE_STATES targetState = outputArrival;
    const auto TransitionTarget = [&](D3D12_RESOURCE_STATES to)
    {
        Barrier(cmdList, target, targetState, to);
        targetState = to;
    };

    ID3D12Device* device = nullptr;

    if (FAILED(target->GetDevice(IID_PPV_ARGS(&device))) || device == nullptr)
    {
        ReportSkipOnce("the output texture belongs to no D3D12 device");
        return;
    }

    const D3D12_RESOURCE_DESC desc = target->GetDesc();
    const auto active =
        frame.BeforeUpscale
            ? DlssNr::PreSrColorExtent(desc, frame.RenderSubrectWidth, frame.RenderSubrectHeight)
            : std::optional<DlssNr::ColorExtent> { DlssNr::ColorExtent { (unsigned int) desc.Width, desc.Height } };
    if (!active)
    {
        ReportSkipOnce("the pre-SR active colour size is invalid");
        device->Release();
        return;
    }
    const auto width = active->width;
    const auto height = active->height;
    const bool cropColor = frame.BeforeUpscale && (width != desc.Width || height != desc.Height);
    const bool targetSupportsUav = cropColor || (desc.Flags & D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS) != 0;

    const auto guideDesc = depth->GetDesc();
    const auto motionDesc = motion->GetDesc();
    const auto guides = DlssNr::ResolveGuideRegions(
        { (unsigned int) guideDesc.Width, guideDesc.Height },
        { (unsigned int) motionDesc.Width, motionDesc.Height },
        { frame.RenderSubrectWidth, frame.RenderSubrectHeight }, { frame.OutputWidth, frame.OutputHeight },
        frame.MotionVectorsLowResolution, frame.DepthSubrectBaseX, frame.DepthSubrectBaseY,
        frame.MotionSubrectBaseX, frame.MotionSubrectBaseY);
    if (!guides.depth.valid() || !guides.motion.valid())
    {
        ReportSkipOnce("depth or motion-vector subrect is empty");
        device->Release();
        return;
    }
    const auto guideWidth = guides.depth.width, guideHeight = guides.depth.height;
    const auto motionWidth = guides.motion.width, motionHeight = guides.motion.height;
    const auto depthBaseX = guides.depth.x, depthBaseY = guides.depth.y;
    const auto motionBaseX = guides.motion.x, motionBaseY = guides.motion.y;

    nr.guideWidth = guideWidth;
    nr.guideHeight = guideHeight;
    nr.guideDepthInverted = frame.DepthInverted;

    // The game's own encoding, passed through. Every resource already carries a subrect saying how
    // big it is, so scaling by the resolution ratio on top of that counts it twice -- vectors come
    // out too long and the model warps its history past where the surface went.
    nr.guideMvScaleX = frame.MvScaleX;
    nr.guideMvScaleY = frame.MvScaleY;

    if (frame.Reset)
    {
        nr.reset = true;

        ++resets;

        if (resets <= 3 || resets % 100 == 0)
            LOG_INFO("DLSS-NR: the game asked for a history reset ({} so far)", resets);
    }

    // Guide dimensions can change without rebuilding the model; report changes as they occur.

    const GuideReport guidesNow {
        true,  nr.guideDepthInverted, nr.guideMvScaleX, nr.guideMvScaleY, guideWidth, guideHeight,
        width, (unsigned int) height
    };

    if (!loggedGuides.valid || loggedGuides.depthInverted != guidesNow.depthInverted ||
        loggedGuides.mvScaleX != guidesNow.mvScaleX || loggedGuides.mvScaleY != guidesNow.mvScaleY ||
        loggedGuides.guideW != guidesNow.guideW || loggedGuides.guideH != guidesNow.guideH ||
        loggedGuides.frameW != guidesNow.frameW || loggedGuides.frameH != guidesNow.frameH)
    {
        loggedGuides = guidesNow;
        LOG_INFO("DLSS-NR guides: depth {}, motion vector scale {} x {}, guides {}x{} for a {}x{} frame",
                 nr.guideDepthInverted ? "inverted" : "not inverted", nr.guideMvScaleX, nr.guideMvScaleY,
                 guideWidth, guideHeight, width, height);
    }

    // The dedicated RR route selects RRPasses/RRWorkingScale; otherwise SR and RR+SR share the settings.
    const unsigned int configuredPasses = DlssNr::ModelPasses(cfg, frame.RayReconstruction);
    const unsigned int requestedPasses = configuredPasses;
    for (auto& model : nr.models)
        model.AdvanceEpoch(frame.SubmissionEpoch);
    if ((!NVNGXProxy::IsDx12Inited() && !NVNGXProxy::InitDx12(device)) || !DlssNr::Proxy::Context::Available())
    {
        nr.failed = true;
        nr.reason = "the NVIDIA NGX driver does not provide Neural Rendering";
        LOG_ERROR("DLSS-NR unavailable: {}", nr.reason);
        device->Release();
        return;
    }

    // Only the model runs at working resolution; source and composition remain at native size.
    // A token fit in progress probes its own scale; otherwise the configured route scale applies.
    const float workScale = DlssNr::TokenFit::ScaleOverride(frame.RayReconstruction)
                                .value_or(DlssNr::ModelWorkingScale(cfg, frame.RayReconstruction));
    const auto workWidth = (unsigned int) (width * workScale + 0.5f);
    const auto workHeight = (unsigned int) (height * workScale + 0.5f);
    const bool reduced = workWidth != width || workHeight != height;
    if (!PrepareRunModels(cmdList, device, frame, desc, { width, height }, { workWidth, workHeight },
                          workScale, requestedPasses))
    {
        device->Release();
        return;
    }
    // The parameter adapter already combined the HDR flag with the active color format.
    const bool isHdrBuffer = frame.ColourIsLinearHdr;

    if (!reportedHdr || reportedHdrValue != isHdrBuffer || reportedBefore != frame.BeforeUpscale)
    {
        reportedHdr = true;
        reportedHdrValue = isHdrBuffer;
        reportedBefore = frame.BeforeUpscale;
        LOG_INFO("DLSS-NR {} SR: the game's DLSS colour space is {} so the colour transform is {}",
                 frame.BeforeUpscale ? "before" : "after", isHdrBuffer ? "linear HDR" : "already tone-mapped",
                 isHdrBuffer ? "on" : "off");
    }

    const bool haveCodec = shader.IsInit();

    if (!haveCodec)
    {
        nr.failed = true;
        nr.reason = "the colour codec would not compile";
        LOG_ERROR("DLSS-NR unavailable: {}", nr.reason);
        device->Release();
        return;
    }

    // Advance capture scheduling only once the codec and models are ready.
    ++frames;
    TickNrRetired(frame.SubmissionEpoch);
    CheckCaptureTrigger();

    if (captureWriteAtFrame != 0 && frames >= captureWriteAtFrame)
    {
        captureWriteAtFrame = 0;
        const auto captureDir = Util::DllPath().remove_filename() / "dlssnr-capture";
        const auto written = captureFrames.write(captureDir);

        if (!written.empty())
            LOG_INFO("DLSS-NR wrote matched before/after frames to {}", written);
    }

    // Paper white maps the frame into the model's display-referred proxy.

    ResTrack_Dx12::HookLateNrQueue(device);
    if (gpuTime == nullptr)
        gpuTime = std::make_unique<DlssNrGpuTime>(device, "total");

    if (ngxTime == nullptr)
        ngxTime = std::make_unique<DlssNrGpuTime>(device, "model");

    if (gpuTime != nullptr)
        gpuTime->Start(cmdList);

    // Copy just the live image, not the stale right/bottom margins. Do this only after model
    // creation/pending-submission early returns, and inside the measured GPU interval. The compact
    // texture lets every existing codec/compare/hold/capture path use unmodified pixel coordinates.
    ID3D12Resource* const gameColor = target;
    if (cropColor)
    {
        TransitionTarget(D3D12_RESOURCE_STATE_COPY_SOURCE);
        Barrier(cmdList, nr.activeColor, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_DEST);
        DlssNr::CopyActiveColor(cmdList, nr.activeColor, gameColor, *active);
        TransitionTarget(outputArrival);
        Barrier(cmdList, nr.activeColor, D3D12_RESOURCE_STATE_COPY_DEST,
                D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        target = nr.activeColor;
        targetState = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
    }

    const auto FinishColor = [&](bool copyBack)
    {
        if (cropColor)
        {
            if (copyBack)
            {
                TransitionTarget(D3D12_RESOURCE_STATE_COPY_SOURCE);
                Barrier(cmdList, gameColor, outputArrival, D3D12_RESOURCE_STATE_COPY_DEST);
                DlssNr::CopyActiveColor(cmdList, gameColor, target, *active);
                Barrier(cmdList, gameColor, D3D12_RESOURCE_STATE_COPY_DEST, outputArrival);
            }
            TransitionTarget(D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        }
        else
        {
            TransitionTarget(outputArrival);
        }
    };

    EncodeContext encoded { cmdList, device, target, targetState, frame, workScale, targetSupportsUav };
    EncodeInput(encoded);
    targetState = encoded.targetState;
    const auto whitePoint = encoded.whitePoint;
    auto* exposureTex = encoded.exposureTex;
    const auto useGameExposure = encoded.useGameExposure;
    const auto exposurePreMul = encoded.exposurePreMul;
    auto* modelInput = encoded.modelInput;

    // Read the exposure scan's candidates on the pass's own command list, once a frame.
    DlssNr::ExposureScan::Tick(device, cmdList, frame.SubmissionEpoch);

    ID3D12Resource* depthIn = ReadableGuide(device, cmdList, depth, &nr.depthClone);
    ID3D12Resource* motionIn = ReadableGuide(device, cmdList, motion, &nr.motionClone);

    if (depthIn == nullptr || motionIn == nullptr)
    {
        nr.reset = true;
        ReportSkipOnce("the game's depth or motion vectors could not be made readable this frame");
        FinishColor(false);
        device->Release();
        return;
    }

    // The vectors were scaled to full-frame pixels; the image the model reprojects is the working size.
    const float mvToWorkX = width != 0 ? (float) workWidth / (float) width : 1.0f;
    const float mvToWorkY = height != 0 ? (float) workHeight / (float) height : 1.0f;

    if (ngxTime != nullptr)
        ngxTime->Start(cmdList);

    // Count only a contiguous set of ready, separate feature histories. A failed extra creation never
    // falls back to reusing the main feature: that tells one temporal model several frames elapsed in
    // one game frame and makes its history fight the later layers.
    unsigned int effectivePasses = 1;
    if (nr.passScratch != nullptr)
    {
        for (unsigned int pass = 1; pass < requestedPasses; ++pass)
        {
            if (!nr.models[pass].Ready(frame.SubmissionEpoch))
                break;
            ++effectivePasses;
        }
    }

    {

        if (loggedConfigured != configuredPasses || loggedEffective != effectivePasses)
        {
            loggedConfigured = configuredPasses;
            loggedEffective = effectivePasses;
            LOG_INFO("DLSS-NR model passes: configured {}, effective {}", configuredPasses, effectivePasses);
        }
    }

    // Keep the encoded base immutable; ping-pong model outputs and compose the final delta once.
    ID3D12Resource* passInput = modelInput;
    ID3D12Resource* passOutput = nr.output;
    ID3D12Resource* finalAnswer = nullptr;
    bool outputReadable = false;
    bool scratchReadable = false;
    bool clampReadable = false;
    bool clampFailed = false;
    uint32_t clampSlots[2] = { UINT32_MAX, UINT32_MAX };

    const auto MakeModelReadable = [&](ID3D12Resource* resource)
    {
        bool& readable = resource == nr.output      ? outputReadable
                         : resource == nr.passClamp ? clampReadable
                                                    : scratchReadable;
        if (!readable)
        {
            Barrier(cmdList, resource, D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            readable = true;
        }
    };

    const auto MakeModelWritable = [&](ID3D12Resource* resource)
    {
        bool& readable = resource == nr.output      ? outputReadable
                         : resource == nr.passClamp ? clampReadable
                                                    : scratchReadable;
        if (readable)
        {
            Barrier(cmdList, resource, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            readable = false;
        }
    };

    int result = NVSDK_NGX_Result_Success;
    const bool enlargementReset = nr.reset;
    bool compositionSucceeded = false;

    for (unsigned int pass = 0; pass < effectivePasses && result == NVSDK_NGX_Result_Success; ++pass)
    {
        MakeModelWritable(passOutput);
        bool evaluated = false;
        result = static_cast<int>(nr.models[pass].Run(
            cmdList, device, passInput, depthIn, motionIn, passOutput, workWidth, workHeight, guideWidth,
            guideHeight, motionWidth, motionHeight, depthBaseX, depthBaseY, motionBaseX, motionBaseY,
            nr.guideDepthInverted, nr.reset, nr.guideMvScaleX * mvToWorkX, nr.guideMvScaleY * mvToWorkY,
            ModelSettings(cfg, pass), frame.SubmissionEpoch, &evaluated));
        modelRunning = evaluated && result == NVSDK_NGX_Result_Success;
        if (!evaluated)
            break;

        if (result != NVSDK_NGX_Result_Success)
            break;

        finalAnswer = passOutput;
        MakeModelReadable(finalAnswer);

        if (pass + 1 < effectivePasses)
        {
            MakeModelWritable(nr.passClamp);
            DlssNrConstants clamp {};
            clamp.Mode = DlssNrMode_ClampProxy;
            clamp.Width = workWidth;
            clamp.Height = workHeight;
            if (!shader.DispatchPass(cmdList, clamp, finalAnswer, nullptr, nullptr, nullptr, nullptr, nr.passClamp,
                                     nullptr, &clampSlots[pass % 2]))
            {
                // Keep this frame's last valid answer; later histories skipped a frame.
                clampFailed = true;
                effectivePasses = pass + 1;
                break;
            }
            MakeModelReadable(nr.passClamp);
            passInput = nr.passClamp;
            passOutput = passOutput == nr.output ? nr.passScratch : nr.output;
        }
    }

    if (ngxTime != nullptr)
        ngxTime->End(cmdList);

    // Token fit: record the grid this size produced; once settled, keep the winner in the route's setting.
    if (result == NVSDK_NGX_Result_Success && finalAnswer != nullptr)
    {
        if (const auto fitted =
                DlssNr::TokenFit::OnModelEvaluated(frame.RayReconstruction, workScale, workWidth, workHeight))
        {
            if (DlssNr::DedicatedRrRoute(cfg, frame.RayReconstruction))
                Config::Instance()->DlssNrRRWorkingScale = *fitted;
            else
                Config::Instance()->DlssNrWorkingScale = *fitted;
        }
    }

    nr.reset = clampFailed || finalAnswer == nullptr;

    // Supersampling probe: report the model working ABOVE native so a test log tells us whether NGX even
    // accepts a super-native evaluate and what it returns. Once per working-size change, or on any error.
    if (workWidth > width || workHeight > height)
    {

        if (lastSuper != workWidth || result != 1)
        {
            lastSuper = workWidth;
            LOG_INFO("DLSS-NR SUPERSAMPLE: model at {}x{} = {:.2f}x native {}x{}, evaluate result {} ({})",
                     workWidth, workHeight, (float) workWidth / (float) width, width, height, result,
                     NgxResultName((unsigned int) result));
        }
    }

    if (result == NVSDK_NGX_Result_Success && finalAnswer != nullptr)
    {
        // Resolve takes the difference between what the model returned and what it was shown, and adds
        // that back to the frame. At strength zero the result is what the upscaler produced, exactly, and
        // anything the model left alone is untouched rather than round-tripped through the curve.
        auto resolveParams = MakeResolveConstants(encoded, effectivePasses);
        // RR colour lock: light-only composition on the RR route, the game's hue and saturation kept.
        if (frame.RayReconstruction && DlssNr::DedicatedRrRoute(cfg, true) &&
            cfg.DlssNrRRColourLock.value_or_default())
            resolveParams.ColourStrength = 0.0f;

        // Downsample the model answer to native for composition; fall back to the working-size pair.
        // The final answer is NPSR and the native output rests in UAV.
        bool superDownOk = false;
        if (workScale > 1.0f && nr.superDown != nullptr && nr.outputNative != nullptr &&
            nr.superDown->DispatchResources(cmdList, finalAnswer, nr.outputNative))
        {
            Barrier(cmdList, nr.outputNative, D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            superDownOk = true;
        }

        ID3D12Resource* resolveProxy = superDownOk ? nr.colorCopy : modelInput;
        ID3D12Resource* resolveAnswer = superDownOk ? nr.outputNative : finalAnswer;

        bool enlargementReady = true;
        if (cfg.DlssNrTransfer.value_or_default() == 2 && reduced)
        {
            auto* enlarged = EnlargeMatchedResidual(cmdList, device, modelInput, finalAnswer, depthIn, motionIn,
                                                    frame, resolveParams, enlargementReset, timingQueue);
            enlargementReady = enlarged != nullptr;
            if (enlarged) { resolveAnswer = enlarged; resolveParams.Transfer = 2; }
            if (enlarged && resolveParams.DebugView == 2)
            { resolveAnswer = finalAnswer; resolveParams.Transfer = 1; } // Inspect the actual model answer.
        }
        else
        {
            ReleaseEnlarger();
            enlargementStatus.clear();
        }

        // Reduced up-leg, spatial filters. Runs when the DLSS enlarger is not in charge -- either by choice
        // or because it could not engage (pre-SR placement, still initialising): NR then keeps applying
        // through the chosen filter instead of the resolve being skipped.
        // Enlarge the model's answer AND the proxy it was shown with SGSR1 (edge-directed)
        // to native, and hand the resolve those two native-size pictures. Its edit is then the difference
        // of two enlargements with the same detail basis, laid on the frame's own full-resolution proxy
        // by the matched-residual block (EnlargedInput keeps that block active although the sizes now
        // agree). Skipped when the DLSS enlarger (Transfer 2) is in charge. Ported from janblade's fork.
        bool sgsrUpOk = false;
        const uint32_t enlargeFilter = cfg.DlssNrEnlargeFilter.value_or_default();
        if (reduced && workScale < 1.0f && enlargeFilter != 0 && enlargeFilter <= 3 &&
            resolveParams.Transfer != 2 && nr.outputNative != nullptr && nr.proxyNative != nullptr)
        {
            bool answerOk = false, proxyOk = false;
            if (enlargeFilter == 1)
            {
                if (nr.sgsr1UpAnswer == nullptr)
                    nr.sgsr1UpAnswer = new SGSR1_Dx12("DLSS-NR SGSR1 up (answer)", device);
                if (nr.sgsr1UpProxy == nullptr)
                    nr.sgsr1UpProxy = new SGSR1_Dx12("DLSS-NR SGSR1 up (proxy)", device);

                if (nr.sgsr1UpAnswer != nullptr && nr.sgsr1UpAnswer->IsInit() &&
                    nr.sgsr1UpAnswer->Dispatch(cmdList, finalAnswer, nr.outputNative, resolveParams.ReversibleMode,
                                               resolveParams.Passthrough))
                    answerOk = true;
                if (nr.sgsr1UpProxy != nullptr && nr.sgsr1UpProxy->IsInit() &&
                    nr.sgsr1UpProxy->Dispatch(cmdList, modelInput, nr.proxyNative, resolveParams.ReversibleMode,
                                              resolveParams.Passthrough))
                    proxyOk = true;
            }
            else
            {
                // FSR1 EASU (2) or bicubic (3) through the output-scaling pass in upsample mode. A filter
                // change retires the old pair and builds a new one.
                if ((nr.osUpAnswer != nullptr || nr.osUpProxy != nullptr) && nr.osUpFilter != enlargeFilter)
                {
                    if (nr.osUpAnswer != nullptr)
                        lifetime.Retire([up = nr.osUpAnswer] { delete up; });
                    if (nr.osUpProxy != nullptr)
                        lifetime.Retire([up = nr.osUpProxy] { delete up; });
                    nr.osUpAnswer = nullptr;
                    nr.osUpProxy = nullptr;
                }
                const Scaler scaler = enlargeFilter == 2 ? Scaler::FSR1 : Scaler::Bicubic;
                if (nr.osUpAnswer == nullptr)
                    nr.osUpAnswer = new OS_Dx12("DLSS-NR enlarge up (answer)", device, true, scaler);
                if (nr.osUpProxy == nullptr)
                    nr.osUpProxy = new OS_Dx12("DLSS-NR enlarge up (proxy)", device, true, scaler);
                nr.osUpFilter = enlargeFilter;

                if (nr.osUpAnswer != nullptr && nr.osUpAnswer->IsInit() &&
                    nr.osUpAnswer->DispatchResources(cmdList, finalAnswer, nr.outputNative))
                    answerOk = true;
                if (nr.osUpProxy != nullptr && nr.osUpProxy->IsInit() &&
                    nr.osUpProxy->DispatchResources(cmdList, modelInput, nr.proxyNative))
                    proxyOk = true;
            }
            if (answerOk)
                Barrier(cmdList, nr.outputNative, D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            if (proxyOk)
                Barrier(cmdList, nr.proxyNative, D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
            // Both or neither: one enlarged side against one small side would mismatch the detail basis.
            sgsrUpOk = answerOk && proxyOk;
            if (sgsrUpOk)
            {
                resolveProxy = nr.proxyNative;
                resolveAnswer = nr.outputNative;
                resolveParams.EnlargedInput = 1u;
            }
            else
            {
                // Put anything that did transition back the way the resolve's end-of-frame code expects.
                if (answerOk)
                    Barrier(cmdList, nr.outputNative, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                            D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
                if (proxyOk)
                    Barrier(cmdList, nr.proxyNative, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                            D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            }
            static bool loggedSgsr = false;
            static bool lastSgsrOk = false;
            if (!loggedSgsr || lastSgsrOk != sgsrUpOk)
            {
                LOG_INFO("DLSS-NR enlarge up-leg (filter {}): {} ({}x{} -> {}x{})", enlargeFilter,
                         sgsrUpOk ? "engaged" : "NOT engaged", workWidth, workHeight, width, height);
                loggedSgsr = true;
                lastSgsrOk = sgsrUpOk;
            }
        }

        // Resolve pre-SR inputs without UAV support through an owned scratch and copy-back.
        ID3D12Resource* resolveOriginal = targetSupportsUav ? nr.hdrCopy : target;
        ID3D12Resource* resolveTarget =
            targetSupportsUav ? target : nr.hdrCopy;

        if (targetSupportsUav)
        {
            TransitionTarget(D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        }
        else
        {
            Barrier(cmdList, nr.hdrCopy, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        }

        // The DLSS enlarger not being ready no longer skips the resolve: Transfer stays 1 (plain matched
        // residual, or the spatial filter above), so NR keeps applying while the status line says why.
        (void) enlargementReady;
        // Colour drift meter: the keep target is the frame itself when nothing is bound, so the stats
        // texture is bound and the shader flag set only together.
        const bool driftOn = cfg.DlssNrDriftMeter.value_or_default() && nr.driftStats != nullptr &&
                             resolveParams.DebugView == 0;
        resolveParams.DriftMeter = driftOn ? 1u : 0u;
        const bool resolved = shader.DispatchPass(cmdList, resolveParams, resolveProxy, resolveAnswer,
                                                  resolveOriginal, motionIn, exposureTex, resolveTarget,
                                                  driftOn ? nr.driftStats : nullptr);
        compositionSucceeded = resolved;
        if (resolved && driftOn)
        {
            CopyDriftToReadback(cmdList, width, height);
            ConsumeDriftReadback();
        }

        if (resolved && !targetSupportsUav)
        {
            Barrier(cmdList, nr.hdrCopy, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
            const D3D12_RESOURCE_STATES priorTargetState = targetState;
            TransitionTarget(D3D12_RESOURCE_STATE_COPY_DEST);
            cmdList->CopyResource(target, nr.hdrCopy);
            TransitionTarget(priorTargetState);
            Barrier(cmdList, nr.hdrCopy, D3D12_RESOURCE_STATE_COPY_SOURCE,
                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        }
        else if (!targetSupportsUav)
        {
            // The resolve target was made writable even while private DLSS was
            // warming up. Restore it before the common end-of-frame transition.
            Barrier(cmdList, nr.hdrCopy, D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        }

        MakeModelWritable(nr.output);
        if (nr.passScratch != nullptr)
            MakeModelWritable(nr.passScratch);

        if (superDownOk)
            Barrier(cmdList, nr.outputNative, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        if (sgsrUpOk)
        {
            Barrier(cmdList, nr.outputNative, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            Barrier(cmdList, nr.proxyNative, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        }

        // Schedule matched proxy/output capture for delayed readback.
        if (captureFrames.isActive())
        {
            captureFrames.record(cmdList, device, nr.colorCopy, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                                 target, targetState);

            if (captureFrames.readyToWrite() && captureWriteAtFrame == 0)
                captureWriteAtFrame = frames + 8;
        }
    }
    else if (result != NVSDK_NGX_Result_Success)
    {
        nr.failed = true;
        nr.reason = "the model refused to run";

        LOG_ERROR("DLSS-NR evaluate returned 0x{:X} ({}); use Retry to recreate the model", (uint32_t) result,
                  NgxResultName((unsigned int) result));
    }

    // Restore all intermediate surfaces to the UAV state expected by the next frame.
    MakeModelWritable(nr.output);
    if (nr.passScratch != nullptr)
        MakeModelWritable(nr.passScratch);

    Barrier(cmdList, nr.hdrCopy, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
            D3D12_RESOURCE_STATE_UNORDERED_ACCESS);

    if (nr.passClamp != nullptr)
        MakeModelWritable(nr.passClamp);

    // Failed evaluations leave the game's original image intact. A successful copy-back writes
    // only the active rectangle and restores both resources before DLSS consumes the image.
    FinishColor(compositionSucceeded);
    if (compositionSucceeded)
        ++nr.successfulDispatches;

    EndGpuTiming(cmdList, timingQueue);

    // Restore guide clones to COPY_DEST for the next frame's refresh.
    if (depthIn == nr.depthClone)
        Barrier(cmdList, nr.depthClone, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                D3D12_RESOURCE_STATE_COPY_DEST);

    if (motionIn == nr.motionClone)
        Barrier(cmdList, nr.motionClone, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                D3D12_RESOURCE_STATE_COPY_DEST);

    if (reduced && nr.colorSmall != nullptr)
        Barrier(cmdList, nr.colorSmall, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                D3D12_RESOURCE_STATE_UNORDERED_ACCESS);

    // Leave the staging copy as the next frame expects to find it.
    Barrier(cmdList, nr.colorCopy, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
            D3D12_RESOURCE_STATE_UNORDERED_ACCESS);

    device->Release();
}
