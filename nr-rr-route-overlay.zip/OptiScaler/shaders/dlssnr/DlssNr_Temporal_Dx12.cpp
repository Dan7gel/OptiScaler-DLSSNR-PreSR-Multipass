#include "pch.h"
#include "DlssNr_Temporal_Dx12.h"
#include "precompile/dlssnr_temporal_Shader.h"

bool DlssNrTemporal_Dx12::Dispatch(ID3D12GraphicsCommandList* cmdList, const DlssNrTemporalConstants& constants,
                                   ID3D12Resource* const* ins, ID3D12Resource* const* outs, uint32_t threadsX,
                                   uint32_t threadsY)
{
    if (!_init || _device == nullptr || cmdList == nullptr || ins == nullptr || outs == nullptr ||
        ins[0] == nullptr || outs[0] == nullptr)
        return false;

    _counter = (_counter + 1) % DLSSNR_TEMPORAL_NUM_OF_HEAPS;
    FrameDescriptorHeap& heap = _frameHeaps[_counter];

    for (uint32_t i = 0; i < 7; ++i)
        CreateShaderResourceView(_device, ins[i] != nullptr ? ins[i] : ins[0], heap.GetSrvCPU(i));
    for (uint32_t i = 0; i < 2; ++i)
        CreateUnorderedAccessView(_device, outs[i] != nullptr ? outs[i] : outs[0], heap.GetUavCPU(i), 0);

    if (!CreateConstantsBuffer(_device, _constantBuffers[_counter], constants, heap.GetCbvCPU(0)))
    {
        LOG_ERROR("[{0}] Failed to create a constants buffer", _name);
        return false;
    }

    ID3D12DescriptorHeap* heaps[] = { heap.GetHeapCSU() };
    cmdList->SetDescriptorHeaps(_countof(heaps), heaps);
    cmdList->SetComputeRootSignature(_rootSignature);
    cmdList->SetPipelineState(_pipelineState);
    cmdList->SetComputeRootDescriptorTable(0, heap.GetTableGPUStart());
    cmdList->Dispatch((threadsX + 7) / 8, (threadsY + 7) / 8, 1);
    return true;
}

DlssNrTemporal_Dx12::DlssNrTemporal_Dx12(std::string name, ID3D12Device* device) : Shader_Dx12(name, device)
{
    if (device == nullptr)
    {
        LOG_ERROR("InDevice is nullptr!");
        return;
    }

    CD3DX12_STATIC_SAMPLER_DESC sampler(0);
    sampler.Filter = D3D12_FILTER_MIN_MAG_LINEAR_MIP_POINT;
    sampler.AddressU = sampler.AddressV = D3D12_TEXTURE_ADDRESS_MODE_CLAMP;

    if (!SetupRootSignature(device, 7, 2, 1, 0, 0, 1, &sampler))
    {
        LOG_ERROR("[{0}] Failed to setup root signature", _name);
        return;
    }

    for (auto& cb : _constantBuffers)
    {
        D3D12_RESOURCE_DESC desc = CD3DX12_RESOURCE_DESC::Buffer(sizeof(DlssNrTemporalConstants));
        auto heapProps = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD);
        if (FAILED(device->CreateCommittedResource(&heapProps, D3D12_HEAP_FLAG_NONE, &desc,
                                                   D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&cb))))
        {
            LOG_ERROR("[{0}] Failed to create a constants buffer resource", _name);
            return;
        }
    }

    if (!Shader_Dx12::CreateComputePipeline(device, &_pipelineState, dlssnr_temporal_cso, sizeof(dlssnr_temporal_cso),
                                            nullptr))
    {
        LOG_ERROR("[{0}] CreateComputePipeline error!", _name);
        return;
    }

    _init = InitHeaps(device, _frameHeaps, DLSSNR_TEMPORAL_NUM_OF_HEAPS);
}

DlssNrTemporal_Dx12::~DlssNrTemporal_Dx12()
{
    if (State::Instance().isShuttingDown)
        return;
    for (auto& cb : _constantBuffers)
    {
        if (cb != nullptr)
        {
            cb->Release();
            cb = nullptr;
        }
    }
    if (!_init)
        return;
    for (auto& heap : _frameHeaps)
        heap.ReleaseHeaps();
}
