#pragma once

#include <shaders/Shader_Dx12.h>
#include <shaders/Shader_Dx12Utils.h>
#include <d3d12.h>
#include <d3dx/d3dx12.h>

#define DLSSNR_TEMPORAL_NUM_OF_HEAPS 32

// The temporal reuse passes (residual, downsample, accumulate, compose), one compute shader with a
// mode constant. Up to four dispatches per frame, each with its own heap and constants buffer.
struct alignas(256) DlssNrTemporalConstants
{
    uint32_t Mode = 0;
    uint32_t Width = 0;
    uint32_t Height = 0;
    uint32_t GuideWidth = 0;
    uint32_t GuideHeight = 0;
    uint32_t GuideBaseX = 0;
    uint32_t GuideBaseY = 0;
    uint32_t MotionWidth = 0;
    uint32_t MotionHeight = 0;
    uint32_t MotionBaseX = 0;
    uint32_t MotionBaseY = 0;
    uint32_t DepthInverted = 0;
    float MvScaleX = 1.0f;
    float MvScaleY = 1.0f;
    float JitterDX = 0.0f;
    float JitterDY = 0.0f;
    uint32_t LowWidth = 0;
    uint32_t LowHeight = 0;
    uint32_t ResetAccum = 0;
    uint32_t Linear = 1;
    float DepthTol = 0.05f;
    float ColourTol = 0.08f;
    float FillStrength = 1.0f;
    float BlendMax = 0.6f;
    uint32_t TexWidth = 0;
    uint32_t TexHeight = 0;
};

class DlssNrTemporal_Dx12 : public Shader_Dx12
{
  private:
    FrameDescriptorHeap _frameHeaps[DLSSNR_TEMPORAL_NUM_OF_HEAPS];
    ID3D12Resource* _constantBuffers[DLSSNR_TEMPORAL_NUM_OF_HEAPS] = {};

  public:
    // ins: up to 7 shader resources (nullptr entries are bound to ins[0]); outs: up to 2 UAVs.
    bool Dispatch(ID3D12GraphicsCommandList* cmdList, const DlssNrTemporalConstants& constants,
                  ID3D12Resource* const* ins, ID3D12Resource* const* outs, uint32_t threadsX, uint32_t threadsY);

    DlssNrTemporal_Dx12(std::string name, ID3D12Device* device);
    ~DlssNrTemporal_Dx12();
};
